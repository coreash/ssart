﻿'use strict';

if (document.getElementById("appAdminUserList")) {
    var appAdminUserList = new Vue({
        el: '#appAdminUserList',
        data: {
            srch: {
                type1: '',
                type2: 'vn',
                word: '',
                page: 1
            },
            page: common.pageObj,
            list: [],
            currPage:1,
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/User', { params: param }).then(function (response) {

                    var __data = appAdminUserList._data;

                    for (var ii = 0, l = response.data.list.length; ii < l; ii++) {
                        var _item = response.data.list[ii];
                        if (_item.eo061 === null) _item.eo061 = {};
                    }

                    __data.list = response.data.list;

                    common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    __data.currPage = param.page;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            view: function (item) {
                location.href = '/admin/mngUser/V/' + item.eo030.eo03VenCd + '?' + common.setParamsFromObj(this.srch);
            },
            isValid: function (item) {
                return common.isNullOrEmpty(item.eo061.eo61MemberVen) ||
                    common.isNullOrEmpty(item.eo061.eo61DelFlag) ||
                    item.eo061.eo61DelFlag == true ? '미승인' : '승인';
            },
            displayDate: function (dt) {
                return common.isNullOrEmpty(dt) ? '' : dt.displayDate();
            },
            rowNum: function (idx) {
                return common.displayRowNumber(this.page.totalCount, this.currPage, this.page.pageSize, idx);
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appAdminUserView")) {
    var appAdminUserView = new Vue({
        el: '#appAdminUserView',
        data: {
            constant: {
                phone: constants.phone,
                email: constants.email,
            },
            id: '',
            user: {
                eo030: {},
                eo061: {}
            },
            newPw: {
                pw: '',
                chk:''
            },
        },
        methods: {
            goList: function () {
                location.href = '/admin/mngUser' + location.search;
            },
            view: function () {
                common.showLoading();
                axios.get('/api/User/' + this.id).then(function (response) {
                    if (response.data.eo061 === null) response.data.eo061 = { eo61Id: response.data.eo030.eo03VenNum };
                    appAdminUserView._data.user = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            save: function () {
                if (common.isNullOrEmpty(this.user.eo061.eo61Id)) {
                    alert('아이디를 입력하세요.');
                    return false;
                }
                if (!this.user.eo061.eo61Num && (common.isNullOrEmpty(this.newPw.pw) || this.newPw.pw.trim() !== this.newPw.chk.trim())) {
                    alert('비밀번호를 확인하세요');
                    return false;
                }

                if (!confirm('저장하시겠습니까?')) return false;
                common.showLoading();

                if (!common.isNullOrEmpty(this.newPw.pw)) this.user.eo061.eo61Pwd = this.newPw.pw;

                var param = this.user.eo061;
                
                if (param.eo61Num) {
                    axios.put('/api/User/' + param.eo61Num, param).then(function (response) {
                        appAdminUserView.goList();
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    var eo030 = this.user.eo030;

                    axios.get('/api/User/existsID', { params: { id: param.eo61Id } }).then(function (response) {
                        if (response.data == true) {
                            alert('중복된 아이디입니다.');
                            return false;
                        }
                        common.showLoading();

                        param.eo61MemberKind = 'U';
                        param.eo61MemberVen = eo030.eo03VenCd;
                        param.eo61UserName = eo030.eo03OwnerNm;
                        param.eo61CompanyNum = eo030.eo03VenNum;
                        param.eo61CompanyName = eo030.eo03VenNm;
                        param.eo61OfficeTel = eo030.eo03Phone;
                        param.eo61Fax = eo030.eo03Fax;

                        axios.post('/api/User', param).then(function (response) {
                            appAdminUserView.goList();
                        }).catch(common.errorMessage).finally(function () {
                            common.hideLoading();
                        });
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                    
                }
            },
            cancel: function () {
                if (!confirm('회원 인증을 취소하시겠습니까?')) return false;
                common.showLoading();
                axios.delete('/api/User/' + this.user.eo061.eo61Num).then(function (response) {
                    appAdminUserView.goList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            download: function () { },
        },
        created: function () {
            this.id = common.pathname.split('/V/')[1];
            this.view();
        },
    });
}
if (document.getElementById("appAdminMemberList")) {
    var appAdminMemberList = new Vue({
        el: '#appAdminMemberList',
        data: {
            srch: {
                type: 'id',
                word: '',
                page: 1
            },
            page: common.pageObj,
            user: {
                list: []
            },
            currPage: 1,
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/Member', { params: param }).then(function (response) {

                    var __data = appAdminMemberList._data;

                    __data.user.list = response.data.list;

                    common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    __data.currPage = param.page;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            view: function (item) {
                location.href = '/admin/mngMember/V/' + item.eo06UserCd + '?' + common.setParamsFromObj(this.srch);
            },
            rowNum: function (idx) {
                return common.displayRowNumber(this.page.totalCount, this.currPage, this.page.pageSize, idx);
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appAdminMemberView")) {
    var appAdminMemberView = new Vue({
        el: '#appAdminMemberView',
        data: {
            constant: {
                mobile: constants.mobile,
                phone: constants.phone,
                email: constants.email,
            },
            member: {},
            id:'',
        },
        methods: {
            view: function () {
                common.showLoading();
                axios.get('/api/Member/'+ this.id).then(function (response) {
                    
                    if (response.data.length <= 0) return false;
                    var data = response.data;

                    try {
                        common.splitNumber(data, data.eo06PhoneTel, 'phone', '-');
                        common.splitNumber(data, data.eo06OfficeTel, 'tel', '-');
                        common.splitNumber(data, data.eo06Fax, 'fax', '-');
                        common.splitNumber(data, data.eo06Email, 'email', '@');
                    } catch (e) {
                        alert('데이터를 불러오는 중 오류가 발생했습니다.');
                        //history.back();
                    }
                    appAdminMemberView._data.member = data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            goList: function () {
                location.href = '/admin/mngMember' + location.search;
            },
            remove: function () {
                if (!confirm('삭제하시겠습니까?')) return false;
                common.showLoading();

                this.member.eo06DelFlag = 'Y';
                axios.put('/api/Member/' + this.id, this.member).then(function (response) {
                    appAdminMemberView.goList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });;
                
            },
            modify: function () {
                if (!confirm('수정하시겠습니까?')) return false;
                common.showLoading();
                
                this.member.eo06PhoneTel = (this.member.phone1 || '').trim() + '-' + (this.member.phone2 || '') + '-' + (this.member.phone3 || '');
                this.member.eo06OfficeTel = (this.member.tel1 || '').trim() + '-' + (this.member.tel2 || '') + '-' + (this.member.tel3 || '');
                this.member.eo06Fax = (this.member.fax1 || '').trim() + '-' + (this.member.fax2 || '') + '-' + (this.member.fax3 || '');
                this.member.eo06Email = (this.member.email1 || '').trim() + '@' + (this.member.email2 || '');

                axios.put('/api/Member/' + this.id, this.member).then(function (response) {
                    appAdminMemberView.goList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },

        },
        created: function () {
            this.id = common.pathname.split('/V/')[1];
            this.view();
        }
    });
}
if (document.getElementById("appAdminProductList")) {
    var appAdminProductList = new Vue({
        el: '#appAdminProductList',
        data: {
            srch: {
                type: 'nm',
                word: '',
            },
            product: {
                list: []
            },
            layerPhysicNm: '',
            layerItemIdx:0,
            eo042: {
                eo042Date: '',
                eo042PhysicCd:'',
                eo042PreUnitCost: 0,
                eo042UnitCost: 0,
            },
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                axios.get('/api/product', { params: param }).then(function (response) {

                    var __data = appAdminProductList._data;
                    
                    __data.product.list = response.data.list;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeUseGu: function (item) {
                item.eo040.eo04UseGu = item.eo040.eo04UseGu == '0' || item.eo040.eo04UseGu == 'Y' ? 'N' : 'Y';

                axios.put('/api/product/' + item.eo040.eo04PhysicCd, item.eo040).then(function (response) {

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            showUseGu: function (item) {
                return item.eo040.eo04UseGu == '0' || item.eo040.eo04UseGu == 'Y' ? 'Y' : 'N';
            },
            btnUseClass: function (item) {
                return item.eo040.eo04UseGu == '0' || item.eo040.eo04UseGu == 'Y' ? 'default' : 'cancel';
            },
            rowNum: function (idx) {
                return this.product.list.length - idx;
            },
            showLayer: function (item,idx) {
                if (item.eo042 && item.eo042.eo042DelFlag == 'N') {
                    common.showLoading();
                    item.eo042.eo042DelFlag = 'Y';
                    axios.put('/api/Product/PriceDown', item.eo042).then(function (response) {
                        console.log('pricedown put', response);
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    this.layerPhysicNm = item.eo040.eo04PhysicNm;
                    this.layerItemIdx = idx;
                    this.eo042 = this.setDefault(item.eo040.eo04PhysicCd);
                    
                    $("#areaPriceDown").dialog({
                        resizable: false,
                        width: 300,
                        height: 260,
                        modal: true,
                        title: "약가인하 설정",
                        open: function () {
                            $(this).removeClass('hidden');
                            document.getElementById('ui-datepicker-div').style.display = 'none'
                            $('#tx_pre_unit_cost').select();
                        },
                        buttons: {
                            "확인": this.savePriceDown,
                            "취소": function () {
                                $(this).dialog("close");
                            },
                        }
                    });
                }
            },
            savePriceDown: function () {
                common.showLoading();

                axios.post('/api/Product/PriceDown', this.eo042).then(function (response) {
                    var __data = appAdminProductList._data;
                    console.log(response.data);
                    __data.product.list[__data.layerItemIdx].eo042 = response.data;
                    $("#areaPriceDown").dialog("close");
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },
            updateEndDate: function (d) {
                this.eo042.eo042Date = d;
                var el = document.getElementById("tx_pre_unit_cost");
                if (el) el.select();
            },
            showCalander: function (e) {
                $(e.target).siblings('input').focus();
            },
            showPriceDown: function (item) {
                return item.eo042 && item.eo042.eo042DelFlag == 'N' ? 'Y' : 'N';
            },
            btnPriceDownClass: function (item) {
                return item.eo042 && item.eo042.eo042DelFlag == 'N' ? 'default' : 'cancel';
            },
            setDefault: function (pc) {
                return {
                    eo042Date: this.eo042.eo042Date,
                    eo042PreUnitCost: 0,
                    eo042UnitCost: 0,
                    eo042PhysicCd: pc,
                };
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.eo042 = this.setDefault(opt.endDate, '');
            this.eo042.eo042Date = opt.endDate.displayDate('-');
            
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appAdminProductPriceList")) {
    var appAdminProductPriceList = new Vue({
        el: '#appAdminProductPriceList',
        data: {
            srch: {
                type: 'nm',
                word: '',
                page: 1
            },
            page: common.pageObj,
            product: {
                list: []
            },
            currPage:1,
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/price', { params: param }).then(function (response) {

                    var __data = appAdminProductPriceList._data;

                    __data.product.list = response.data.list;

                    common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    __data.currPage = param.page;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeUseGu: function (item) {
                item.eo041DelFlag = item.eo041DelFlag == 'Y' ? 'N' : 'Y';

                axios.put('/api/price/', item).then(function (response) {

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            btnClass: function (item) {
                return item.eo041.eo041DelFlag == 'Y' ? 'default' : 'cancel';
            },
            rowNum: function (idx) {
                return common.displayRowNumber(this.page.totalCount, this.currPage, this.page.pageSize, idx);
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appAdminMemo")) {
    var appAdminMemo = new Vue({
        el: '#appAdminMemo',
        data: {
            curr: {
                memoText: '',
                closeTime: '',
                stopTime:''
            },
            memo: {
                eoMemo:'',
            },
            time: {
                close: {
                    hour: '',
                    min:''
                },
                stop: {
                    hour: '',
                    min:''
                }
            },
        },
        methods: {
            fitInsertType: function (s) {
                var ns = '0' + s;
                return ns.substring(ns.length - 2);
            },
            saveMemo: function () {
                common.showLoading();

                var param = {
                    eoMemo: this.memo.eoMemo
                };
                
                axios.post('/api/Order/OrderMemo', param).then(function (response) {
                    appAdminMemo._data.curr.memoText = response.data.eoMemo;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            saveTime: function () {
                common.showLoading();

                var param = {
                    closeTime: this.fitInsertType(this.time.close.hour) + this.fitInsertType(this.time.close.min),
                    stopTime: this.fitInsertType(this.time.stop.hour) + this.fitInsertType(this.time.stop.min)
                };

                axios.post('/api/Order/OrderTime', param ).then(function (response) {
                    appAdminMemo._data.curr.closeTime = param.closeTime.substring(0, 2) +':'+ param.closeTime.substring(2);
                    appAdminMemo._data.curr.stopTime = param.stopTime.substring(0, 2) +':'+ param.stopTime.substring(2);
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },

            getData: function () {
                common.showLoading();
                axios.get('/api/Order/OrderMemo').then(function (response) {
                    appAdminMemo._data.memo = response.data;
                    appAdminMemo._data.curr.memoText = appAdminMemo._data.memo.eoMemo;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

                axios.get('/api/order/orderTime').then(function (response) {
                    var _item = response.data;
                    var _data = appAdminMemo._data.time;

                    _data.close.hour = _item.closeTime.substring(0,2);
                    _data.close.min = _item.closeTime.substring(2);
                    _data.stop.hour = _item.stopTime.substring(0,2);
                    _data.stop.min = _item.stopTime.substring(2);

                    appAdminMemo._data.curr.closeTime = _data.close.hour + ':' + _data.close.min;
                    appAdminMemo._data.curr.stopTime = _data.stop.hour + ':' + _data.stop.min;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
        },
        created: function () {
            this.getData();
        },
    });
}
if (document.getElementById("appPopup")) {
    var appPopup = new Vue({
        el: '#appPopup',
        data: {
            srch: {
                type: 'title',
                word: '',
                page: 1
            },
            page: common.pageObj,
            list: [],
            currPage :1,
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/popup', { params: param }).then(function (response) {

                    var __data = appPopup._data;

                    __data.list = response.data.list;

                    common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    __data.currPage = param.page;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            rowNum: function (idx) {
                return common.displayRowNumber(this.page.totalCount, this.currPage, this.page.pageSize, idx);
            },
            view: function (item) {
                location.href = '/Admin/MngPopup/V/' + item.eopopNum + '?' + common.setParamsFromObj(this.srch);
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appPopupWrite")) {
    Vue.use(CKEditor);
    
    var appPopupWrite = new Vue({
        el: '#appPopupWrite',
        data: {
            popup: {
                eopopGubun: constants.popupGubun.order,
            },
            id: '',
            editorConfig: {
                filebrowserUploadUrl: '/api/popup/UploadFile',
            },
            venList: [],
            selectedVenList: [],
            srch: {
                venCd: '',
            },
            dt: null,
        },
        methods: {
            errorMessageLocal: function (e) {
                common.errorMessage(e);
                common.hideLoading();
            },
            view: function () {
                common.showLoading();

                axios.get('/api/popup/' + this.id).then(function (response) {
                    if (response.data == null) return;

                    var __data = response.data;
                    __data.eopopStartDate = __data.eopopStartDate.displayDate('-');
                    __data.eopopEndDate = __data.eopopEndDate.displayDate('-');
                    appPopupWrite._data.popup = __data;

                    if (!common.isNullOrEmpty(__data.eopopVenCd)) {
                        axios.get('/api/popup/GetVen?vc=' + __data.eopopVenCd).then(function (response) {
                            appPopupWrite.selectedVenList = response.data;
                        }).catch(common.errorMessage);
                    }

                }).catch(this.errorMessageLocal);
                setTimeout(function () {
                    common.hideLoading();
                }, 1500);
            },
            goList: function () {
                location.href = '/admin/mngPopup' + location.search;
            },
            getSelectedVenList: function () {
                var s = [];
                for (var ii = 0, l = this.selectedVenList.length; ii < l; ii++) {
                    s.push(this.selectedVenList[ii].venCd);
                }
                return s.length > 0 ? s.join(',') : '';
            },
            save: function () {
                if (common.isNullOrEmpty(this.popup.eopopGubun)) {
                    alert('구분을 선택하세요');
                    return false;
                }
                if (common.isNullOrEmpty(this.popup.eopopTitle)) {
                    alert('제목을 입력하세요');
                    return false;
                }
                if (common.isNullOrEmpty(this.popup.eopopContent)) {
                    alert('내용을 입력하세요');
                    return false;
                }

                if (!confirm('저장하시겠습니까?')) return false;
                common.showLoading();
                this.popup.eopopVenCd = '';
                if (this.popup.eopopGubun != constants.popupGubun.outside) this.popup.eopopVenCd = this.getSelectedVenList();

                if (this.id) {
                    axios.put('/api/popup/' + this.id, this.popup).then(function (response) {
                        alert('저장되었습니다.');
                        appPopupWrite.goList();
                    }).catch(this.this.errorMessageLocal);
                } else {
                    axios.post('/api/popup', this.popup).then(function (response) {
                        alert('저장되었습니다.');
                        appPopupWrite.goList();
                    }).catch(this.this.errorMessageLocal);
                } 
                common.showLoading();
            },
            remove: function () {
                if (!confirm('삭제하시겠습니까?')) return false;
                common.showLoading();
                axios.delete('/api/popup/' + this.id).then(function (response) {
                    alert('처리 완료되었습니다.');
                    appPopupWrite.goList();
                }).catch(this.errorMessageLocal);
            },
            updateStartDate: function (d) {
                this.popup.eopopStartDate = d;
            },
            updateEndDate: function (d) {
                this.popup.eopopEndDate = d;
            },
            showCalander: function (e) {
                $(e.target).siblings('input').focus();
            },
            showSearchVen: function () {
                this.srch.venCd = '';
                this.venList = [];
                $("#areaSearchVen").dialog({
                    resizable: false,
                    width: 600,
                    height: 358,
                    modal: true,
                    title: "거래처검색",
                    open: function () {
                        $(this).removeClass('hidden');
                        $('#tx_ven_cd').focus();
                    },
                    buttons: {
                        "확인": function () {
                            $(this).dialog("close");
                        },
                    }
                });
            },
            clearVenList: function () {
                this.selectedVenList = [];
            },
            searchVen: function () {
                common.showLoading();

                axios.get('/api/Common/GetVenList', { params: this.srch }).then(function (response) {
                    appPopupWrite._data.venList = response.data;
                    common.hideLoading();
                }).catch(this.errorMessageLocal);
                
            },
            selectVen: function (item) {
                if (this.selectedVenList.filter(function (r) { return r.venCd == item.eo03VenCd; }).length > 0) return;
                this.selectedVenList.push({
                    venCd: item.eo03VenCd,
                    venNm: item.eo03VenNm
                });
            },
            removeVen: function (idx) {
                this.selectedVenList.splice(idx, 1);
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.popup.eopopStartDate = opt.startDate;
            this.popup.eopopEndDate = opt.endDate;

            this.id = common.pathname.split('/V/')[1];
            if (this.id) this.view();
            else {
                setTimeout(function () {
                    common.hideLoading();
                }, 1000);
            }
        },
    });
}
if (document.getElementById("appAdminHoliday")) {
    var appAdminHoliday = new Vue({
        el: '#appAdminHoliday',
        data: {
            currYear:'',
            year: [],
        },
        methods: {
            setHoliday: function (item) {
                
                common.showLoading();
                if (item.cls.indexOf('holiday_set') > -1) {
                    axios.delete('/api/Holiday/'+ item.id).then(function (response) {
                        item.cls = item.cls.replace('holiday_set', '');
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    var param = {
                        eodayTargetDate: item.id,
                        eodayFlag: 'holiday'
                    };
                    
                    axios.post('/api/Holiday', param).then(function (response) {
                        item.cls += ' holiday_set';
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                }
            },
            getData: function (yyyy) {
                common.showLoading();
                var __data = this;
                __data.currYear = yyyy;

                axios.get('/api/Holiday?year='+ yyyy).then(function (response) {

                    var today = new Date(String(yyyy));
                    var year = [];
                    for (var mm = 1, l = 12; mm <= l; mm++) {
                        var item = {
                            month: mm,
                            list: [],
                        };
                        var respnoseList = response.data;
                        
                        var firstDate = new Date(today.getFullYear(), mm - 1, 1);  // 이번 달의 첫째 날
                        var lastDate = new Date(today.getFullYear(), mm, 0); // 이번 달의 마지막 날
                        
                        var aryHtml = [];

                        var dd = 1;
                        for (var i = 1; i < lastDate.getDate() + firstDate.getDay() + 1; i++) {
                            var strClass = "";
                            var strAClass = "";
                            if (i % 7 == 1 || i % 7 == 0) {
                                strClass = "holiday";
                            } else {
                                strClass = "";
                            }
                            if (firstDate.getDay() < i) {
                                var NowDate = String(yyyy) + ((mm < 10) ? "0" + mm : mm) + ((dd < 10) ? "0" + dd : dd);
                                
                                if (respnoseList != null) {
                                    for (var j = 0; j < respnoseList.length; j++) {
                                        
                                        if (respnoseList[j]["eodayTargetDate"] == NowDate) {
                                            
                                            strClass += " holiday_set";
                                            break;
                                        }
                                    }
                                }
                                aryHtml.push({
                                    id:NowDate,
                                    text: dd,
                                    cls: strClass,
                                });
                                dd++;
                            } else {
                                aryHtml.push({
                                    id:'',
                                    text: '&nbsp;',
                                    cls:'',
                                });

                            }

                            if (i % 7 == 0) {
                                item.list.push(aryHtml);
                                aryHtml = [];
                            }

                        }
                        if (aryHtml.length > 0) item.list.push(aryHtml);
                        year.push(item);
                    }
                    __data.year = year;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            lastYear: function () {
                var year = this.currYear - 1;
                this.getData(year);
            },
            nextYear: function () {
                var year = this.currYear + 1;
                this.getData(year);
            },
            thisYear: function () {
                var year = new Date().getFullYear();
                this.getData(year);
            },
        },
        created: function () {
            this.thisYear();
        },
    });
}

if (document.getElementById("appCollectMoney")) {

    Vue.component('datepicker', {
        template: '<input type="text" class="nm" />',
        mounted: function () {
            var self = this;

            $(this.$el).monthpicker({
                dateFormat: "yy-mm"
                , monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
                , monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']
                , changeMonth: true // 월선택 select box 표시 (기본은 false)
                , changeYear: true  // 년선택 selectbox 표시 (기본은 false)
                , showMonthAfterYear: true // 다음년도 월 보이기
                , showOtherMonths: true // 다른 월 달력에 보이기
                , selectOtherMonths: true // 다른 월 달력에 보이는거 클릭 가능하게 하기
                , onSelect: function (d) { self.$emit('update-date', d) }
            });

        },
        beforeDestroy: function () { $(this.$el).datepicker('hide').datepicker('destroy') }
    });

    var appCollectMoney = new Vue({
        el: '#appCollectMoney',
        data: {
            srch: {
                collectMonth: '',
                venNm: '',
                venCd: '',
                page: 1
            },
            page: common.pageObj,
            collectMoney: {
                list: []
            },
            vendor: {
                list: []
            }
        },
        filters: {
            comma: function(val) {
                return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            },
            formatDate: function(val) {
                if (val !== undefined && val.length == 6) {
                    return val.substr(0, 4) + '.' + val.substr(4, 2);
                }
                else if (val !== undefined && val.length == 8) {
                    return val.substr(0, 4) + '.' + val.substr(4, 2) + '.' + val.substr(6, 2);
                }
            }
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            updateCollectMonth: function (d) {
                this.srch.collectMonth = d;
            },
            searchVen: function () {
                var param = this.srch.venCd;
                common.showLoading();

                if (param.length > 0) {
                    axios.get('/api/Common/GetVendors', { params: { searchText: param } })
                        .then(function (response) {
                            var __data = appCollectMoney._data;
                            __data.vendor.list = response.data.list;
                            if (response.data.list.length > 0) __data.srch.venCd = response.data.list[0].eo03VenCd;
                        })
                        .catch(common.errorMessage).finally(function () {
                            common.hideLoading();
                        });
                }
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/CollectMoney/GetEoCollectMoney', { params: param })
                    .then(function (response) {

                        var __data = appCollectMoney._data;

                        __data.collectMoney.list = response.data.list;

                        common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);

                    })
                    .catch(function (error) {
                        if (error.response.status == 401) {
                            location.href = '/Main/Login';
                            return;
                        }
                        console.log(error);
                    }).finally(function () {
                        common.hideLoading();
                    });
            },
            downloadSample: function () {
                common.showLoading();
                var url = '/Stock/DownloadExcelSample';
                var fileName = "수금자료_샘플.xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: { sampleType: "collectMoney" },
                    responseType: 'blob',
                })
                    .then(function(response){
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            }
        },
        created: function () {

            var date = new Date();
            var year = date.getFullYear();
            var month = ("0" + (1 + date.getMonth())).slice(-2);

            this.srch.collectMonth = year + "-" + month;

            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}