﻿Vue.directive('focus', {
    inserted: function (el) {
        el.focus();
    }
});

Vue.directive('numeric-only', {
    bind: function(el, binding, vnode) {
        el.addEventListener('keyup', function () {
            var regex = /^[0-9]*$/
            el.value = el.value.replace(/[^0-9]/g, '');
        });
    }
});

Vue.directive('select-all', {
    bind: function(el, binding, vnode) {
        el.addEventListener('focus', function () {
            el.select();
        });
    }
});