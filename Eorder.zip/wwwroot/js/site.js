﻿'use strict';
var evtBus = new Vue();
if (document.getElementById("header")) {
    var appHeader = new Vue({
        el: '#header',
        data: {
            currUser: {
                userCd: '',
                userNm: '',
                userKind: '',
                venCd: '',
                venNm: ''
            },
            baseDate: '',
            baseMonth: '',
            layerGu: '',
        },
        methods: {
            loginCheck: function () {
                axios.get('/api/Login/IsLogin').then(function (response) {
                    appHeader._data.currUser = response.data;

                    if (response.data.userCd == '') {
                        common.errorMessage({ response: { status: 401 } });
                        return;
                    }
                    if (response.data.userKind !== 'A' && common.pathname.toLowerCase().indexOf('admin') > 0) {
                        alert('관리자 로그인이 필요합니다');
                        location.href = '/Main/Login/Logout';
                        return;
                    }
                    evtBus.$emit('IsLogin', response.data);
                });
            },
            isSales: function () {
                return this.currUser.userKind == 'S';
            },
            isAdmin: function () {
                return this.currUser.userKind == 'A' || this.currUser.userKind == 'SA';
            },
            isUser: function () {
                return this.currUser.userKind == 'U';
            },
            isSuperAdmin: function () {
                return this.currUser.userKind == 'A';
            },
            showchoiceDate: function (f) {
                this.layerGu = f;
                $("#areaBaseDate").dialog({
                    resizable: false,
                    width: 400,
                    height: 190,
                    modal: true,
                    title: "e-Order",
                    open: function () {
                        $(this).removeClass('hidden');
                        $(this).focus();
                    },
                    buttons: {
                        "확인": this.showPopup,
                        "취소": function () {
                            $(this).addClass('hidden');
                            $(this).dialog("close");
                        },
                    }
                });
            },
            updateBaseDate: function (d) {
                this.baseDate = d;
                document.getElementById("areaBaseDate").focus();
            },
            updateBaseMonth: function (d) {
                this.baseMonth = d;
                document.getElementById("areaBaseDate").focus();
            },
            showCalander: function (e) {
                $(e.target).siblings('input').focus();
            },
            showPopup: function () {
                if (this.layerGu === 'D') this.showPrintBalance();
                else this.showPrintReceive();
            },
            showPrintReceive: function () {
                var url = '/TransCard/PrintReceive?dt=' + this.baseMonth.replace(/-/g, '');
                window.open(url, 'popReceive', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=800,height=800');
            },
            showPrintBalance: function () {
                var url = "/TransCard/PrintBalance?dt=" + this.baseDate;
                window.open(url, "PrintPopup", "toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=800,height=800");
            },
            loginUserCd: function () {
                return this.currUser.userCd;
            },
        },
        created: function () {
            this.loginCheck();
            var opt = common.getSrchDateOption();
            this.baseDate = opt.endDate;
            this.baseMonth = opt.endDate.substring(0,7); 
        },
    });
}
if (document.getElementById("appMenu")) {
    var appMenu = new Vue({
        el: '#appMenu',
        methods: {
            notReady: function () {
                alert('준비중입니다.');
                return false;
            },
        },
        computed: {
            viewType: function () {
                return common.pathname.toLowerCase().indexOf('admin') > 0 ? 'A' : 'U';
            },
            userKind: function () {
                return appHeader._data.currUser.userKind;
            },
            isActive: function () {
                return common.pathname.substring(1).toLowerCase().replace('admin/','').split('/')[0];
            },
        }
    });
}

if (document.getElementById("appModifyInfo")) {
    var appModifyInfo = new Vue({
        el: '#appModifyInfo',
        data: {
            user: {
                eo030: {},
                eo061: {}
            },
            newPw: {
                pw: '',
                chk: ''
            },
        },
        methods: {
            view: function () {
                common.showLoading();
                axios.get('/api/User/Info').then(function (response) {
                    appModifyInfo._data.user = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            save: function () {
                if (common.isNullOrEmpty(this.user.eo061.eo61Id)) {
                    alert('아이디를 입력하세요.');
                    return false;
                }
                
                if (!this.user.eo061.eo61Num || common.isNullOrEmpty(this.newPw.pw) || this.newPw.pw.trim() !== this.newPw.chk.trim()) {
                    alert('비밀번호를 확인하세요');
                    this.$refs.newPw.select();
                    return false;
                }
                if (!common.isValidPassword(this.newPw.pw)) {
                    alert('비밀번호는 숫자,영문자,특수문자를 포함하여 8~15자리로 설정해주세요.');
                    this.$refs.newPw.select();
                    return false;
                }
                if (!confirm('저장하시겠습니까?')) return false;
                common.showLoading();

                if (!common.isNullOrEmpty(this.newPw.pw)) this.user.eo061.eo61Pwd = this.newPw.pw;

                var param = this.user.eo061;

                axios.put('/api/User/' + param.eo61Num, param).then(function (response) {
                    alert('변경이 완료되었습니다.');
                    appModifyInfo._data.newPw = {
                        pw: '',
                        chk: ''
                    };
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },
          
        },
        created: function () {
            this.view();
        },
    });
}
if (document.getElementById("appModifySalesInfo")) {
    var appModifySalesInfo = new Vue({
        el: '#appModifySalesInfo',
        data: {
            user: {},
            newPw: {
                pw: '',
                chk: ''
            },
        },
        methods: {
            view: function () {
                common.showLoading();
                axios.get('/api/User/SalesInfo').then(function (response) {
                    appModifySalesInfo._data.user = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            save: function () {
                if (common.isNullOrEmpty(this.newPw.pw) || this.newPw.pw.trim() !== this.newPw.chk.trim()) {
                    alert('비밀번호를 확인하세요');
                    this.$refs.newPw.select();
                    return false;
                }
                if (!common.isValidPassword(this.newPw.pw)) {
                    alert('비밀번호는 숫자,영문자,특수문자를 포함하여 8~15자리로 설정해주세요.');
                    this.$refs.newPw.select();
                    return false;
                }

                if (!confirm('저장하시겠습니까?')) return false;
                common.showLoading();

                if (!common.isNullOrEmpty(this.newPw.pw)) this.user.eo06Password= this.newPw.pw;
                
                axios.put('/api/User/SalesInfo/'+ this.user.eo06UserCd, this.user).then(function (response) {
                    alert('변경이 완료되었습니다.');
                    appModifySalesInfo._data.newPw = {
                        pw: '',
                        chk: ''
                    };
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },

        },
        created: function () {
            this.view();
        },
    });
}

if (document.getElementById("appOrder") || document.getElementById("appReward")) {
    var appInfo = common.getAppInfo();

    var appOrder = new Vue({
        el: '#app' + appInfo.appName,
        data: {
            isShowProductInfo: false,
            srch: {
                venCd: '',
                dropCd: '',
                type: '',
                phyNm: '',
                bagType: appInfo.appBagType,
            },
            product: {
                list: [],
                view: {
                    info: {},
                    orderedList: [],
                    avgQty: 0,
                    sumPrice: 0
                },
            },
            venList: [],
            dropList: [],
            memo: {},
            popup: [],
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();
                this.isShowProductInfo = false;
                var param = this.srch;

                axios.get('/api/Order', { params: param }).then(function (response) {
                    var __data = appOrder._data;
                    if (response.data.list == null) response.data.list = [];

                    __data.product.list = response.data.list;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            viewDetail: function (item) {
                common.showLoading();
                this.product.view.info = item.eo040;
                var param = 'venCd=' + this.srch.venCd + '&dropCd=' + this.srch.dropCd + '&physicCd=' + item.eo040.eo04PhysicCd;
                axios.get('/api/Order/OrderedList?' + param).then(function (response) {
                    appOrder._data.product.view.orderedList = response.data;
                    var sumQty = 0;
                    var monthPrice = 0;
                    var today = new Date();
                    var currMonth = today.getFullYear() + ('0' + (today.getMonth() + 1)).substring(-2);
                    for (var ii = 0, l = response.data.length; ii < l; ii++) {
                        var item = response.data[ii];
                        sumQty += item.eo16Quantity;
                        if (item.eo16ReYyMmDd.substring(0, 6) == currMonth) monthPrice += (item.eo16SupplyPrice + item.eo16TaxPrice);
                    }
                    appOrder._data.product.view.avgQty = sumQty > 0 ? sumQty / response.data.length : 0;
                    appOrder._data.product.view.sumPrice = monthPrice;
                    appOrder._data.isShowProductInfo = true;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            hideDetail: function () {
                this.isShowProductInfo = false;
            },
            insertBagProc: function (param, _callback) {
                common.showLoading();
                axios.post('/api/Bag', param).then(function (response) {
                    appBag.getBagList();
                    if (_callback !== undefined && typeof _callback == 'function') _callback();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            insertBag: function (e, item) {

                if (e.keyCode != 13) return;
                if (appInfo.appBagType === constants.bagType.order &&
                    (!item.stock || item.stock.storQty <= 0 || item.realPrice <= 0)) {

                    alert('재고/단가를 확인해주세요.\n'+ item.eo040.eo04PhysicNm);
                    return false;
                }
                var param = [{
                    eobgType: this.srch.bagType,
                    eobgVenCd: item.eo041.eo041VenCd,
                    eobgDropCd: item.eo041.eo041DropCd,
                    eobgPhysicCd: item.eo040.eo04PhysicCd,
                    eobgPrice: appInfo.appBagType === constants.bagType.order ? item.realPrice : item.eo042.eo042UnitCost,
                    eobgQty: parseInt(item.qty)
                }];
                
                this.insertBagProc(param, function () {
                    item.qty = '';
                });
            },
            insertBagAll: function () {
                var param = [];
                var notValid = [];
                for (var ii = 0, l = this.product.list.length; ii < l; ii++) {
                    var item = this.product.list[ii];
                    if (common.isNullOrEmpty(item.qty) || parseInt(item.qty) <= 0) continue;
                    ///단가 재고 체크
                    if (appInfo.appBagType === constants.bagType.order &&
                        (!item.stock || item.stock.storQty <= 0 || item.realPrice <= 0)) {

                        notValid.push(item.eo040.eo04PhysicNm);
                        continue;
                    }
                    param.push({
                        eobgType: this.srch.bagType,
                        eobgVenCd: item.eo041.eo041VenCd,
                        eobgDropCd: item.eo041.eo041DropCd,
                        eobgPhysicCd: item.eo040.eo04PhysicCd,
                        eobgPrice: appInfo.appBagType === constants.bagType.order ? item.realPrice : item.eo042.eo042UnitCost,
                        eobgQty: parseInt(item.qty)
                    });
                    item.qty = '';
                }
                if (notValid.length > 0) {
                    alert('재고/단가를 확인해주세요.\n' + notValid.join('\n'));
                    return false;
                }
                this.insertBagProc(param, function () {

                });
            },
            getVenList: function (e) {
                common.showLoading();

                axios.get('/api/Common/GetVenList?venCd=' + encodeURIComponent(this.srch.venCd)).then(function (response) {
                    appOrder._data.venList = response.data;
                    if (response.data.length > 0) appOrder.setVenCd(response.data[0].eo03VenCd);
                    else alert('조회가능한 거래처가 없습니다.');
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeVenCd: function () {
                this.getDropList();
                appBag.getBagList();
            },
            setVenCd: function (venCd) {
                this.srch.venCd = venCd;
                this.$refs.selectVenCd.focus();
                this.changeVenCd();
            },
            setDropCd: function (dropCd) {
                this.srch.dropCd = dropCd;
                this.changeDropCd(dropCd);
            },
            getDropList: function () {
                common.showLoading();
                var param = {
                    venCd: this.srch.venCd
                };
                axios.get('/api/Common/GetDropList?' + common.setParamsFromObj(param)).then(function (response) {
                    appOrder._data.dropList = response.data;
                    if (response.data.length > 0) appOrder.setDropCd(response.data[0].eo31DropCd);
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getMemo: function () {
                common.showLoading();
                axios.get('/api/Order/OrderMemo').then(function (response) {
                    appOrder._data.memo = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeDropCd: function (dropCd) {
                this.search(1);
                var obj = this.dropList.filter(function (x) {
                    return x.eo31DropCd == dropCd;
                });
                appBag.changeDrop(obj);
            },
            changeInterest: function (item) {
                var params = {
                    eo43VenCd: this.srch.venCd,
                    eo43PhysicCd: item.eo040.eo04PhysicCd
                };
                if (item.eo043 === null) {
                    axios.post('/api/Order/Interest', params).then(function (response) {
                        item.eo043 = response.data;
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    axios.delete('/api/Order/Interest', { data: params }).then(function (response) {
                        item.eo043 = null;
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                }
            },
            getPopup: function () {
                common.showLoading();
                var param = {
                    type: 'today',
                    page: 1,
                    pageSize: 100,
                };
                axios.get('/api/popup?' + common.setParamsFromObj(param)).then(function (response) {
                    if (response.data && response.data.count <= 0) return;
                    for (var ii = 0, l = response.data.list.length; ii < l; ii++) {
                        var item = response.data.list[ii];
                        var showFlag = true;
                        
                        if (common.getCookie(item.eopopCook.trim()) == 'ON') showFlag = false;
                        item.show = showFlag;
                        if (item.eopopGubun == constants.popupGubun.order) {
                            appOrder._data.popup.push(item);
                        }
                        else if (showFlag == true && item.eopopGubun == constants.popupGubun.inside) {

                            var popoupwidth = parseInt(item.eopopWidth);
                            var popoupheight = parseInt(item.eopopHeight);
                            if (popoupwidth < 250) popoupwidth = 250;
                            if (popoupheight < 100) popoupheight = 100;

                            if (common.isIEbrowser()) {
                                popoupwidth += 30;
                                popoupheight += 123;
                            } else {
                                popoupwidth += 30;
                                popoupheight += 133;
                            }
                            
                            var param = 'width=' + popoupwidth + ',height=' + popoupheight + ',left=' + item.eopopLeft + ',top=' + item.eopopTop + ',scrollbars=no,resizable=no';

                            window.open('/main/popup?n=' + item.eopopNum, 'pop' + item.eopopNum, param);
                        }
                    }

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            noMorePopup: function (item) {
                common.setCookie(item.eopopCook.trim(), "ON", 1);
                item.show = false;
            },
            closePopup: function (item) {
                item.show = false;
            },
            viewStock: function (item) {
                try {
                    return item.stock && item.stock.storQty > 0 ? 'O' : 'X';
                } catch(e) {
                    return 'X';
                }
            },
            viewPrice: function (item) {
                item.realPrice = common.getOrderPrice(this.srch.bagType, item.eo040.eo04InsuPrice, item.eo041.eo041CtrPYl, item.eo041.eo041HpinYl);
                return item.realPrice.toLocaleFixed();
            },
            viewShipAddr: function () {
                
                var dropCd = this.srch.dropCd;
                var curr = this.dropList.filter(function (x) {
                    return x.eo31DropCd == dropCd;
                });
                return curr[0] ? curr[0].eo31Address : '';
            },
        },
        created: function () {
            this.getDropList();
            this.getMemo();
            if(appInfo.appBagType === constants.bagType.order) this.getPopup();
        },
        computed: {
            isAdmin: function () {
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            },
        },
    });
}
if (document.getElementById("appOrderSearch") || document.getElementById("appReturnSearch") || document.getElementById("appRewardSearch")) {
    var appInfo = common.getAppInfo();
    
    var appOrderSearch = new Vue({
        el: '#app' + appInfo.appName,
        data: {
            srch: {
                venCd: '',
                dropCd: '',
                type: '',
                phyNm: '',
                startDate: '',
                endDate: '',
                ordGu: appInfo.appBagType
            },
            list: [],
            groupList: [],
            venList: [],
            dropList: [],
            chkAll: false,
            columnCnt: 16,
            reason: '',
            confirmNote: '',
            sortType: '',
            sortFlag: '',
            confirmDate: '',
        },

        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();

                var param = this.srch;

                axios.get('/api/OrderSearch?' + common.setParamsFromObj(param)).then(function (response) {

                    //axios.post('/api/Common/PostSendEmail').then(function (response) {
                    //    console.log('send mail');
                    //}).catch(common.errorMessage).finally(function () {

                    //});
                    var __data = appOrderSearch._data;
                    var groupList = [];
                    var map = {};

                    __data.list = response.data.list;

                    for (var ii = 0, l = __data.list.length; ii < l; ii++) {
                        var item = __data.list[ii];
                        item.chked = false;
                        item.venCheck = {};
                        item.detail = {
                            list: [],
                            venInfo: {},
                            dropInfo: {},
                            custScrt: [],
                        };

                        var key = (item.revenCd + '-' + item.dropCd);
                        if (!map[key]) {
                            map[key] = true;
                            groupList.push({
                                revenCd: item.revenCd,
                                dropCd: item.dropCd
                            });
                        }
                    }
                    __data.groupList = groupList;
                    appOrderSearch.getVenChecks();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getVenChecks: function () {

                //common.showLoading();
                axios.post('/api/OrderSearch/VenCheck', this.groupList).then(function (response) {

                    if (!response.data || response.data.length <= 0) return;

                    for (var ii = 0, l = appOrderSearch._data.list.length; ii < l; ii++) {
                        var _item = appOrderSearch._data.list[ii];

                        for (var jj = 0, k = response.data.length; jj < k; jj++) {
                            var _group = response.data[jj];

                            if (_item.revenCd.trim() === _group.venCd.trim() && _item.dropCd.trim() === _group.dropCd.trim()) {
                                _item.venCheck = _group;
                            }
                        }
                    }
                    appOrderSearch.$forceUpdate();

                }).catch(common.errorMessage).finally(function () {
                    //common.hideLoading();
                });
            },
            getSelectedItems: function (flag) {
                var items = [];
                var cntAlready = 0;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];

                    if (item.selected != 'Y') continue;
                    if (item.maxReDi != '1' && flag != 'excel') {
                        cntAlready++;
                        item.selected = '';
                        continue;
                    }
                    items.push({
                        eo15ReYyMmDd: item.reYyMmDd,
                        eo15RevenCd: item.revenCd,
                        eo15ReSeq: item.reSeq,
                    });
                    var currIdx = items.length - 1;

                    items[currIdx].eo15Other = item.other;
                    if (flag == 'confirm') items[currIdx].eo15Other += (!common.isNullOrEmpty(this.confirmNote) ? ' / ' + this.confirmNote : '');
                    if (flag == 'ret') items[currIdx].eo15ReturnMsg = this.reason;

                    items[currIdx].eo15ConfirmDateToIF = this.confirmDate.replace(/-/g, '');

                    if ((item.other.trim() + ' / ' + this.confirmNote.trim()).length > 80) {
                        alert('비고 글자수가 많습니다.');
                        return [];
                    }
                }
                if (cntAlready > 0) {
                    alert('이미 처리된 건은 처리할 수 없습니다.');
                }
                return items;
            },
            getSelectedItemsForPrint: function () {
                var yyyymmdds = [];
                var seqs = [];

                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];

                    if (item.selected != 'Y') continue;
                    yyyymmdds.push(item.reYyMmDd);
                    seqs.push(item.reSeq);
                }
                if (yyyymmdds.length <= 0) return '';

                return 'dt=' + yyyymmdds.join(',') + '&s=' + seqs.join(',');
            },
            getSelectedItemsForMod: function () {
                var items = [];
                var cntAlready = 0;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];

                    if (item.selected != 'Y') continue;
                    //if (item.maxReDi != '1') {
                    //    cntAlready++;
                    //    item.selected = '';
                    //    continue;
                    //}
                    items.push({
                        eo15ReYyMmDd: item.reYyMmDd,
                        eo15RevenCd: item.revenCd,
                        eo15ReSeq: item.reSeq,
                    });
                    var details = [];
                    for (var jj = 0, k = item.detail.list.length; jj < k; jj++) {
                        var detailItem = item.detail.list[jj];

                        // detailItem.eo160.eo16UnitCost = common.getOrderPrice(appInfo.appBagType, detailItem.eo040.eo04InsuPrice, detailItem.eo160.eo16CtrPYl, detailItem.eo160.eo16HpinYl);

                        details.push(detailItem.eo160);
                    }
                    items[items.length - 1].detail = details;
                }
                if (cntAlready > 0) {
                    alert('이미 처리된 건은 처리할 수 없습니다.');
                }
                return items;
            },
            print: function () {
                var items = this.getSelectedItemsForPrint();
                if (items == '') {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }
                var param = items + '&sd=' + this.srch.startDate + '&ed=' + this.srch.endDate + '&vc=' + this.srch.venCd + '&dc=' + this.srch.dropCd;
                window.open('/OrderSearch/Print?' + param, 'printPopup', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=1100,height=800');
            },
            excelDown: function () {
                var items = this.getSelectedItems('excel');
                if (items.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }
                common.showLoading();
                var fileName = "주문내역_" + common.getToday() + ".xlsx";

                var header = {
                    responseType: 'blob'
                };
                var param = {
                    startDate: this.srch.startDate,
                    endDate: this.srch.endDate,
                    venCd: this.srch.venCd,
                    dropCd: this.srch.dropCd,
                }
                axios.post('/api/OrderSearch/ExcelDown?' + common.setParamsFromObj(param), items, header).then(function (response) {
                    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                        // IE에서 동작
                        window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                    } else {
                        var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                        var fileLink = document.createElement('a');

                        fileLink.href = fileURL;
                        fileLink.setAttribute('download', fileName);
                        document.body.appendChild(fileLink);

                        fileLink.click();
                    }
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            updateStartDate: function (d) {
                this.srch.startDate = d;
            },
            updateEndDate: function (d) {
                this.srch.endDate = d;
            },
            updateConfirmDate: function (d) {
                this.confirmDate = d;
                var el = document.getElementById("tx_confirm_note");
                if (el) el.select();
            },
            setVenCd: function (venCd) {
                this.srch.venCd = venCd;
                this.getDropList();
            },
            setDropCd: function (dropCd) {
                this.srch.dropCd = dropCd;
                this.getList();
            },
            getVenList: function (e) {
                common.showLoading();

                axios.get('/api/Common/GetVenList?venCd=' + encodeURIComponent(this.srch.venCd)).then(function (response) {
                    appOrderSearch._data.venList = response.data;
                    if (response.data.length > 0) appOrderSearch.setVenCd(response.data[0].eo03VenCd);
                    else alert('조회가능한 거래처가 없습니다.');
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getDropList: function () {
                common.showLoading();
                var param = {
                    venCd: this.srch.venCd
                };
                axios.get('/api/Common/GetDropList?' + common.setParamsFromObj(param)).then(function (response) {
                    appOrderSearch._data.dropList = response.data;
                    //if (response.data.length > 0) appOrderSearch.setDropCd(response.data[0].eo31DropCd);
                    appOrderSearch.getList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            toggleChkAll: function () {
                var newChkAll = !this.chkAll;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    this.list[ii].selected = newChkAll ? 'Y' : '';
                }
                this.chkAll = newChkAll;
            },
            toggleSelect: function (item) {
                item.selected = item.selected == 'Y' ? '' : 'Y';
            },
            view: function (item, index) {
                var id = item.reYyMmDd + item.revenCd.trim() + item.reSeq;

                var target = this.$refs.items[index].nextElementSibling;

                if (item.detail.list.length > 0) {
                    if (target.className.indexOf('hidden') < 0) {
                        target.className = 'hidden detailArea';
                        //item.selected = '';
                    } else {
                        target.className = 'detailArea';
                        //item.selected = 'Y';
                    }
                    return;
                }
                var param = 'yyyymmdd=' + item.reYyMmDd + '&revenCd=' + item.revenCd.trim() + '&seq=' + item.reSeq;

                this.getVenInfo(item);
                this.getCustScrt(item);
                //item.selected = 'Y';
                common.showLoading();
                axios.get('/api/OrderSearch/Detail?' + param).then(function (response) {

                    item.detail.list = response.data.list;
                    target.className = 'detailArea';

                    if (response.data.list.length > 0 && response.data.list[0].eo031) item.detail.dropInfo = response.data.list[0].eo031;
                    appOrderSearch.$forceUpdate();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            showCalander: function (e) {
                $(e.target).siblings('input').focus();
            },
            rowNum: function (idx) {
                return this.list.length - idx;
            },
            closeReasonLayer: function () {
                $('#areaCancelReason').dialog("close");
            },
            closeConfirmLayer: function () {
                $('#areaConfirmNote').dialog("close");
            },
            confirm: function () {
                var items = this.getSelectedItems('confirm');
                if (items.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }

                if (!confirm('선택하신 주문건을 승인처리 하시겠습니까?')) return false;

                common.showLoading();
                axios.post('/api/OrderSearch/Confirm', items).then(function (response) {
                    alert('승인 완료되었습니다.');
                    appOrderSearch.closeConfirmLayer();
                    appOrderSearch.search();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            showNotePop: common.showNotePop,
            showReasonPop: common.showReasonPop,
            cancel: function () {
                var items = this.getSelectedItems('ret');
                if (items.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }

                if (common.isNullOrEmpty(this.reason)) {
                    alert('거절사유를 입력하세요');
                    return false;
                }

                if (!confirm('선택하신 주문건들을 거절처리 하시겠습니까?')) return false;
                common.showLoading();
                axios.post('/api/OrderSearch/Cancel', items).then(function (response) {
                    alert('거절 처리되었습니다.');
                    appOrderSearch.closeReasonLayer();
                    appOrderSearch.search();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getOrderDate: function (_callback) {
                common.showLoading();
                axios.get('/api/OrderSearch/OrderDate').then(function (response) {
                    appOrderSearch._data.srch.endDate = (response.data + '').displayDate('-');
                    if (_callback !== undefined && typeof (_callback) == 'function') _callback();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getMsg: function (master) {
                var firstItem = master.detail.list[0] || null;
                if (firstItem === null) return '';
                var msg = '';
                msg = !common.isNullOrEmpty(firstItem.note) ? firstItem.note : '';
                if (msg != '' && !common.isNullOrEmpty(firstItem.retMsg)) msg += ' / ';
                msg += !common.isNullOrEmpty(firstItem.retMsg) ? firstItem.retMsg : '';
                return msg;
            },
            getIfOrdNum: function (master) {
                return master.detail.list.length > 0 ? master.detail.list[0].eo160.eo16IfOrdNum : '';
            },
            sumScrtAmt: function (master) {
                var sumAmt = 0;
                for (var ii = 0, l = master.detail.custScrt.length; ii < l; ii++) {
                    sumAmt += master.detail.custScrt[ii].scrtAmt;
                }
                return sumAmt.toLocaleFixed();
            },
            getVenInfo: function (item) {
                common.showLoading();
                axios.get('/api/OrderSearch/VenInfo?venCd=' + item.revenCd.trim()).then(function (response) {
                    item.detail.venInfo = response.data;
                    appOrderSearch.$forceUpdate();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getCustScrt: function (item) {
                common.showLoading();
                axios.get('/api/OrderSearch/CustScrt?venCd=' + item.revenCd.trim()).then(function (response) {
                    item.detail.custScrt = response.data;
                    appOrderSearch.$forceUpdate();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            modify: function () {
                var items = this.getSelectedItemsForMod();
                if (items.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }

                if (!confirm('선택하신 주문건을 수정처리 하시겠습니까?')) return false;
                var cnt = 0;
                for (var ii = 0, l = items.length; ii < l; ii++) {
                    common.showLoading();
                    axios.put('/api/OrderSearch', items[ii].detail).then(function (response) {
                        cnt++;
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                        if (common._processing <= 0 && items.length == cnt) {
                            alert('수정 완료되었습니다.');
                            appOrderSearch.search();
                        }
                    });
                }
            },
            remove: function () {
                var eo150 = [];
                var cntAlready = 0;
                var msg = appHeader.isUser() ? '취소' : '삭제';

                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];

                    if (item.selected != 'Y') continue;

                    if (item.maxReDi != '1') {
                        cntAlready++;
                        item.selected = '';
                        continue;
                    }

                    eo150.push({
                        eo15ReYyMmDd: item.reYyMmDd,
                        eo15RevenCd: item.revenCd,
                        eo15ReSeq: item.reSeq
                    });
                }
                if (cntAlready > 0) {
                    alert('이미 처리된 건은 처리할 수 없습니다.');
                }
                if (eo150.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return;
                }
                if (!confirm('선택한 주문건을 ' + msg +'하시겠습니까?')) return;

                common.showLoading();
                var _this = this;
                axios.post('/api/OrderSearch/Delete', eo150).then(function (response) {
                    if (eo150.length != parseInt(response.data)) {
                        if (parseInt(response.data) > 0) {
                            alert(msg +'하지 못한 항목이 있습니다.');
                        }
                        else {
                            alert(msg +'하지 못했습니다.');
                        }
                    }
                    _this.getList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            sort: function (st) {
                if (this.list.length <= 0) return;
                this.sortFlag = this.sortType === st && this.sortFlag === 'ASC' ? 'DESC' : 'ASC';   //현재 설정된 정렬구분을 다시 클릭하는 경우만 desc로 변경, 나머지는 무조건 ASC
                this.sortType = st;

                var sf = this.sortFlag;

                this.list.sort(function (a, b) {
                    if (sf === 'ASC') {
                        return a[st] < b[st] ? -1 : a[st] > b[st] ? 1 : 0;
                    } else {
                        return a[st] < b[st] ? 1 : a[st] > b[st] ? -1 : 0;
                    }
                });
            },
            getDropTel: function (master) {
                return master.detail.list.length > 0 ? master.detail.list[0].eo031.eo31Tel : '';
            },
            getSelectedItemsForCancelConfirm: function () {
                var items = [];
                var cntNotConfirm = 0;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];
                    
                    if (item.selected != 'Y') continue;
                    if (common.isNullOrEmpty(item.ifOrdNum)) {
                        cntNotConfirm++;
                        item.selected = '';
                        continue;
                    }
                    items.push({
                        eo15ReYyMmDd: item.reYyMmDd,
                        eo15RevenCd: item.revenCd,
                        eo15ReSeq: item.reSeq,
                    });
 
                }
                if (cntNotConfirm > 0) {
                    alert('승인된 건만 취소할 수 있습니다.');
                }
                return items;
            },
            cancelConfirm: function () {
                var items = this.getSelectedItemsForCancelConfirm();
                if (items.length <= 0) {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }

                if (!confirm('선택하신 주문건들을 승인취소 하시겠습니까?')) return false;
                common.showLoading();
                var _this = this;
                axios.post('/api/OrderSearch/CancelConfirm', items).then(function (response) {
                    alert('승인 취소 처리되었습니다.');
                    _this.search();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.endDate; // 현재일자로 고정요청하심.
            this.srch.endDate = opt.endDate;
            this.confirmDate = opt.endDate;
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            var obj = this;
            
            evtBus.$on('IsLogin', function (response) {
                
                if (obj.srch.venCd != '') obj.getVenList();
                else {
                    if (response.userKind == 'U') obj.getDropList();
                    else common.hideLoading();
                }
            });
            
        },
        computed: {
            isAdmin: function () {
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            },
            isUser: function () {
                return appHeader.isUser();
            },
            isViewVen: function () {
                var ret = appHeader.isAdmin() || appHeader.isSales();
                this.columnCnt = ret ? 16 : 11;
                return ret;
            },
            sumSupplyPrice: function () {
                return this.list.length <= 0 ? 0 : this.list[0].sumSupplyPrice.toLocaleFixed();
            },
            sumTaxPrice: function () {
                return this.list.length <= 0 ? 0 : this.list[0].sumTaxPrice.toLocaleFixed();
            },
            sumPrice: function () {
                return this.list.length <= 0 ? 0 : this.list[0].sumTotPrice.toLocaleFixed();
            },
        },
    });
}
if (document.getElementById("appNotice")) {
    var appNotice = new Vue({
        el: '#appNotice',
        data: {
            srch: {
                type: 'title',
                word: '',
                page: 1
            },
            page: common.pageObj,
            list: [],
            currPage: 1,
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/notice', { params: param }).then(function (response) {

                    var __data = appNotice._data;

                    __data.list = response.data.list;
                    if (__data.list.eo060 == null) __data.list.eo060 = {};

                    common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    __data.currPage = param.page;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getWriterName: function (item) {
                return '관리자';
            },
            view: function (item) {
                location.href = '/Notice/V/' + item.eoNotice.eobdNum + '?' + common.setParamsFromObj(this.srch);
            },
            rowNum: function (idx) {
                return common.displayRowNumber(this.page.totalCount, this.currPage, this.page.pageSize, idx);
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
        computed: {
            isAdmin: function () {
                return appHeader.isSuperAdmin();
            },
        },
    });
}
if (document.getElementById("appNoticeWrite")) {
    var appNoticeWrite = new Vue({
        el: '#appNoticeWrite',
        data: {
            notice: {},
            id: '',
            file: null,
        },
        methods: {
            view: function () {
                common.showLoading();
                axios.get('/api/notice/' + this.id).then(function (response) {
                    appNoticeWrite._data.notice = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            goList: function () {
                location.href = '/notice' + location.search;
            },
            save: function () {
                if (common.isNullOrEmpty(this.notice.eobdTitle)) {
                    alert('제목을 입력하세요');
                    return false;
                }
                if (common.isNullOrEmpty(this.notice.eobdContent)) {
                    alert('내용을 입력하세요');
                    return false;
                }

                if (!confirm('저장하시겠습니까?')) return false;
                common.showLoading();

                var formData = new FormData();
                formData.append("title", this.notice.eobdTitle);
                formData.append("content", this.notice.eobdContent);
                formData.append("file", this.file);

                if (this.id) {
                    axios.put('/api/notice/' + this.id, formData, {
                        headers: {
                            'Content-Type': ' multipart/form-data',
                        }
                    }).then(function (response) {
                        appNoticeWrite.goList();
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    axios.post('/api/notice', formData, {
                        headers: {
                            'Content-Type': ' multipart/form-data',
                        }
                    }).then(function (response) {
                        appNoticeWrite.goList();
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                }
            },
            fileChange: function (e) {
                this.file = e.target.files[0];
            },
            remove: function () {
                if (!confirm('삭제하시겠습니까?')) return false;
                axios.delete('/api/notice/' + this.id).then(function (response) {
                    appNoticeWrite.goList();
                }).catch(common.errorMessage).finally(common.hideLoading);
            },
            getFileName: function () {
                var aryFileName = this.notice.eobdFileName.split('\\');

                return aryFileName[aryFileName.length - 1] + '(' + common.byteCalculation(this.notice.eobdFileSize) + ')';
            },
            removeFile: function () {
                if (!confirm('첨부파일을 삭제하시겠습니까?')) return false;


                axios.put('/api/Notice/RemoveFile/' + this.id).then(function (response) {
                    appNoticeWrite._data.notice.eobdFileName = '';
                    appNoticeWrite._data.notice.eobdFileSize = '';
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            download: function () {
                var param = this.notice.eobdFileName;
                
                $('#download').attr('src', '/api/notice/Download?fileName=' + encodeURIComponent(param));
            },
        },
        created: function () {
            this.id = common.pathname.split('/V/')[1];
            if (this.id) this.view();
            else common.hideLoading();
        },
        
    });
}
if (document.getElementById("appNoticeView")) {
    var appNoticeView = new Vue({
        el: '#appNoticeView',
        data: {
            notice: {},
            id: '',
            file:null,
        },
        methods: {
            view: function () {
                common.showLoading();
                axios.get('/api/notice/' + this.id).then(function (response) {
                    appNoticeView._data.notice = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            goList: function () {
                location.href = '/notice' + location.search;
            },
            
            getFileName: function () {
                var aryFileName = this.notice.eobdFileName.split('\\');
                
                return aryFileName[aryFileName.length-1] +'('+common.byteCalculation(this.notice.eobdFileSize) +')';
            },
            download: function () {
                var param = this.notice.eobdFileName;
                $('#download').attr('src', '/api/notice/Download?fileName=' + encodeURIComponent(param));
            },
         
        },
        created: function () {
            this.id = common.pathname.split('/V/')[1];
            if (this.id) this.view();
        },
        
    });
}
if (document.getElementById("appStock")) {
    var appStock = new Vue({
        el: '#appStock',
        data: {
            srch: {
                stockMonth: '',
                venNm: '',
                venCd: '',
                page: 1
            },
            page: common.pageObj,
            stock: {
                list: []
            },
            vendor: {
                list: []
            },
            isShowPopup: false,
            uploaded: {
                startDate: '',
                endDate: '',
                list: []
            },
            userFlag: null,
        },
        filters: {
            comma: function(val) {
                return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            },
            formatDate: function(val) {
                if (val !== undefined && val.length == 6) {
                    return val.substr(0, 4) + '.' + val.substr(4, 2);
                }
            }
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            updateStockMonth: function (d) {
                this.srch.stockMonth = d;
            },
            searchVen: function () {
                common.showLoading();
                var param = this.srch.venCd;

                if (param.length > 0) {
                    axios.get('/api/Common/GetVendors', { params: { searchText: param } })
                        .then(function (response) {
                            var __data = appStock._data;
                            __data.vendor.list = response.data.list;
                            if (response.data.list.length > 0) __data.srch.venCd = response.data.list[0].eo03VenCd;
                        })
                        .catch(common.errorMessage).finally(function () {
                            common.hideLoading();
                        });
                }
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/Stock/GetEoStocks', { params: param })
                    .then(function (response) {

                        var __data = appStock._data;

                        __data.stock.list = response.data.list;

                        common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);

                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                });
            },
            downloadExcel: function () {
                common.showLoading();
                var param = this.srch;
                var url = '/Stock/DownloadExcelStock';
                var fileName = "재고자료_" + param.stockMonth + ".xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: param,
                    responseType: 'blob',
                })
                    .then(function(response)  {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                });
            },
            downloadSample: function () {
                common.showLoading();
                var url = '/Stock/DownloadExcelSample';
                var fileName = "재고자료_샘플.xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: { sampleType: "stock" },
                    responseType: 'blob',
                })
                    .then(function(response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                });
            },
            downloadStatus: function () {
                common.showLoading();
                var param = {
                    startDate: this.uploaded.startDate.replace(/-/g, ''),
                    endDate: this.uploaded.endDate.replace(/-/g, ''),
                    venCd: '',
                };
                var url = '/Stock/DownloadStatusInfo';
                var fileName = "매출재고자료_업로드현황_" + (new Date().toISOString().substring(0, 10)) + ".xlsx";

                axios({
                    url: url,
                    method: 'GET',
                    params: param,
                    responseType: 'blob',
                })
                    .then(function (response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            showPopup: function (f) {
                var __this = this;

                if (appHeader.isAdmin() || appHeader.isSales()) {
                    if (f === '') return;
                    $("#checkUploadedArea").dialog({
                        resizable: false,
                        width: 400,
                        height: 200,
                        modal: true,
                        title: "e-Order",
                        open: function () {
                            $('#checkUploadedArea').removeClass('hidden');
                        },
                        buttons: {
                            "다운로드": function () {
                                __this.downloadStatus();
                            },
                            "취소": function () {
                                $(this).dialog("close");
                            }
                        }
                    });
                    return;
                }
                if (f === '' && common.getCookie('uploaded') == 'ON') return;

                if (this.uploaded.list.length > 0) {
                    this.isShowPopup = true;
                    return;
                }
                
                var param = {
                    startDate: this.uploaded.startDate.replace(/-/g, ''),
                    endDate: this.uploaded.endDate.replace(/-/g, ''),
                    venCd: this.srch.venCd
                };

                var currDate = param.startDate.replace(/-/g, "");
                var endDate = param.endDate.replace(/-/g, "");

                common.showLoading();
                axios.get('/api/Sale/CheckUpload', { params: param }).then(function (response) {
                    var retList = response.data;

                    while (currDate <= endDate) {

                        var dt = currDate.substring(0, 4) + '-' + currDate.substring(4, 6);
                        var _data = retList.filter(function (x) {
                            return x.yyyymm == currDate;
                        });

                        var item = {
                            yyyyMM: dt,
                            sales: false,
                            stocks: false,
                        };
                        for (var ii = 0, l = _data.length; ii < l; ii++) {
                            var _tmp = _data[ii];
                            if (_tmp.salesCnt > 0) item.sales = true;
                            if (_tmp.stocksCnt > 0) item.stocks = true;
                        }
                        __this.uploaded.list.push(item);

                        var tmp = new Date(dt + '-01');
                        tmp.setMonth(tmp.getMonth() + 1);
                        currDate = tmp.getFullYear() + ("0" + (tmp.getMonth() + 1)).slice(-2);
                    }
                    __this.isShowPopup = true;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            viewFlag: function (f) {
                return f === true ? 'Y' : 'N';
            },
            noMorePopup: function () {
                common.setCookie('uploaded', "ON", 1);
                this.isShowPopup = false;
            },
            closePopup: function () { this.isShowPopup = false; },
            updateChkDateFrom: function (d) { this.uploaded.startDate = d; },
            updateChkDateTo: function (d) { this.uploaded.endDate = d; },
        },
        created: function () {
            var opt = common.getSrchDateOption();

            var tmp = new Date(opt.endDate);
            tmp.setMonth(tmp.getMonth() - 1);
            this.srch.stockMonth = tmp.toISOString().substring(0, 7);
            tmp.setMonth(tmp.getMonth() - 2);
            this.uploaded.startDate = tmp.toISOString().substring(0, 7);
            this.uploaded.endDate = this.srch.stockMonth;

            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
        watch: {
            userFlag: function () {
                if (this.userFlag == true) this.showPopup('');
            },
        },
        computed: {
            isViewVen: function () {
                var ret = appHeader.isAdmin() || appHeader.isSales();
                this.userFlag = appHeader.isUser();
                return ret;
            },
        },
    });
}
if (document.getElementById("appSale")) {
    var appSale = new Vue({
        el: '#appSale',
        data: {
            srch: {
                saleMonth: '',
                venNm: '',
                venCd: '',
                saleVenName: '',
                page: 1
            },
            page: common.pageObj,
            sale: {
                list: []
            },
            vendor: {
                list: []
            },
            isShowPopup: false,
            uploaded: {
                startDate: '',
                endDate: '',
                list: []
            },
            userFlag: null,
        },
        filters: {
            comma: function (val) {
                return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            }
        },
        methods: {
            search: function (newPage) {
                this.srch.page = newPage;
                this.getList();
            },
            updateSaleMonth: function (d) {
                this.srch.saleMonth = d;
            },
            searchVen: function () {
                common.showLoading();
                var param = this.srch.venCd;

                if (param.length > 0) {
                    axios.get('/api/Common/GetVendors', { params: { searchText: param } })
                        .then(function (response) {
                            var __data = appSale._data;
                            __data.vendor.list = response.data.list;
                            if (response.data.list.length > 0) __data.srch.venCd = response.data.list[0].eo03VenCd;
                        })
                        .catch(common.errorMessage).finally(function () {
                            common.hideLoading();
                        });
                }
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/Sale/GetEoSales', { params: param })
                    .then(function (response) {
                        var __data = appSale._data;
                        __data.sale.list = response.data.list;
                        common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    })
                    .catch(common.errorMessage)
                    .finally(function () {
                        common.hideLoading();
                    });
            },
            downloadExcel: function () {
                common.showLoading();
                var param = this.srch;
                var url = '/Stock/DownloadExcelSale';
                var fileName = "매출자료_" + param.saleMonth + ".xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: param,
                    responseType: 'blob',
                })
                    .then(function (response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            downloadSample: function () {
                common.showLoading();
                var url = '/Stock/DownloadExcelSample';
                var fileName = "매출자료_샘플.xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: { sampleType: "sale" },
                    responseType: 'blob',
                })
                    .then(function (response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            downloadStatus: function () {
                common.showLoading();
                var param = {
                    startDate: this.uploaded.startDate.replace(/-/g, ''),
                    endDate: this.uploaded.endDate.replace(/-/g, ''),
                    venCd: '',
                };
                var url = '/Stock/DownloadStatusInfo';
                var fileName = "매출재고자료_업로드현황_" + (new Date().toISOString().substring(0, 10)) + ".xlsx";

                axios({
                    url: url,
                    method: 'GET',
                    params: param,
                    responseType: 'blob',
                })
                    .then(function (response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            showPopup: function (f) {
                var __this = this;

                if (appHeader.isAdmin() || appHeader.isSales()) {
                    if (f === '') return;
                    $("#checkUploadedArea").dialog({
                        resizable: false,
                        width: 400,
                        height: 200,
                        modal: true,
                        title: "e-Order",
                        open: function () {
                            $('#checkUploadedArea').removeClass('hidden');
                        },
                        buttons: {
                            "다운로드": function () {
                                __this.downloadStatus();
                            },
                            "취소": function () {
                                $(this).dialog("close");
                            }
                        }
                    });
                    return;
                }
                if (f === '' && common.getCookie('uploaded') == 'ON') return;

                if (this.uploaded.list.length > 0) {
                    this.isShowPopup = true;
                    return;
                }
                var param = {
                    startDate: this.uploaded.startDate.replace(/-/g, ''),
                    endDate: this.uploaded.endDate.replace(/-/g, ''),
                    venCd: this.srch.venCd
                };

                var currDate = param.startDate.replace(/-/g, "");
                var endDate = param.endDate.replace(/-/g, "");

                common.showLoading();
                axios.get('/api/Sale/CheckUpload', { params: param }).then(function (response) {
                    var retList = response.data;

                    while (currDate <= endDate) {

                        var dt = currDate.substring(0, 4) + '-' + currDate.substring(4, 6);
                        var _data = retList.filter(function (x) {
                            return x.yyyymm == currDate;
                        });

                        var item = {
                            yyyyMM: dt,
                            sales: false,
                            stocks: false,
                        };
                        for (var ii = 0, l = _data.length; ii < l; ii++) {
                            var _tmp = _data[ii];
                            if (_tmp.salesCnt > 0) item.sales = true;
                            if (_tmp.stocksCnt > 0) item.stocks = true;
                        }
                        __this.uploaded.list.push(item);

                        var tmp = new Date(dt + '-01');
                        tmp.setMonth(tmp.getMonth() + 1);
                        currDate = tmp.getFullYear() + ("0" + (tmp.getMonth() + 1)).slice(-2);
                    }
                    __this.isShowPopup = true;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            viewFlag: function (f) {
                return f === true ? 'Y' : 'N';
            },
            noMorePopup: function () {
                common.setCookie('uploaded', "ON", 1);
                this.isShowPopup = false;
            },
            closePopup: function () { this.isShowPopup = false; },
            updateChkDateFrom: function (d) { this.uploaded.startDate = d; },
            updateChkDateTo: function (d) { this.uploaded.endDate = d; },
        },
        created: function () {
            var opt = common.getSrchDateOption();

            var tmp = new Date(opt.endDate);
            tmp.setMonth(tmp.getMonth() - 1);
            this.srch.saleMonth = tmp.toISOString().substring(0, 7);
            tmp.setMonth(tmp.getMonth() - 2);
            this.uploaded.startDate = tmp.toISOString().substring(0,7);
            this.uploaded.endDate = this.srch.saleMonth;

            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();

        },
        watch: {
            userFlag: function () {
                if (this.userFlag == true) this.showPopup('');
            },
        },
        computed: {
            isViewVen: function () {
                var ret = appHeader.isAdmin() || appHeader.isSales();
                this.userFlag = appHeader.isUser();
                return ret;
            },
        },
    });
}
if (document.getElementById("appTransCard")) {

    var appTransCard = new Vue({
        el: '#appTransCard',
        data: {
            srch: {
                startDate: '',
                endDate: '',
                venNm: '',
                venCd: '',
                dropCd: '',
                page: 1,
                venNumCd: '',
                venNum: '',
            },
            page: common.pageObj,
            transCard: {
                list: []
            },
            venGroup: {
                list: [],
            },
            vendor: {
                list: []
            },
            drop: {
                list: []
            },
            selectedVenCd: '',
            selectedDate: '',
            userFlag: null,
        },
        filters: {
            comma: function (val) {
                if (val == undefined || val == null) {
                    return "";
                }
                return String(val).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
            }
        },
        methods: {
            search: function (newPage) {

                if (common.isNullOrEmpty(this.srch.venNum) && this.userFlag === false) {
                    alert("사업자를 선택하고 검색해주십시오.");
                    return false;
                }

                this.srch.page = newPage;
                this.getList();
            },
            updateStartDate: function (d) {
                this.srch.startDate = d;
            },
            updateEndDate: function (d) {
                this.srch.endDate = d;
            },
            isDisabledCheckBox: function (item) {
                if (item.gubun != "A") {
                    return true;
                }
                return false;
            },
            searchVen: function () {
                if (this.userFlag === false && this.venGroup.list.length <= 0) {
                    alert("사업자를 선택하고 검색해주십시오.");
                    return;
                }
                common.showLoading();
                var _this = this;
                axios.get('/api/Common/GetUserVenList?venCd=' + encodeURIComponent(this.srch.venCd) +'&venNum='+ encodeURIComponent(this.srch.venNum)).then(function (response) {
                    var __data = appTransCard._data;
                    __data.vendor.list = response.data;
                    __data.srch.venCd = response.data.length > 0 ? response.data[0].eo03VenCd : '';
                    if (response.data.length > 0 && _this.userFlag === true || !common.isNullOrEmpty(_this.srch.venNum)) {
                        _this.search();
                    }
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                param.pageSize = this.page.pageSize;

                axios.get('/api/TransCard/GetTransCards', { params: param })
                    .then(function (response) {
                        var __data = appTransCard._data;
                        __data.transCard.list = response.data.list;

                        for (var ii = 0, l = __data.transCard.list; ii < l; ii++) {
                            __data.transCard.list[ii].chked = false;
                        }

                        common.setPagingInfo(__data.page, __data.srch.page, response.data.count, constants.pageSize, constants.pageCol);
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            toggleSelect: function (item) {

                var itemSelected = item.selected;

                for (var ii = 0, l = this.transCard.list.length; ii < l; ii++) {
                    this.transCard.list[ii].selected = '';
                }

                item.selected = itemSelected == 'Y' ? '' : 'Y';
                this.selectedVenCd = '';
                if (item.selected == 'Y') {
                    this.selectedVenCd = item.custCd.trim();
                    this.selectedDate = item.salDate.replace(/\./g, '');
                }
            },
            downloadExcel: function () {
                common.showLoading();
                var param = this.srch;
                var url = '/TransCard/DownloadExcel';
                var fileName = "거래원장_" + param.startDate + "-" + param.endDate + ".xlsx";
                axios({
                    url: url,
                    method: 'GET',
                    params: param,
                    responseType: 'blob',
                })
                    .then(function (response) {
                        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                            // IE에서 동작
                            window.navigator.msSaveBlob(new Blob([response.data]), fileName);

                        } else {
                            var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                            var fileLink = document.createElement('a');

                            fileLink.href = fileURL;
                            fileLink.setAttribute('download', fileName);
                            document.body.appendChild(fileLink);

                            fileLink.click();
                        }
                    })
                    .catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
            },
            changeVenGroup: function () {
                var venNum = this.srch.venNum;
                var item = this.venGroup.list.filter(function (x) {
                    return x.eo03VenNum == venNum;
                });
                this.srch.venCd = "";
                this.srch.venNumCd = item[0].eo03VenCd;
                appTransCard.searchVen();
            },
            searchVenGroup: function () {
                common.showLoading();
                axios.get('/api/Common/GetVenGroupList?venNumCd=' + encodeURIComponent(this.srch.venNumCd)).then(function (response) {
                    var __data = appTransCard._data;
                    __data.venGroup.list = response.data;
                    __data.srch.venNum = response.data.length > 0 ? response.data[0].eo03VenNum : '';
                    appTransCard.changeVenGroup();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.startDate;
            this.srch.endDate = opt.endDate;

            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
        },
        watch: {
            userFlag: function () {
                if (this.userFlag == true) this.searchVen();
                else common.hideLoading();
            },
        },
        computed: {
            isAdmin: function () {
                this.userFlag = appHeader.isUser();
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            }
        }
    });
}

if (document.getElementById("appProductPrice")) {
    var appProductPrice = new Vue({
        el: '#appProductPrice',
        data: {
            srch: {
                type: 'nm',
                word: '',
                venCd: '',
                dropCd:'',
            },
            product: {
                list: []
            },
            venList: [],
            dropList: [],
            columnCnt: 11,
            userFlag: null,
            chkAll:false,
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();
                var param = this.srch;

                axios.get('/api/price', { params: param }).then(function (response) {

                    var __data = appProductPrice._data;
                    if (!response.data.list) {
                        __data.product.list = [];
                        return;
                    }
                    for (var ii = 0, l = response.data.list.length; ii < l; ii++)
                        response.data.list[ii].selected = false;

                    __data.product.list = response.data.list;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            rowNum: function (idx) {
                return this.product.list.length - idx;
            },
            viewPrice: function (item) {
                item.realPrice = common.getOrderPrice(constants.bagType.order, item.eo040.eo04InsuPrice, item.eo041.eo041CtrPYl, item.eo041.eo041HpinYl);
                return item.realPrice.toLocaleFixed();
            },
            getVenList: function () {
                common.showLoading();

                axios.get('/api/Common/GetUserVenList?venCd=' + encodeURIComponent(this.srch.venCd) ).then(function (response) {
                    appProductPrice._data.venList = response.data;
                    appProductPrice._data.srch.venCd = response.data.length > 0 ? response.data[0].eo03VenCd : '';
                    appProductPrice.getDropList();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getDropList: function () {
                common.showLoading();
                var param = {
                    venCd: this.srch.venCd
                };
                axios.get('/api/Common/GetDropListForVen?' + common.setParamsFromObj(param)).then(function (response) {
                    appProductPrice._data.dropList = response.data;
                    appProductPrice._data.srch.dropCd = '';
                    appProductPrice.search();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            save: function (item) {
                if (!confirm('수정하시겠습니까?')) return;

                common.showLoading();
                axios.put('/api/price', item.eo041).then(function (response) {
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getSelectedItem: function () {
                var selected = [];
                for (var ii = 0, l = this.product.list.length; ii < l; ii++) {
                    var _item = this.product.list[ii];
                    if (_item.selected) selected.push(_item.eo041);
                }
                return selected;
            },
            modify: function () {
                var items = this.getSelectedItem();

                if (items.length <= 0) {
                    alert('선택하신 항목이 없습니다.');
                    return;
                }
                common.showLoading();
                var _this = this;
                axios.post('/api/price', items).then(function (response) {
                    alert('저장되었습니다.');
                    for (var ii = 0, l = _this.product.list.length; ii < l; ii++) {
                        _this.product.list[ii].selected = false;
                    }
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            toggleSelect: function (item) {
                item.selected = !item.selected;
            },
            toggleChkAll: function () {
                var newChkAll = !this.chkAll;
                for (var ii = 0, l = this.product.list.length; ii < l; ii++) {
                    this.product.list[ii].selected = newChkAll;
                }
                this.chkAll = newChkAll;
            },
        },
        watch: {
            userFlag: function () {
                this.columnCnt = this.userFlag == true ? 11 : 15;
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getVenList();
        },
        computed: {
            isAdmin: function () {
                this.userFlag = appHeader.isUser();
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            },
            venCdClass: function () {
                return appHeader.isAdmin() || appHeader.isSales() ? 'nm' : 'nm withNoSearch';
            }
        }
    });
}
if (document.getElementById("appInventory")) {
    var appInventory = new Vue({
        el: '#appInventory',
        data: {
            srch: {
                type: 'nm',
                word: ''
            },
            product: {
                list: []
            },
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                
                common.showLoading();
                var param = this.srch;

                axios.get('/api/inventory', { params: param }).then(function (response) {

                    var __data = appInventory._data;

                    __data.product.list = response.data.list;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            rowNum: function (idx) {
                return this.product.list.length - idx;
            },
            displayStock: function (item) {
                return item.storQty > 0 ? 'O' : 'X';
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appOrderSearchPrint")) {
    var appOrderSearchPrint = new Vue({
        el: '#appOrderSearchPrint',
        data: {
            srch: {
                sd: '',
                ed: '',
                vc: '',
                dc:'',
                dt: '',
                s:''
            },
            list: [],
        },
        methods: {
            getList: function () {
                common.showLoading();
                var param = [];
                var qry = {
                    startDate: this.srch.sd,
                    endDate: this.srch.ed,
                    venCd: this.srch.vc,
                    dropCd: this.srch.dc
                };
                var aryDt = this.srch.dt.split(',');
                var arySeq = this.srch.s.split(',');
                for (var ii = 0, l = aryDt.length; ii < l; ii++) {
                    param.push({
                        eo15ReYyMmDd: aryDt[ii],
                        eo15ReSeq: arySeq[ii]
                    });
                }
                axios.post('/api/OrderSearch/GetData?' + common.setParamsFromObj(qry), param).then(function (response) {
                    var preOrder = {
                        dt: '',
                        seq:0
                    };
                    var lists = [];
                    var data = {
                        info: null,
                        detail:[]
                    };

                    for (var ii = 0, l = response.data.list.length; ii < l; ii++) {
                        var item = response.data.list[ii];
                        
                        if (item.eo150.eo15ReYyMmDd != preOrder.dt || item.eo150.eo15ReSeq != preOrder.seq) {
                            preOrder.dt = item.eo150.eo15ReYyMmDd;
                            preOrder.seq = item.eo150.eo15ReSeq;
                            if (data.info != null) lists.push(data);
                            data = {info:null, detail:[]};
                        }
                        if (data.info == null) {
                            data.info = {};
                            data.info.orderNumber = item.eo150.eo15ReYyMmDd + item.eo150.eo15ReSeq;
                            data.info.eo030 = item.eo030;
                            data.info.eo031 = item.eo031;
                            data.info.eo150 = item.eo150;
                        }
                        
                        data.detail.push({
                            eo160: item.eo160,
                            eo040: item.eo040,
                            eo010: item.eo010
                        });
                        
                    }
                    if (data.info != null) lists.push(data);
                    appOrderSearchPrint._data.list = lists;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                    window.print();
                });
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getList();
        },
    });
}
if (document.getElementById("appTrans")) {
    var appTrans = new Vue({
        el: '#appTrans',
        data: {
            srch: {
                venCd: '',
                ordNo: '',
                salprssGb: '',
                startDate: '',
                endDate: '',
            },
            list: [],
            venList: [],
            chkAll: false,
            columnCnt: 10,
            userFlag: null,
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();

                var param = this.srch;

                axios.get('/api/Trans?' + common.setParamsFromObj(param)).then(function (response) {

                    var __data = appTrans._data;
                    var list = response.data.list;
                    for (var ii = 0, l = list.length; ii < l; ii++) {
                        list[ii].selected = '';
                        list[ii].info = {
                            detail: [],
                        };
                    }
                    __data.list = list;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getSelectedItemsForPrint: function () {
                var aryOrdNo = [];

                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var item = this.list[ii];

                    if (item.selected != 'Y') continue;
                    aryOrdNo.push(item.ordNo.trim());
                }
                if (aryOrdNo.length <= 0) return '';
                return 'ordNo=' + aryOrdNo.join(',');
            },
            print: function () {
                var param = this.getSelectedItemsForPrint();
                if (param == '') {
                    alert('선택된 주문건이 없습니다.');
                    return false;
                }
                window.open('/Transaction/Print?' + param, 'printPopup', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=1100,height=800');
            },
            updateStartDate: function (d) {
                this.srch.startDate = d;
            },
            updateEndDate: function (d) {
                this.srch.endDate = d;
            },
            setVenCd: function (venCd) {
                this.srch.venCd = venCd;
            },
            getVenList: function (e) {
                common.showLoading();

                axios.get('/api/Common/GetVenList?venCd=' + encodeURIComponent(this.srch.venCd)).then(function (response) {
                    appTrans._data.venList = response.data;
                    if (response.data.length > 0) appTrans.setVenCd(response.data[0].eo03VenCd);
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            toggleChkAll: function () {
                var newChkAll = !this.chkAll;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    this.list[ii].selected = newChkAll ? 'Y' : '';
                }
                this.chkAll = newChkAll;
            },
            toggleSelect: function (item) {
                item.selected = item.selected == 'Y' ? '' : 'Y';
            },
            showCalander: function (e) {
                $(e.target).siblings('input').focus();
            },
            rowNum: function (idx) {
                return this.list.length - idx;
            },
            viewDetail: function (item, index) {
                var target = appTrans.$refs.items[index].nextElementSibling;

                if (item.info.detail.length > 0) {
                    if (target.className.indexOf('hidden') < 0) {
                        target.className = 'hidden detailArea';
                        return;
                    }

                    if (item.info.detail.length > 0) {
                        target.className = 'detailArea';
                        return;
                    }
                }

                common.showLoading();
                axios.get('/api/Trans/' + item.ordNo).then(function (response) {
                    item.info = response.data[0];
                    target.className = 'detailArea';

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.startDate;
            this.srch.endDate = opt.endDate;

            if (location.search !== '') this.srch = common.setObjFromParams(location.search);

        },
        watch: {
            userFlag: function () {
                if (this.userFlag == true) this.getList();
                else this.getVenList();
            },
        },
        computed: {
            isAdmin: function () {
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            },
            isViewVen: function () {
                var ret = appHeader.isAdmin() || appHeader.isSales();
                this.columnCnt = ret ? 10 : 9;
                this.userFlag = appHeader.isUser();
                return ret;
            },
        },

    });
}
if (document.getElementById("appTransPrint")) {
    var appTransPrint = new Vue({
        el: '#appTransPrint',
        data: {
            itemCnt: 10,
            srch: {},
            info: {},
            list:[],
        },
        methods: {
            getData: function () {
                common.showLoading();
                axios.get('/api/Trans/' + this.srch.ordNo).then(function (response) {
                    var __data = appTransPrint._data;
                    for (var ii = 0, l = response.data.length; ii < l; ii++) {
                        var items = response.data[ii];
                        
                        for (var jj = 0, ll = items.detail.length; jj < ll; jj++) {
                            var item = items.detail[jj];
                            if (item.chbGb == '1') {
                                items.chb1 += item.salTmc;
                            } else {
                                items.chb2 += item.salTmc;
                            }
                        }
                    }

                    __data.info = response.data;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                    window.print();
                });
            },
            getDividePageCnt: function (items) {
                return items.page > 1 ? Math.floor(items.page /2) : 1;
            },
            getPlantNm: function (items) {
                return constants.plantInfo[items.plantCd];
            },
            displayVenNum: function (items) {
                return items.businNo.displayVenNum();
            },
            currPageItems: function (details, page) {
                return details.slice((page - 1) * this.itemCnt, page * this.itemCnt);
            },
            currPageEmptyItemCnt: function (items, page) {
                return items.cnt > page * this.itemCnt ? 0 : 10 - items.cnt % this.itemCnt;
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getData();
        },
    });
}
if (document.getElementById("appPrintReceive")) {
    var appPrintReceive = new Vue({
        el: '#appPrintReceive',
        data: {
            srch: {},
            list: [],
        },
        methods: {
            getData: function () {
                common.showLoading();
                var __data = this;
                axios.get('/api/CollectMoney/GetPrintData', { params: this.srch }).then(function (response) {
                    if (response.data.length <= 0) {
                        alert('등록된 수금요청서가 없습니다. [' + __data.srch.dt.substring(0, 4) + '년' + __data.srch.dt.substring(4, 6) + '월]');
                        self.close();
                    }
                    __data.list = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                    window.print();
                });
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.getData();
        },
    });
}
if (document.getElementById("appReturn")) {
    var appReturn = new Vue({
        el: '#appReturn',
        data: {
            isShowProductInfo: false,
            srch: {
                venCd: '',
                dropCd: '',
                type: '',
                phyNm: '',
                bagType: constants.bagType.return,
            },
            product: {
                list: [],
                view: {
                    info: {},
                    orderedList: [],
                    avgQty: 0,
                    sumPrice: 0
                },
            },
            venList: [],
            dropList: [],
            memo: {},
            popup: [],
        },
        methods: {
            search: function () {
                this.getList();
            },
            getList: function () {
                common.showLoading();
                this.isShowProductInfo = false;
                var param = this.srch;

                axios.get('/api/Order', { params: param }).then(function (response) {
                    var __data = appReturn._data;
                    if (response.data.list == null) response.data.list = [];

                    __data.product.list = response.data.list;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            viewDetail: function (item) {
                common.showLoading();
                this.product.view.info = item.eo040;
                var param = 'venCd=' + this.srch.venCd + '&dropCd=' + this.srch.dropCd + '&physicCd=' + item.eo040.eo04PhysicCd;
                axios.get('/api/Order/OrderedList?' + param).then(function (response) {
                    appReturn._data.product.view.orderedList = response.data;
                    var sumQty = 0;
                    var monthPrice = 0;
                    var today = new Date();
                    var currMonth = today.getFullYear() + ('0' + (today.getMonth() + 1)).substring(-2);
                    for (var ii = 0, l = response.data.length; ii < l; ii++) {
                        var item = response.data[ii];
                        sumQty += item.eo16Quantity;
                        if (item.eo16ReYyMmDd.substring(0, 6) == currMonth) monthPrice += (item.eo16SupplyPrice + item.eo16TaxPrice);
                    }
                    appReturn._data.product.view.avgQty = sumQty > 0 ? sumQty / response.data.length : 0;
                    appReturn._data.product.view.sumPrice = monthPrice;
                    appReturn._data.isShowProductInfo = true;

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            hideDetail: function () {
                this.isShowProductInfo = false;
            },
            insertBagProc: function (param, _callback) {
                common.showLoading();
                axios.post('/api/Bag', param).then(function (response) {
                    appBag.getBagList();
                    if (_callback !== undefined && typeof _callback == 'function') _callback();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            insertBag: function (e, item) {

                if (e.keyCode != 13) return;
                if (item.realPrice <= 0) {
                    alert('단가를 확인해주세요.\n' + item.eo040.eo04PhysicNm);
                    return false;
                }
                var param = [{
                    eobgType: this.srch.bagType,
                    eobgVenCd: item.eo041.eo041VenCd,
                    eobgDropCd: item.eo041.eo041DropCd,
                    eobgPhysicCd: item.eo040.eo04PhysicCd,
                    eobgPrice: item.realPrice,
                    eobgQty: parseInt(item.qty)
                }];

                this.insertBagProc(param, function () {
                    item.qty = '';
                });
            },
            insertBagAll: function () {
                var param = [];
                var notValid = [];
                for (var ii = 0, l = this.product.list.length; ii < l; ii++) {
                    var item = this.product.list[ii];
                    if (common.isNullOrEmpty(item.qty) || parseInt(item.qty) <= 0) continue;
                    if (item.realPrice <= 0) {
                        notValid.push(item.eo040.eo04PhysicNm);
                        continue;
                    }
                    param.push({
                        eobgType: this.srch.bagType,
                        eobgVenCd: item.eo041.eo041VenCd,
                        eobgDropCd: item.eo041.eo041DropCd,
                        eobgPhysicCd: item.eo040.eo04PhysicCd,
                        eobgPrice: item.realPrice,
                        eobgQty: parseInt(item.qty)
                    });
                    item.qty = '';
                }
                if (notValid.length > 0) {
                    alert('단가를 확인해주세요.\n' + notValid.join('\n'));
                    return false;
                }
                this.insertBagProc(param, function () {

                });
            },
            getVenList: function (e) {
                common.showLoading();

                axios.get('/api/Common/GetVenList?venCd=' + encodeURIComponent(this.srch.venCd)).then(function (response) {
                    appReturn._data.venList = response.data;
                    if (response.data.length > 0) appReturn.setVenCd(response.data[0].eo03VenCd);
                    else alert('조회가능한 거래처가 없습니다.');
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeVenCd: function () {
                this.getDropList();
                appBag.getBagList();
            },
            setVenCd: function (venCd) {
                this.srch.venCd = venCd;
                this.$refs.selectVenCd.focus();
                this.changeVenCd();
            },
            setDropCd: function (dropCd) {
                this.srch.dropCd = dropCd;
                this.changeDropCd(dropCd);
            },
            getDropList: function () {
                common.showLoading();
                var param = {
                    venCd: this.srch.venCd
                };
                axios.get('/api/Common/GetDropList?' + common.setParamsFromObj(param)).then(function (response) {
                    appReturn._data.dropList = response.data;
                    if (response.data.length > 0) appReturn.setDropCd(response.data[0].eo31DropCd);
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getMemo: function () {
                common.showLoading();
                axios.get('/api/Order/OrderMemo').then(function (response) {
                    appReturn._data.memo = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeDropCd: function (dropCd) {
                this.search(1);
                var obj = this.dropList.filter(function (x) {
                    return x.eo31DropCd == dropCd;
                });
                appBag.changeDrop(obj);
            },
            changeInterest: function (item) {
                var params = {
                    eo43VenCd: this.srch.venCd,
                    eo43PhysicCd: item.eo040.eo04PhysicCd
                };
                if (item.eo043 === null) {
                    axios.post('/api/Order/Interest', params).then(function (response) {
                        item.eo043 = response.data;
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                } else {
                    axios.delete('/api/Order/Interest', { data: params }).then(function (response) {
                        item.eo043 = null;
                    }).catch(common.errorMessage).finally(function () {
                        common.hideLoading();
                    });
                }
            },
            viewStock: function (item) {
                try {
                    return item.stock.storQty > 0 ? 'O' : 'X';
                } catch (e) {
                    return 'X';
                }
            },
            viewPrice: function (item) {
                item.realPrice = common.getOrderPrice( this.srch.bagType, item.eo040.eo04InsuPrice, item.eo041.eo041CtrPYl, item.eo041.eo041HpinYl);
                return item.realPrice.toLocaleFixed();
            },
        },
        created: function () {
            this.getDropList();
            this.getMemo();
        },
        computed: {
            isAdmin: function () {
                return appHeader.isAdmin();
            },
            isSales: function () {
                return appHeader.isSales();
            },
        },
    });
}
if (document.getElementById("appBag")) {
    var appBag = new Vue({
        el: '#appBag',
        data: {
            list: [],
            memo: '',
            addr: '',
            isShowAnnounce: false,
        },
        methods: {
            getOrderParam: function () {
                var obj = appOrder || appReturn;
                var srch = obj._data.srch;
                return {
                    venCd: srch.venCd,
                    bagType: srch.bagType
                };
            },
            getBagList: function (e) {

                common.showLoading();

                var params = this.getOrderParam();

                axios.get('/api/bag?' + common.setParamsFromObj(params)).then(function (response) {
                    appBag._data.list = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            order: function (e) {
                var fn = appOrder === undefined ? 'ReturnInsert' : appOrder._data.srch.bagType === constants.bagType.order ? 'OrderInsert' : 'RewardInsert';
                
                if (fn === 'ReturnInsert' && common.isNullOrEmpty(this.memo)) {
                    this.isShowAnnounce = true;
                    return false;
                }

                var bag = [];
                var invalidList = [];

                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var group = this.list[ii];

                    for (var jj = 0, k = group.bagList.length; jj < k; jj++) {
                        var item = group.bagList[jj];
                        if (item.eoBag.eobgDelFlag == 'Y') continue;

                        //if (fn === 'OrderInsert' &&
                        //    item.orderedQtyFourMonth != 0 &&
                        //    item.eo041.eo041PossibleQty < parseInt(item.eoBag.eobgQty) + parseInt(item.orderedQty || 0)) {
                        //    invalidList.push(item);
                        //    continue;
                        //}
                        bag.push(item.eoBag);
                    }
                }
                if (invalidList.length > 0) {
                    var msg = invalidList[0].eo040.eo04PhysicNm + (invalidList.length > 1 ? '외 ' + (invalidList.length - 1) + '건' : '') + '이 품목 과다주문으로 주문 불가합니다.';
                    alert(msg);
                    return;
                }
                if (bag.length <= 0) {
                    alert('장바구니가 비어있습니다.');
                    return false;
                }

                if (!confirm('주문하시겠습니까?')) return false;

                common.showLoading();

                var param = {
                    eoBags: bag,
                    memo: this.memo
                };

                axios.post('/api/Order/' + fn, param).then(function (response) {
                    var aryPhyNm = [];
                    for (var ii = 0, l = response.data.length; ii < l; ii++) {
                        aryPhyNm.push(response.data[ii].eo04PhysicNm.trim());
                    }
                    if (aryPhyNm.length > 0) {
                        alert('재고가 부족합니다.\n' + aryPhyNm.join('\n'));
                    } else {
                        appBag.cancelProc();
                    }

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            cancelProc: function () {
                common.showLoading();
                var params = this.getOrderParam();
                var param = {
                    eobgVenCd: params.venCd,
                    eobgType: params.bagType
                };

                axios.delete('/api/bag', { data: param }).then(function (response) {
                    appBag.list = [];
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            cancel: function (e) {
                if (!confirm('장바구니를 비우시겠습니까?')) return false;
                this.cancelProc();
            },
            changeBag: function (item) {
                common.showLoading();
                item.eoBag.eobgDelFlag = item.eoBag.eobgDelFlag == 'Y' ? 'N' : 'Y';

                axios.put('/api/bag/' + item.eoBag.eobgNum, item.eoBag).then(function (response) {
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            viewDetail: function (item) {
                var obj = appOrder || appReturn;
                obj.viewDetail(item);
            },
            modifyBag: function (item) {
                common.showLoading();
                axios.put('/api/bag/' + item.eoBag.eobgNum, item.eoBag).then(function (response) {
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            changeDrop: function (eo031) {
                this.addr = eo031.length > 0 && eo031[0].eo31Address != null ? '(' + eo031[0].eo31ZipCode + ')' + eo031[0].eo31Address : '';
            },
            hideAnnounce: function () {
                this.isShowAnnounce = false;
            },
        },
        created: function () {
            this.getBagList();
        },
        computed: {
            isAdmin: function () {
                return appHeader.isAdmin();
            },
            isUser: function () {
                return appHeader.isUser();
            },
            sumPrice: function () {
                var sum = 0;
                for (var ii = 0, l = this.list.length; ii < l; ii++) {
                    var group = this.list[ii];
                    
                    for (var jj = 0, k = group.bagList.length; jj < k; jj++) {
                        var item = group.bagList[jj].eoBag;
                        if (item.eobgDelFlag != 'Y') sum += item.eobgPrice * item.eobgQty;
                    }
                }
                return sum.toLocaleFixed();
            },
        },
    });
}
if (document.getElementById("appCardPayment")) {
    var appPrintReceive = new Vue({
        el: '#appCardPayment',
        data: {
            srch: {
                type: 'an',
                word: '',
                startDate: '',
                endDate: '',
            },
            constants: {
                email: constants.email,
            },
            list: [],
            payment: {
                ven: {
                    chemical: false,
                    bio: false,
                    dakeda: false
                },
                info: {
                    venCd: '',
                    totalAmount: 0,
                    eocpOrderName: '',
                    eocpEmail: '',
                    installMonth: 0
                },
                targetMonth: '',
            },
            frm: {
                email1: '',
                email2: '',
            },
            payList: [],
        },
        methods: {
            search: function () {
                common.showLoading();
                var _this = this;
                axios.get('/api/card/cardPaymentList', { params: this.srch } ).then(function (response) {
                    _this.list = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            updateStartDate: function (d) { this.srch.startDate = d; },
            updateEndDate: function (d) { this.srch.endDate = d; },
            showCalander: function (e) { $(e.target).siblings('input').focus(); },
            showPay: function () {
                var _this = this;
                this.getPayInfo(function () {
                    $("#areaCardPayment").dialog({
                        resizable: false,
                        width: 600,
                        height: 435,
                        modal: true,
                        title: "e-Order",
                        open: function () {
                            $(this).removeClass('hidden');
                        },
                        buttons: {
                            'prev': {
                                text: '이전',
                                id: 'btn_prev',
                                click: function () {
                                    var $dialog = $(this).closest('.ui-dialog');
                                    $dialog.find('.ui-button#btn_next').removeClass('hidden');
                                    $dialog.find('.ui-button#btn_prev').addClass('hidden');
                                    $dialog.find('.ui-button#btn_confirm').addClass('hidden');
                                    $dialog.find('.step1').removeClass('hidden');
                                    $dialog.find('.step2').addClass('hidden');
                                }
                            },
                            'next': {
                                text: '다음',
                                id: 'btn_next',
                                click: function () {
                                    var $dialog = $(this).closest('.ui-dialog');
                                    $dialog.find('.ui-button#btn_next').addClass('hidden');
                                    $dialog.find('.ui-button#btn_prev').removeClass('hidden');
                                    $dialog.find('.ui-button#btn_confirm').removeClass('hidden');
                                    $dialog.find('.step1').addClass('hidden');
                                    $dialog.find('.step2').removeClass('hidden');
                                }
                            },
                            'confirm': {
                                text: '승인요청',
                                id: 'btn_confirm',
                                click: _this.pay
                            },
                            '취소': function () {
                                $(this).addClass('hidden');
                                $(this).dialog("close");
                            },
                        },
                        create: function () {
                            var $dialog = $(this).closest('.ui-dialog');
                            $dialog.find('.ui-button#btn_next').removeClass('hidden');
                            $dialog.find('.ui-button#btn_prev').addClass('hidden');
                            $dialog.find('.ui-button#btn_confirm').addClass('hidden');
                            $dialog.find('.step1').removeClass('hidden');
                            $dialog.find('.step2').addClass('hidden');
                        }
                    });
                });
            },
            getPayInfo: function (_callback) {
                common.showLoading();
                var _this = this;
                axios.get('/api/card/payinfo').then(function (response) {

                    if (response.data.length <= 0) {
                        alert('결제 대상이 없습니다.');
                        return;
                    }
                    var today = new Date();
                    today.setMonth(today.getMonth() - 1);
                    _this.payment.targetMonth = today.toISOString().substring(0, 7);
                    _this.payList = response.data;
                    if (_callback !== undefined && typeof _callback == 'function') _callback();
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            getVenItem: function (t) {
                return this.payList.filter(function (x) {
                    return common.IsExactVenType(x.venCd, t);
                });
            },
            changeVenType: function (t) {
                this.payment.ven.chemical = t === 'chemical' ? true : false;
                this.payment.ven.bio = t === 'bio' ? true : false;
                this.payment.ven.dakeda = t === 'dakeda' ? true : false;

                var venItem = this.getVenItem(t);

                if (venItem.length <= 0) return;
                this.payment.info.venCd = venItem[0].venCd.trim();
                this.payment.info.totalAmount = venItem[0].price;
            },
            exceldown: function () {
                var fileName = "결제목록_" + common.getToday() + ".xlsx";
                common.excelDownload('/api/card/ExcelDown', this.srch, fileName);
            },
            pay: function () {
                var email = this.frm.email1 + '@' + this.frm.email2;
                var param = {
                    "userName": this.payment.info.eocpOrderName,
                    "userEmail": email.length > 1 ? email : '',
                    "productName": "정기결제 " + this.payment.targetMonth,
                    "totalAmount": this.payment.info.totalAmount,
                    "payload": this.payment.targetMonth.replace(/-/g, '') + '|' + this.payment.info.venCd,
                    "cardNumb": this.payment.info.cardNumb.replace(/-/g, ''),
                    "expiryDate": this.payment.info.expiryDate,
                    "installMonth": this.payment.info.installMonth
                };
                common.showLoading();
                axios.post('/api/card/pay', param).then(function (response) {
                    if (response.data.code === constants.payRespCode.success) {
                        alert('정상처리되었습니다.');
                        $("#areaCardPayment").dialog("close");
                    } else if (response.data.code === constants.payRespCode.errKSnetServer) {
                        alert('결제서버 오류입니다. 담당자에게 문의하세요.');
                    } else {
                        alert('결제에 실패하였습니다. 담당자에게 문의하세요.');
                    }
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });

            },
            getPayType: function (item) {
                return item.code == 'A0200' ? "정상결제" : "결제실패";
            },
            getVenType: function (item) {
                return common.getVenType(item.eocpVenCd);
            },
            getInstallMonthName: function (item) {
                return parseInt(item.installMonth) == 0 ? '일시불' : item.installMonth + '개월';
            },
            getTradeDate: function (item) {
                return String(item.tradeDateTime||'').displayDate();
            },
            getTradeTime: function (item) {
                return String(item.tradeDateTime||'').displayTime();
            },
            print: function (item) {
                window.open('/cardPayment/Print?on=' + item.cardPayment.eocpOrderNumber, 'cardPaymentPrint', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=430,height=670');
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.endDate;
            this.srch.endDate = opt.endDate;

            common.hideLoading();
        },
        computed: {
            totalPrice: function () {
                var sum = 0;
                for (var ii = 0, l = this.list.length; ii <l; ii++) {
                    sum += this.list[ii].cardPayment.totalAmount;
                }
                return sum.toLocaleFixed();
            },
        },
    });
}

if (document.getElementById("appDepositList")) {
    var appDepositList = new Vue({
        el: '#appDepositList',
        data: {
            srch: {
                startDate: '',
                endDate:'',
            },
            list:[],
        },
        methods: {
            search: function () {
                common.showLoading();
                var _this = this;
                axios.get('/api/deposit', { params: this.srch }).then(function (response) {
                    _this.list = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            updateStartDate: function (d) { this.srch.startDate = d; },
            updateEndDate: function (d) { this.srch.endDate = d; },
            showCalander: function (e) { $(e.target).siblings('input').focus(); },
            print: function (item) {
                var dtObj = item.colDt.split('-');
                var param = {
                    colNo:item.colNo,
                    yy: dtObj[0].substring(2,4),
                    mm: dtObj[1],
                    dd: dtObj[2],
                    amt: item.amt,
                    venNm: item.custNm
                };
                window.open('/depositPrint/Print?' + common.setParamsFromObj(param), 'depositPrint', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=380,height=520');
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.endDate;
            this.srch.endDate = opt.endDate;

            common.hideLoading();
        },
    });
}
if (document.getElementById("appDepositPrint")) {
    var appDepositPrint = new Vue({
        el: '#appDepositPrint',
        data: {
            info: {
                colNo:'',
                yy: '',
                mm: '',
                dd: '',
                amt:'',
                venNm:'',
            },
            convertedAmt:'',
        },
        methods: {
            print: function () {
                window.print();
            },
            getAmtChar: function (idx) {
                return this.convertedAmt.length >= idx ? this.convertedAmt[idx] : '';
            },
        },
        created: function () {
            if (location.search !== '') this.info = common.setObjFromParams(location.search);
            var amt = '         ' + this.info.amt;
            this.convertedAmt = amt.substring(amt.length - 10);
        },
        computed: {
            getEmptyCnt: function () {
                return 10 - this.info.amt.length;
            },
            
        },
    });
}
if (document.getElementById("appTaxPrintList")) {
    var appTaxPrintList = new Vue({
        el: '#appTaxPrintList',
        data: {
            srch: {
                type: 's',
                startDate: '',
                endDate: '',
            },
            list: [],
        },
        methods: {
            search: function () {
                common.showLoading();
                var _this = this;
                axios.get('/api/taxPrint/TaxList', { params: this.srch }).then(function (response) {
                    _this.list = response.data;
                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            updateStartDate: function (d) { this.srch.startDate = d; },
            updateEndDate: function (d) { this.srch.endDate = d; },
            showCalander: function (e) { $(e.target).siblings('input').focus(); },
            print: function (item) {
                var param = {
                    yyyy: item.salDt.substring(0, 4),
                    mm: item.salDt.substring(5, 7),
                    taxSeq: item.taxSeq,
                    f: this.srch.type
                };
                window.open('/TaxPrint/Print?'+ common.setParamsFromObj(param), 'taxprint', 'toolbar=yes,scrollbars=1,resizable=yes,top=0,left=0,width=580,height=520');
            },
        },
        created: function () {
            var opt = common.getSrchDateOption();
            this.srch.startDate = opt.endDate;
            this.srch.endDate = opt.endDate;

            common.hideLoading();
        },
    });
}
if (document.getElementById("appTaxPrint")) {
    var appTaxPrint = new Vue({
        el: '#appTaxPrint',
        data: {
            srch: {
                f: '',
                yyyy: '',
                mm: '',
                taxSeq:0,
            },
            info: {},
        },
        methods: {
            search: function () {
                var _this = this;
                axios.get('/api/taxPrint/TaxPrint', { params: this.srch }).then(function (response) {
                    _this.info = response.data;
                }).catch(common.errorMessage).finally(function () {
                });
            },
            print: function () {
                window.print();
            },
        },
        created: function () {
            if (location.search !== '') this.srch = common.setObjFromParams(location.search);
            this.search();
        },
        computed: {
            getTitleType: function() {
                return this.srch.f == 'r' ? '공급받는자' : '공급자';
            },
            getOrdNo1: function () {
                return this.info.ordNo ? this.info.ordNo.substring(0, 8) : '';
            },
            getOrdNo2: function () {
                return this.info.ordNo ? this.info.ordNo.substring(8).trim() : '';
            },
        },
    });
}
if (document.getElementById("appCardPaymentPrint")) {
    var appCardPaymentPrint = new Vue({
        el: '#appCardPaymentPrint',
        data: {
            venInfo: constants.vendor.card,
            payInfo: {},
            srch: {},
        },
        methods: {
            search: function (n) {
                var param = {
                    orderNumber: n,
                };
                var _this = this;
                axios.get('/api/card/printData', { params: param }).then(function (response) {
                    _this.payInfo = response.data;
                }).catch(common.errorMessage).finally(function () {
                });
            },
            print: function () {
                window.print();
            },
        },
        created: function () {
            var obj = common.setObjFromParams(location.search);
            this.search(obj.on);
        },
        computed: {
            getTradeDateTime: function () {
                return this.payInfo.tradeDateTime ? this.payInfo.tradeDateTime.displayDate() +' '+ this.payInfo.tradeDateTime.displayTime() : '';
            },
            getInstallMonth: function () {
                return (this.payInfo.installMonth || 0) == 0 ? '일시불' : this.payInfo.installMonth +'개월';
            },
            getStatus: function () {
                return this.payInfo.code == constants.payRespCode.success ? '거래승인' : '거래실패';
            },
        },
    });
}