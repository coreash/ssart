﻿'use strict';
String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, '');
};
String.prototype.displayDate = function (dv) {
    var t = this.replace(/-/g, '').substring(0, 8);
    if (common.isNullOrEmpty(t)) return '';
    if (dv === undefined || dv === null) dv = '.';
    return t.substring(0, 4) + dv + t.substring(4, 6) + dv + t.substring(6);
}
String.prototype.displayTime = function () {
    try {
        var t = this.replace(/-/g, '').substring(8);
        var dv = ':';
        if (common.isNullOrEmpty(t)) return '';
        return t.substring(0, 2) + dv + t.substring(2, 4);
    } catch (e) {
        return '';
    }
}
String.prototype.displayVenNum = function (dv) {
    var vn = this.replace(/-/g, '');
    if (dv === null || dv === undefined) dv = '-';
    return vn.substring(0, 3) + dv + vn.substring(3, 5) + dv + vn.substring(5);
};
Date.prototype.displayDate = function(dv) {
    var t = this.replace(/-/g, '').substring(0, 8);
    if (common.isNullOrEmpty(t)) return '';
    if (dv === undefined || dv === null) dv = '.';
    return t.substring(0, 4) + dv + t.substring(4, 6) + dv + t.substring(6);
}
Date.prototype.displayTime = function (dv) {
    return String(this).displayTime();
}
Number.prototype.toLocaleFixed = function (n) {
    if (n === undefined) n = 0;
    return this.toLocaleString('en', { maximumFractionDigits: n });
};

var common = {
    _Loading: document.getElementById("layerLoading"),
    _processing: 0,
    _msgLogin: false,
    splitNumber: function (obj, s, nm, c) {
        if (common.isNullOrEmpty(s)) return;
        var ary = s.split(c);
        for (var ii = 0, l = ary.length; ii < l; ii++) {
            obj[nm + (ii + 1)] = ary[ii];
        }
    },
    pageObjWithFooter: {
        pageSize: constants.pageSize -2,
        totalPage: 0,
        totalCount: 0,
        list: []
    },
    pageObj: {
        pageSize: constants.pageSize,
        totalPage: 0,
        totalCount: 0,
        list: []
    },
    isNullOrEmpty: function (s) {
        return s === null || s === undefined || (typeof s === 'string' && s.trim() === '') ? true : false;
    },
    showLoading: function () {
        this._processing++;
        this._Loading.style.display = "block";
    },
    hideLoading: function () {
        this._processing--;
        if (this._processing <= 0) { this._Loading.style.display = "none"; this._processing = 0; }
    },
    errorMessage: function (e) {

        if (e.response && e.response.status == 401) {
            if (common._msgLogin === false) {
                alert('로그인이 필요합니다.');
                location.href = '/Main/Login';
                common._msgLogin = true;
            }
            return;
        }
        console.error('errorMessage', e);
        alert('관리자에게 문의해주세요.');
    },
    setPagingInfo: function (obj, page, totalCount, pageSize, pageCol) {
        if (pageSize === undefined) pageSize = constans.pageSize;
        if (pageCol === undefined) pageCol = constans.pageCol;
        obj.list = [];
        obj.totalCount = totalCount;
        obj.totalPage = Math.ceil(obj.totalCount / pageSize);

        obj.startNumber = parseInt((page - 1) / pageCol) * pageCol + 1;
        obj.endNumber = parseInt(((page - 1) + pageCol) / pageCol) * pageCol;
        if (obj.totalPage <= obj.endNumber) obj.endNumber = obj.totalPage;

        obj.hasPrev = false;
        obj.hasNext = false;
        if (obj.startNumber > 1) obj.hasPrev = true;
        if (obj.totalPage > obj.endNumber) obj.hasNext = true;

        for (var ii = obj.startNumber, l = obj.endNumber; ii <= l; ii++) {
            obj.list.push(ii);
        }
    },
    setParamsFromObj: function (obj) {
        var ary = [];
        for (var item in obj) {
            ary.push(item + '=' + encodeURIComponent(obj[item]));
        }
        return ary.join('&');
    },
    setObjFromParams: function (param) {
        var s = param.substring(1);
        var obj = {};
        var ary = s.split('&');
        for (var ii = 0, l = ary.length; ii < l; ii++) {
            var item = ary[ii];
            var aryItem = item.split('=');
            if (aryItem.length != 2) continue;

            obj[aryItem[0]] = decodeURIComponent(aryItem[1]);
        }
        return obj;
    },
    byteCalculation: function (bytes) {
        var bytes = parseInt(bytes);
        var s = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
        var e = Math.floor(Math.log(bytes) / Math.log(1024));

        if (e == "-Infinity")
            return "0 " + s[0];
        else
            return (bytes / Math.pow(1024, Math.floor(e))).toFixed(2) + " " + s[e];
    },
    getSrchDateOption: function () {
        var date = new Date();
        var year = date.getFullYear();
        var month = ("0" + (1 + date.getMonth())).slice(-2);
        var day = ("0" + date.getDate()).slice(-2);

        return {
            startDate: year + "-" + month + "-01",
            endDate: year + "-" + month + "-" + day
        };
    },
    getToday: function () {
        var today = new Date();
        return today.toISOString().substring(0, 10);
    },
    getCookie: function (name) {
        var nameOfCookie = name + "=";
        var x = 0;
        var endOfCookie;
        while (x <= document.cookie.length) {
            var y = (x + nameOfCookie.length);
            if (document.cookie.substring(x, y) == nameOfCookie) {
                if ((endOfCookie = document.cookie.indexOf(";", y)) == -1) endOfCookie = document.cookie.length;
                return decodeURIComponent(document.cookie.substring(y, endOfCookie));
            }
            x = document.cookie.indexOf(" ", x) + 1;
            if (x == 0) break;
        }
        return;
    },
    setCookie: function (name, value, expiredays){
        var todayDate = new Date();
        todayDate.setDate(todayDate.getDate() + expiredays);
        document.cookie = name + "=" + escape(value) + "; path=/; expires=" + todayDate.toGMTString() + ";"
    },
    isValidPassword: function (s) {
        /* 8자리 이상, 숫자,영문자,특수문자 포함 */
        var reg = /^(?=.*?[a-zA-Z)(?=.*?[0-9])(?=.*?[!@#$%^&*()?]).{8,15}$/;
        return reg.test(s.trim());
    },
    displayRowNumber: function (totalCnt, page, pageSize, index) {
        return totalCnt - ((page - 1) * pageSize) - index;
    },
    calDecimal: function (p, f) {
        return f == constants.bagType.order ? Math.round(p) : Math.floor(p);
    },
    /**
     * @description 주문단가
     *  @param {number} p 단가
     *  @param {number} ctr_p 사전할인
     *  @param {number} hpin 원내할인 
     *  -- 매출 : 원내할인 적용 후 반올림, 이후 사전할인 적용 후 다시 반올림
     *  -- 반품 : 동일한 로직에서 버림처리.
     */
    getOrderPrice: function (f, p, ctr_p, hpin) {
        if (parseInt(hpin) > 0) p = this.calDecimal(p - (p * (hpin / 100)), f);
        if (parseInt(ctr_p) > 0) p = this.calDecimal(p - (p * (ctr_p / 100)), f);        
        return p;
    },
    pathname: location.pathname,
    showReasonPop: function () {
        $("#areaCancelReason").dialog({
            resizable: false,
            width: 400,
            height: 190,
            modal: true,
            title: "e-Order",
            open: function () {
                $(this).removeClass('hidden');
                $('#tx_reason').focus();
            },
            buttons: {
                "확인": this.cancel,
                "취소": function () {
                    $(this).addClass('hidden');
                    $(this).dialog("close");
                },
            }
        });
    },
    showNotePop: function () {
        $("#areaConfirmNote").dialog({
            resizable: false,
            width: 400,
            height: 230,
            modal: true,
            title: "e-Order",
            open: function () {
                $(this).removeClass('hidden');
                $('#tx_confirm_note').focus();
            },
            buttons: {
                "확인": this.confirm,
                "취소": function () {
                    $(this).addClass('hidden');
                    $(this).dialog("close");
                },
            }
        });
    },
    isIEbrowser: function () {
        var navAgent = window.navigator.userAgent.toLowerCase();
        var navAppName = window.navigator.appName.toLowerCase();
        return (navAppName === 'netscape' && navAgent.indexOf('trident') !== -1) || navAgent.indexOf('msie') !== -1 ? true : false;
    },
    getAppInfo: function () {
        return document.getElementById("appOrder") ? {
            appName: 'Order',
            appBagType: constants.bagType.order
        } : document.getElementById("appReturn") ? {
            appName: 'Return',
            appBagType: constants.bagType.return
        } : document.getElementById("appOrderSearch") ? {
            appName: 'OrderSearch',
            appBagType: constants.bagType.order
        } :  document.getElementById("appReturnSearch") ? {
            appName: 'ReturnSearch',
            appBagType: constants.bagType.return
        } : document.getElementById("appReward") ? {
            appName: 'Reward',
            appBagType: constants.bagType.reward
        } : {
            appName: 'RewardSearch',
            appBagType: constants.bagType.reward
        };
    },
    /**
     * @description 사업부
     * @param {string} v 거래처코드
     * @param {string} vt 사업부 영문명
     * 0 : chemical
     * 2 : bio
     * 3 : datkeda
     * @returns{boolean} 
     */
    IsExactVenType: function (v, vt) {
        var lv = v.substring(0, 1);
        switch (vt.toLowerCase()) {
            case 'chemical':
                return lv === '0';
                break;
            case 'bio':
                return lv === '2';
                break;
            case 'dakeda':
                return lv === '3';
                break;
            default:
                return false;
        }
    },
    excelDownload: function (url, data, fileName) {
        common.showLoading();
        axios.post(url, data, { responseType: 'blob' }).then(function (response) {
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                // IE에서 동작
                window.navigator.msSaveBlob(new Blob([response.data]), fileName);

            } else {
                var fileURL = window.URL.createObjectURL(new Blob([response.data]));
                var fileLink = document.createElement('a');

                fileLink.href = fileURL;
                fileLink.setAttribute('download', fileName);
                document.body.appendChild(fileLink);

                fileLink.click();
            }
        }).catch(common.errorMessage).finally(function () {
            common.hideLoading();
        });
    },
    getVenType: function (v) {
        var lv = v.substring(0, 1);
        return lv === constants.venType.chemical.venCdPrefix ? constants.venType.chemical.name :
            lv === constants.venType.bio.venCdPrefix ? constants.venType.bio.name :
                lv === constants.venType.dakeda.venCdPrefix ? constants.venType.dakeda.name : '';
    },
};

// CustomAuthorizationFilter 에서 ajax, axios 요청시 로그인 체크시 사용
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

//var navAgent = window.navigator.userAgent.toLowerCase();
//var navAppName = window.navigator.appName.toLowerCase();
//if ((navAppName === 'netscape' && navAgent.indexOf('trident') !== -1) || navAgent.indexOf('msie') !== -1) {
//    if (confirm("현재 페이지는 인터넷익스플로러(IE)브라우저를 지원하지 않습니다. " + "크롬 혹은 엣지브라우저에서 정상적으로 작동됩니다. 해당 브라우저로 이동하시겠습니까?")) {
//        window.location = "microsoft-edge:" + window.location.href;
//        self.close();
//    }
//}

