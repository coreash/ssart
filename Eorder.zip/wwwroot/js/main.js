﻿'use strict';

if (document.getElementById("mainApp")) {
    var mainApp = new Vue({
        el: '#mainApp',
        data: {
            isShowFindInfo: false,
            id: '',
            pwd: '',
            findInfo: {
                venNm: '',
                venNum1: '',
                venNum2: '',
                venNum3: ''
            },
        },
        methods: {
            showFindInfo: function () { this.isShowFindInfo = true; },
            hideFindInfo: function () { this.isShowFindInfo = false; },
            loginWork: function (e) {
                common.showLoading();
                var params = {
                    id: this.id,
                    pwd: this.pwd
                };
                axios.post('/api/Login', params)
                    .then(function (response) {
                        if (response.data == 'OK') {
                            location.href = '/Order';
                        } else if (response.data == 'FIRSTLOGIN') {
                            location.href = '/Info';
                        } else if (response.data == 'NEEDPWCHANGE') {
                            alert('비밀번호를 변경한 지 3개월이 경과하여 비밀번호 변경이 필요합니다.');
                            location.href = '/Info';
                        } else if (response.data == "CHKPWD") {
                            alert('잘못된 비밀번호입니다.');
                            mainApp.$refs.id.select();
                        } else if (response.data == "INVALID") {
                            alert('인증이 필요합니다.');
                            mainApp.$refs.id.select();
                        } else {
                            alert('로그인 정보를 확인하세요');
                            mainApp.$refs.id.select();
                        }
                    }).catch(function (error) {
                        alert('로그인에 실패하였습니다.\n관리자에게 문의하여주세요');
                        mainApp.$refs.id.select();
                    }).finally(function () {
                        common.hideLoading();
                    });
            },
            findId: function (e) {
                var params = 'venNm=' + encodeURIComponent(this.findInfo.venNm) + '&venNum=' + this.findInfo.venNum1 + this.findInfo.venNum2 + this.findInfo.venNum3;

                axios
                    .get('/api/Login/FindInfo?' + params).then(function (response) {

                        var id = response.data;

                        if (id === undefined || id === null || common.isNullOrEmpty(id)) {
                            alert('찾는 정보가 없습니다.');
                        } else {
                            alert("찾으시는 ID는 '" + id + "' 입니다.");
                            mainApp.hideFindInfo();
                        }
                    }).catch(function () {
                        alert('찾는 정보가 없습니다.\n관리자에게 문의하여주세요');
                    });
            },
            getPopup: function () {
                common.showLoading();
                var param = {
                    type: 'today',
                    gubun: constants.popupGubun.outside,
                    page: 1,
                    pageSize: 100,
                };
                axios.get('/api/popup?' + common.setParamsFromObj(param)).then(function (response) {
                    if (response.data && response.data.count <= 0) return;
                    for (var ii = 0, l = response.data.list.length; ii < l; ii++) {
                        var item = response.data.list[ii];

                        if (common.getCookie(item.eopopCook.trim()) == 'ON') continue;

                        var popoupwidth = parseInt(item.eopopWidth); 
                        var popoupheight = parseInt(item.eopopHeight);
                        if (popoupwidth < 250) popoupwidth = 250;
                        if (popoupheight < 100) popoupheight = 100;

                        if (common.isIEbrowser()) {
                            popoupwidth += 30;
                            popoupheight += 123;
                        } else {
                            popoupwidth += 30;
                            popoupheight += 133;
                        }

                        var param = 'width=' + popoupwidth + ',height=' + popoupheight + ',left=' + item.eopopLeft + ',top=' + item.eopopTop + ',scrollbars=no,resizable=no';
                        
                        window.open('/main/popup?n=' + item.eopopNum, 'pop' + item.eopopNum, param);
                    }

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            downloadManual: function () {
                $('#download').attr('src', '/api/login/Filedownload?filefolder=resource&fileName=' + encodeURIComponent('E-order 매뉴얼(사용자용).pdf'));
            },
        },
        created: function () {
            this.getPopup();
        },
    });
}
if (document.getElementById("appPopup")) {
    var appPopup = new Vue({
        el: '#appPopup',
        data: {
            id: '',
            popup: {},
        },
        methods: {
            getData: function () {
                common.showLoading();
                axios.get('/api/popup/' + this.id).then(function (response) {
                    var __data = response.data;
                    appPopup._data.popup = __data;
                    var contentStyle = ''
                    var minWidth = 250;

                    if (__data.eopopWidth > 0) contentStyle = 'width:' + (__data.eopopWidth < minWidth ? minWidth : __data.eopopWidth) + 'px;';
                    if (__data.eopopHeight > 0) {
                        contentStyle += 'height: ' + (__data.eopopHeight + 73) + 'px;';
                        $(".pop-text").attr('style', 'height: ' + __data.eopopHeight + 'px;');
                    }
                    if (contentStyle != '') $(".popup-content").attr('style', contentStyle);

                }).catch(common.errorMessage).finally(function () {
                    common.hideLoading();
                });
            },
            noMorePopup: function () {
                common.setCookie(this.popup.eopopCook.trim(), "ON", 1);
                this.closePopup();
            },
            closePopup: function () {
                self.close();
            }
        },
        created: function () {
            this.id = location.search.split('n=')[1];
            this.getData();
        },
    });
}