﻿var constants = {
    pageSize: 14,
    pageCol: 5,
    mobile: ['010','011','016','017','018','019'],
    phone: ['02', '031', '032', '033', '041', '042', '043', '044', '051', '052', '053', '054', '055', '061', '062', '063', '064', '070'],
    email: ['naver.com', 'gmail.com', 'kakao.com', 'daum.net', 'hotmail.com', 'nate.com', 'yahoo.co.kr', 'paran.com', 'empas.com', 'dreamwiz.com', 'freechal.com', 'lycos.co.kr', 'korea.com'],
    popupGubun: {
        order: '1',
        outside: '2',
        inside:'3'
    },
    plantInfo: {
        '1000': '진천',
        '2000': '서울',
        '3000': '오창'
    },
    bagType: {
        order: 'O',
        return: 'R',
        reward: 'W',
    },
    payRespCode: {
        success: 'A0200',
        fail: 'A0201',
        errParam: 'A0400',
        errAuth: 'A0401',
        errProtocol: 'A0403',
        errKSnetServer: 'A0500',
        errOther: 'A0999'
    },
    venType: {
        chemical: { venCdPrefix: '0', code: 'C', name: '케미칼' },
        bio: { venCdPrefix: '2', code: 'B', name: '바이오' },
        dakeda: { venCdPrefix: '3', code: 'D', name: '다케다' },
    },
    vendor: {
        card: {
            venName: '(주)셀트리온제약',
            venNum: '301-85-35923',
            venTel:'02-2216-3611',
            storeName: '(주)셀트리온제약',
            ceoName: '김만훈',
            address: '충청북도 진천군 이월면 사곡리 588-2',
        },
    },
};