﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder
{
    public static class Common
    {
        public static string GetName()
        {
            return "coreash";
        }
    }
}
