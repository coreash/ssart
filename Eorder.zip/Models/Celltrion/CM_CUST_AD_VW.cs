﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models
{
    public class CM_CUST_AD_VW
    {
        #region 배송지 묶음
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CustCd { get; set; }
        /// <summary>
        /// 간납처코드
        /// </summary>
        public string EcustCd { get; set; }
        /// <summary>
        /// 배송지코드
        /// </summary>
        public string RelaCd { get; set; }
        public string RelaAddress { get; set; }
        #endregion
    }
}
