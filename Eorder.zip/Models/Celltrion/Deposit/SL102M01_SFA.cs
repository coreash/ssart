﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    /// <summary>
    /// 입금표 출력내역
    /// </summary>
    public class SL102M01_SFA
    {
        /// <summary>
        /// 전표번호
        /// </summary>
        public string ColNo { get; set; }
        /// <summary>
        /// 거래처명
        /// </summary>
        public string CustNm { get; set; }
        /// <summary>
        /// 수금일자
        /// </summary>
        public string SalDt { get; set; }
        /// <summary>
        /// 실수금일자
        /// </summary>
        public string ColDt { get; set; }
        /// <summary>
        /// 수금액
        /// </summary>
        public Int64 Amt { get; set; }
        /// <summary>
        /// 수금액 기타
        /// </summary>
        public Int64 AmtKita { get; set; }
    }
}
