﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class UploadedData
    {
        #region 매출/재고 업로드 내역
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }
        /// <summary>
        /// 거래처명
        /// </summary>
        public string VenNm { get; set; }
        /// <summary>
        /// 업로드일자
        /// </summary>
        public string YYYYMM { get; set; }
        /// <summary>
        /// 매출 업로드 건수
        /// </summary>
        public int SalesCnt { get; set; }
        /// <summary>
        /// 재고 업로드 건수
        /// </summary>
        public int StocksCnt { get; set; }
        #endregion
    }
}
