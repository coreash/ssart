﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class TRANS_COMM_VW
    {
        #region 거래명세서 내역

        /// <summary>
        /// 사업장코드
        /// 1000: 진천, 2000: 서울, 3000: 오창
        /// </summary>
        public string Plant_Cd { get; set; }
        /// <summary>
        /// 전표번호
        /// </summary>
        public string Ord_No { get; set; }
        /// <summary>
        /// 발행구분
        /// Y: 발행, N: 미발행
        /// </summary>
        public string Salprss_Gb { get; set; }
        /// <summary>
        /// 주문일자
        /// </summary>
        public DateTime Sal_Dt { get; set; }
        /// <summary>
        /// 주문구분
        /// AA: 증정용(영업부), AD: 사업자매출, AH: 직원용, AJ: 자가소비, AK: 견본품(영업외)
        /// AM: 수철, AN: 군납, AP: 기타, AR: 선출고
        /// BD: 반품, BF: 인거반품
        /// </summary>
        public string Sal_Gb { get; set; }
        /// <summary>
        /// 자료구분
        /// 11: 직납, 12: 간납, 21: 사입, 22: 이기, 24: 수가변동, 33: 교품
        /// </summary>
        public string Data_Gb { get; set; }
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string Cust_Cd { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string Cust_Nm { get; set; }
        /// <summary>
        /// 사업자번호
        /// </summary>
        public string BUSIN_NO { get; set; }
        /// <summary>
        /// 대표자명
        /// </summary>
        public string Ceo_Nm { get; set; }
        /// <summary>
        /// 간납처코드
        /// </summary>
        public string Ecust_Cd { get; set; }

        /// <summary>
        /// 공급가액
        /// </summary>
        public long Sal_Amt { get; set; }
        /// <summary>
        /// 부가세액
        /// </summary>
        public long Sal_Vat { get; set; }
        /// <summary>
        /// 비고
        /// </summary>
        public string Bigo { get; set; }
        /// <summary>
        /// 담당자명
        /// </summary>
        public string emp_nm { get; set; }

        #endregion
    }
}
