﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class SL101S01
    {
        #region 주문서 상세

        /// <summary>
        /// 사업장코드
        /// 1000: 진천, 2000: 서울, 3000: 오창
        /// </summary>
        public string PlantCd { get; set; }
        /// <summary>
        /// 전표번호 
        /// yyyymmdd + 5xxxx
        /// </summary>
        public string OrdNo { get; set; }
        /// <summary>
        /// 일련번호
        /// </summary>
        public int SeqNo { get; set; }
        /// <summary>
        /// 품목코드
        /// </summary>
        public string ItemCd { get; set; }
        /// <summary>
        /// 처방구분
        /// 1: 처방, 2: 비처방
        /// </summary>
        public string ChbGb { get; set; }
        /// <summary>
        /// 판매수량
        /// </summary>
        public decimal SalQty { get; set; }
        /// <summary>
        /// 할증수량
        /// </summary>
        public decimal GivQty { get; set; }
        /// <summary>
        /// 출하가
        /// </summary>
        public float SalPrc { get; set; }
        /// <summary>
        /// 총매출액
        /// </summary>
        public decimal SalTmc { get; set; }
        /// <summary>
        /// 사전액
        /// </summary>
        public decimal BefAmt { get; set; }
        /// <summary>
        /// 사후액
        /// </summary>
        public decimal AftAmt { get; set; }
        /// <summary>
        /// 공그가액
        /// </summary>
        public decimal SalAmt { get; set; }
        /// <summary>
        /// 부가세
        /// </summary>
        public decimal SalVat { get; set; }
        /// <summary>
        /// 사전비
        /// </summary>
        public decimal BefYl { get; set; }
        /// <summary>
        /// 사후비
        /// </summary>
        public decimal AftYl { get; set; }
        /// <summary>
        /// 할증비
        /// </summary>
        public decimal GivYl { get; set; }
        /// <summary>
        /// 반품유형
        /// 01: 유경, 02: 파손, 03: 불량, 04: 변질, 05: 외노, 06: 유임, 07: 인거, 08: 과매, 09: 주문오류, 10: 폐업, 11: 교품, 99: 기타
        /// </summary>
        public string ResGb { get; set; }
        /// <summary>
        /// 할증초과
        /// </summary>
        public string GivCk { get; set; }
        /// <summary>
        /// 단가오류
        /// </summary>
        public string PrcCk { get; set; }
        /// <summary>
        /// 품절구분
        /// </summary>
        public string AbsCk { get; set; }
        /// <summary>
        /// 상태구분
        /// 1: 배송완료, 3: 배송전
        /// </summary>
        public string ConcGb { get; set; }
        /// <summary>
        /// 거래장인쇄여부
        /// </summary>
        public string CustPrtGb { get; set; }
        /// <summary>
        /// 간납장인쇄여부
        /// </summary>
        public string EcustPrtGb { get; set; }
        /// <summary>
        /// 출하가1
        /// </summary>
        public float SalPrc1 { get; set; }
        /// <summary>
        /// 공급가액1
        /// </summary>
        public decimal SalAmt1 { get; set; }
        /// <summary>
        /// 부가세1
        /// </summary>
        public decimal SalVat1 { get; set; }
        /// <summary>
        /// 기준가
        /// </summary>
        public decimal DrugPrc { get; set; }
        /// <summary>
        /// 매출원가
        /// </summary>
        public decimal SalCost { get; set; }
        /// <summary>
        /// 제조원가
        /// </summary>
        public decimal MfCost { get; set; }
        /// <summary>
        /// 수정일
        /// </summary>
        public DateTime? UpdateDt { get; set; }
        /// <summary>
        /// 수정자
        /// </summary>
        public string UEmpCd { get; set; }
        /// <summary>
        /// 이기Lot
        /// </summary>
        public string OutlotNo { get; set; }
        /// <summary>
        /// 이기Lot 유효일자
        /// </summary>
        public string OutexpDt { get; set; }

        #endregion
    }
}
