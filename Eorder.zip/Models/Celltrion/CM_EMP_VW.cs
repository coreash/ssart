﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    
    public class CM_EMP_VW
    {
        #region 사원정보

        /// <summary>
        /// 사원코드
        /// </summary>
        public string EMP_CD { get; set; }
        /// <summary>
        /// 사원명
        /// </summary>
        public string EMP_NM { get; set; }
        /// <summary>
        /// 부서코드
        /// </summary>
        public string DEPT_CD { get; set; }
        /// <summary>
        /// 부서명
        /// </summary>
        public string DEPT_NM { get; set; }
        /// <summary>
        /// 직급코드
        /// </summary>
        public string EMP_POST { get; set; }
        /// <summary>
        /// 직급명
        /// </summary>
        public string EMP_POST_NM { get; set; }
        /// <summary>
        /// 전화번호
        /// </summary>
        public string EMP_PHONE { get; set; }
        /// <summary>
        /// 메일주소
        /// </summary>
        public string EMP_EMAIL { get; set; }
        /// <summary>
        /// 퇴사여부
        /// </summary>
        public string RETIRE_FLAG { get; set; }

        #endregion
    }
}
