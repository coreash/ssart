﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class CM_CUST_VW
    {
        #region 거래처정보

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CUST_CD { get; set; }
        /// <summary>
        /// 거래처명
        /// </summary>
        public string CUST_NM { get; set; }
        /// <summary>
        /// 거래처상태
        /// </summary>
        public string SAGO_GB { get; set; }
        /// <summary>
        /// 거래처상태명
        /// 1: 정상, 2: 사고처, 3: 중지처, 4: 폐업
        /// </summary>
        public string SAGO_NM { get; set; }
        /// <summary>
        /// 유통구분
        /// 10 : 도매, 20: 약국, 30: 병원, 31: 종병, 32: 준종합, 40: 의원, 60: 수출, 80: 현판, 99: 기타
        /// </summary>
        public string UT_GB { get; set; }
        /// <summary>
        /// 업태
        /// </summary>
        public string CATGO_NM { get; set; }
        /// <summary>
        /// 종목
        /// </summary>
        public string BUSIN_NM { get; set; }
        /// <summary>
        /// 사업자번호
        /// </summary>
        public string BUSIN_NO { get; set; }
        /// <summary>
        /// 대표자명
        /// </summary>
        public string CEO_NM { get; set; }
        /// <summary>
        /// 전화번호
        /// </summary>
        public string TEL_NO { get; set; }
        /// <summary>
        /// FAX번호
        /// </summary>
        public string FAX_NO { get; set; }
        /// <summary>
        /// 메일주소
        /// </summary>
        public string E_MAIL_AD { get; set; }
        /// <summary>
        /// 우편번호
        /// </summary>
        public string POST_CD { get; set; }
        /// <summary>
        /// 주소
        /// </summary>
        public string ADDRESS { get; set; }
        /// <summary>
        /// 최종판매일
        /// </summary>
        public string FNSAL_DT { get; set; }
        /// <summary>
        /// 최종수금일
        /// </summary>
        public string FNCOL_DT { get; set; }
        /// <summary>
        /// 회전일
        /// </summary>
        public string TURN_DT { get; set; }
        /// <summary>
        /// 미수금
        /// </summary>
        public string RMD_AMT { get; set; }
        /// <summary>
        /// 미도래어음
        /// </summary>
        public string BIL_AMT_SUM { get; set; }
        /// <summary>
        /// 총잔액
        /// </summary>
        public string TOT_AMT { get; set; }
        #endregion
    }
}
