﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class TRANS_COMM_VW_LIST
    {
        #region 거래명세서 목록

        /// <summary>
        /// 사업장코드
        /// </summary>
        public string PlantCd { get; set; }
        /// <summary>
        /// 전표번호
        /// </summary>
        public string OrdNo { get; set; }
        /// <summary>
        /// 발행구분
        /// </summary>
        public string SalprssGb { get; set; }
        /// <summary>
        /// 주문일자
        /// </summary>
        public DateTime SalDt { get; set; }
        /// <summary>
        /// 주문구분
        /// </summary>
        public string SalGb { get; set; }
        /// <summary>
        /// 자료구분
        /// </summary>
        public string DataGb { get; set; }
        /// <summary>
        /// 공급가액
        /// </summary>
        public decimal SalAmt { get; set; }
        /// <summary>
        /// 세액
        /// </summary>
        public decimal SalVat { get; set; }
        /// <summary>
        /// 총액
        /// </summary>
        public decimal SalTmc { get; set; }
        /// <summary>
        /// 비고
        /// </summary>
        public string Bigo { get; set; }
        /// <summary>
        /// 거래처명
        /// </summary>
        public string CustNm { get; set; }
        /// <summary>
        /// 대표자명
        /// </summary>
        public string CeoNm { get; set; }
        /// <summary>
        /// 사업자번호
        /// </summary>
        public string BusinNo { get; set; }
        /// <summary>
        /// 주소
        /// </summary>
        public string KorAd { get; set; }
        /// <summary>
        /// 간납처명
        /// </summary>
        public string EcustNm { get; set; }
        /// <summary>
        /// 담당자명
        /// </summary>
        public string EmpNm { get; set; }
        /// <summary>
        /// 전화번호
        /// </summary>
        public string TelNo { get; set; }
        /// <summary>
        /// 전체 row 개수
        /// </summary>
        public int Cnt { get; set; }
        /// <summary>
        /// 명세서 페이지 수
        /// </summary>
        public decimal Page { get; set; }
        /// <summary>
        /// 전문의약품 금액
        /// </summary>
        public decimal chb1 { get; set; }
        /// <summary>
        /// 일반의약품 금액
        /// </summary>
        public decimal chb2 { get; set; }
        /// <summary>
        /// 상세내역 목록
        /// </summary>
        public List<TRANS_COMM_VW_DETAIL> detail { get; set; }

        #endregion
    }
}
