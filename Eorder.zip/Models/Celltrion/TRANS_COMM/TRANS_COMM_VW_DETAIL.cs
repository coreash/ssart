﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class TRANS_COMM_VW_DETAIL
    {
        #region 거래명세서 상세 목록

        /// <summary>
        /// 전표번호
        /// </summary>
        public string OrdNo { get; set; }
        /// <summary>
        /// 일련번호
        /// </summary>
        public int SeqNo { get; set; }
        /// <summary>
        /// 품목코드
        /// </summary>
        public string ItemCd { get; set; }
        /// <summary>
        /// 품목명
        /// </summary>
        public string ItemNm { get; set; }
        /// <summary>
        /// 규격
        /// </summary>
        public string Standard { get; set; }
        /// <summary>
        /// 판매수량
        /// </summary>
        public decimal SalQty { get; set; }
        /// <summary>
        /// 단가
        /// </summary>
        public double SalPrc { get; set; }
        /// <summary>
        /// 공급가액
        /// </summary>
        public decimal SalAmt { get; set; }
        /// <summary>
        /// 부가세
        /// </summary>
        public decimal SalVat { get; set; }
        /// <summary>
        /// 총매출액
        /// </summary>
        public decimal SalTmc { get; set; }
        /// <summary>
        /// 이기Lot
        /// </summary>
        public string OutlotNo { get; set; }
        /// <summary>
        /// 이기Lot 유효일자
        /// </summary>
        public string OutexpDt { get; set; }
        /// <summary>
        /// 처방구분
        /// 1:처방, 2:비처방
        /// </summary>
        public string ChbGb { get; set; }
        #endregion
    }
}
