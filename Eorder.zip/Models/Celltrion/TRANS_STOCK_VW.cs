﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class TRANS_STOCK_VW
    {
        #region 재고

        /// <summary>
        /// 표준코드
        /// </summary>
        public string StandardCd { get; set; }
        /// <summary>
        /// 품목코드
        /// </summary>
        public string ItemCd { get; set; }
        /// <summary>
        /// 품목명
        /// </summary>
        public string ItemNm { get; set; }
        /// <summary>
        /// 재고수량
        /// </summary>
        public decimal StorQty { get; set; }
        /// <summary>
        /// 단위량
        /// </summary>
        public decimal UnitQt { get; set; }
        /// <summary>
        /// 단위량
        /// 포:포 
        /// A:앰플
        /// Act:역가
        /// Box:박스
        /// Btl:병
        /// C:캡슐
        /// Can:캔
        /// CM:센티미터
        /// EA:개
        /// g:그람
        /// GAP:갑
        /// IU:단위
        /// kg:킬로그람
        /// L:리터
        /// m:미터
        /// mg:밀리그람
        /// mL:밀리리터
        /// ㎍:마이크로그람
        /// ㎕:마이크로리터
        /// Pack:팩
        /// R/L: 롤
        /// S:프리필드시린지
        /// SH:장
        /// T:정
        /// Tube:튜브
        /// Unit:유닛
        /// V:바이알
        /// </summary>
        public string Unit { get; set; }

        #endregion
    }
}
