﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    public class CM_CUST_SCRT_VW
    {
        #region 거래처별 담보현황

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CustCd { get; set; }
        /// <summary>
        /// 순번
        /// </summary>
        public int SeqNo { get; set; }
        /// <summary>
        /// 담보종류
        /// 0: 승인, 1: 연대보증인, 2: 부동산근저당, 3: 타수, 4: 보증보험증권, 5: 현금
        /// 6: 지급보증서, 7: 채권/국공채, 8: 당좌수표, 9: 승인
        /// A: 가계수표, B: 채권양도양수서, C: 약속어음, D: 질권, E: 양도성예금증서
        /// F: 구매전용카드, H: 전자어음, I: 신협어음, J: 선수금, Z: 기타
        /// </summary>
        public string ScrtGb { get; set; }
        /// <summary>
        /// 담보종류명
        /// </summary>
        public string ScrtGbNm{ get; set; }
        /// <summary>
        /// 설정일
        /// </summary>
        public DateTime? ScrtDt { get; set; }
        /// <summary>
        /// 담보가치
        /// </summary>
        public decimal ScrtAmt { get; set; }
        /// <summary>
        /// 만기일
        /// </summary>
        public DateTime? ExpDt { get; set; }
        /// <summary>
        /// 물건지주소
        /// </summary>
        public string ScrtAd { get; set; }
        /// <summary>
        /// 보증인성명
        /// </summary>
        public string ScrtpsnNm { get; set; }
        /// <summary>
        /// 보증인주민번호
        /// </summary>
        public string ScrtpsnNo { get; set; }
        /// <summary>
        /// 보증인주소
        /// </summary>
        public string ScrtpsnAd { get; set; }
        /// <summary>
        /// 비고
        /// </summary>
        public string Remark { get; set; }
        /// <summary>
        /// 관리번호
        /// </summary>
        public string ScrtNo { get; set; }
        /// <summary>
        /// 어음번호
        /// </summary>
        public string KbillNo { get; set; }
        /// <summary>
        /// 인감
        /// </summary>
        public string Chk1 { get; set; }
        /// <summary>
        /// 등본
        /// </summary>
        public string Chk2 { get; set; }
        /// <summary>
        /// 과세
        /// </summary>
        public string Chk3 { get; set; }
        /// <summary>
        /// 관리부반환
        /// </summary>
        public string Chk4 { get; set; }
        /// <summary>
        /// 관리부반환일
        /// </summary>
        public DateTime? Chk4Dt { get; set; }
        /// <summary>
        /// 관리부입고
        /// </summary>
        public string AccinCk { get; set; }
        /// <summary>
        /// 관리부입고일
        /// </summary>
        public DateTime? AccinDt { get; set; }
        /// <summary>
        /// 완결
        /// N: 미결, Y: 완결
        /// </summary>
        public string UseGb { get; set; }
        #endregion
    }
}
