﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    /// <summary>
    /// 거래원장 : 인쇄
    /// </summary>
    public class PrintVM
    {
        public PrintVM()
        {
            TransCardViews = new List<TransCardView>();
        }

        public List<TransCardView> TransCardViews { get; set; }
    }
}
