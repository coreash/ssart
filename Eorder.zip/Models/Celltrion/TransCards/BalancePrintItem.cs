﻿namespace Eorder.Models.Celltrion.TransCards
{
    /// <summary>
    /// 잔고확인항목
    /// </summary>
    public class BalancePrintItem
    {
        /// <summary>
        /// 구분
        /// </summary>
        public string Kind { get; set; }

        /// <summary>
        /// 거래장잔고
        /// </summary>
        public decimal? SheetBalanceAmount { get; set; }

        /// <summary>
        /// 거래처잔고
        /// </summary>
        public decimal? CustBalanceAmount { get; set; }

        /// <summary>
        /// 차액
        /// </summary>
        public decimal? DifferenceAmount { get; set; }

        /// <summary>
        /// 비고
        /// </summary>
        public string Remark { get; set; }
    }
}
