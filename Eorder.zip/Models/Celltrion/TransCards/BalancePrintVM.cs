﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    /// <summary>
    /// 거래원장 : 잔고확인서
    /// </summary>
    public class BalancePrintVM
    {
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CustCode { get; set; }
        
        /// <summary>
        /// 거래처명
        /// </summary>
        public string CustName { get; set; }
        /// <summary>
        /// 조회기준일
        /// </summary>
        public string BaseDate { get; set; }
        /// <summary>
        /// 기준일 - 년
        /// </summary>
        public string BaseDateYear
        {
            get
            {
                string result = "";
                if (BaseDate.Length == 8)
                {
                    result = BaseDate.Substring(0, 4);
                }

                return result;
            }
        }

        /// <summary>
        /// 기준일 - 월
        /// </summary>
        public string BaseDateMonth
        {
            get
            {
                string result = "";
                if (BaseDate.Length == 8)
                {
                    result = BaseDate.Substring(4, 2);
                }

                return result;
            }
        }

        /// <summary>
        /// 기준일 - 일
        /// </summary>
        public string BaseDateDay
        {
            get
            {
                string result = "";
                if (BaseDate.Length == 8)
                {
                    result = BaseDate.Substring(6, 2);
                }

                return result;
            }
        }

        /// <summary>
        /// 확인일
        /// </summary>
        public string ConfirmDate { get; set; }

        /// <summary>
        /// 확인일 - 년도
        /// </summary>
        public string ConfirmDateYear
        {
            get
            {
                string result = "";
                if (ConfirmDate.Length == 8)
                {
                    result = ConfirmDate.Substring(0, 4);
                }

                return result;
            }
        }

        /// <summary>
        /// 확인일 - 월
        /// </summary>
        public string ConfirmDateMonth
        {
            get
            {
                string result = "";
                if (ConfirmDate.Length == 8)
                {
                    result = ConfirmDate.Substring(4, 2);
                }

                return result;
            }
        }

        /// <summary>
        /// 확인일 - 일
        /// </summary>
        public string ConfirmDateDay
        {
            get
            {
                string result = "";
                if (ConfirmDate.Length == 8)
                {
                    result = ConfirmDate.Substring(6, 2);
                }

                return result;
            }
        }

        /// <summary>
        /// 확인원 : 사업자번호
        /// </summary>
        public string VenNum { get; set; }

        public string VenNumFormat
        {
            get
            {
                string result = "";
                if (VenNum.Length >= 10)
                {
                    result = VenNum.Substring(0, 3) + "-" +
                        VenNum.Substring(3, 2) + "-" +
                        VenNum.Substring(5);
                }

                return result;
            }
        }


        /// <summary>
        /// 확인원 : 주소
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 확인원 : 상호
        /// </summary>
        public string 상호 { get; set; }

        /// <summary>
        /// 확인원 : 대표자
        /// </summary>
        public string Owner { get; set; }

        /// <summary>
        /// 외상매입금, 미도래어음 목록
        /// </summary>
        public List<BalancePrintItem> BalancePrintItems { get; set; }
        
        /// <summary>
        /// 차액정보 목록
        /// </summary>
        public List<차액내용> 차액정보 { get; set; }
        
        /// <summary>
        /// 물적담보 목록
        /// </summary>
        public List<BalanceLienItem> LienItems { get; set; }

        /// <summary>
        /// 거래장잔고 합계
        /// </summary>
        public string BalanceSheetAmount 
        { 
            get
            {
                decimal? sum = BalancePrintItems.Select(i => i.SheetBalanceAmount).Sum();
                return sum != null ? Convert.ToDecimal(sum).ToString("#,#") : "0";
            }
        }

        /// <summary>
        /// 거래처잔고 합계
        /// </summary>
        public string BalanceCustAmount
        {
            get
            {
                decimal? sum = BalancePrintItems.Select(i => i.CustBalanceAmount).Sum();
                return sum != null ? Convert.ToDecimal(sum).ToString("#,#") : "";
            }
        }

        /// <summary>
        /// 차액 합계
        /// </summary>
        public string BalanceDifferenceAmount
        {
            get
            {
                decimal? sum = BalancePrintItems.Select(i => i.DifferenceAmount).Sum();
                return sum != null ? Convert.ToDecimal(sum).ToString("#,#") : "";
            }
        }

    }

    /// <summary>
    /// 차액내용
    /// </summary>
    public class 차액내용
    {

    }
    public class BalancePrintList
    {
        public List<BalancePrintVM> balanceList { get; set; }
    }
}
