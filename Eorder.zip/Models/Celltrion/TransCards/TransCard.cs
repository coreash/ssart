﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class TransCard
    {
        /// <summary>
        /// 거래일자
        /// </summary>
        public string TransDate { get; set; }      // 거래일자

        public string TransDateYymmdd
        {
            get
            {
                string result = "";
                DateTime saleDateTime;
                if (!string.IsNullOrWhiteSpace(TransDate) && DateTime.TryParseExact(TransDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDateTime))
                {
                    result = saleDateTime.ToString("yyyy.MM.dd");
                }
                return result;
            }
        }

        /// <summary>
        /// 전표번호
        /// </summary>
        public string TransNo { get; set; }      // 전표번호

        /// <summary>
        /// 간납처코드
        /// </summary>
        public string CustCode { get; set; }      // 거래처코드

        /// <summary>
        /// 간납처명
        /// </summary>
        public string CustName { get; set; }      // 거래처명

        /// <summary>
        /// 구분
        /// </summary>
        public string TransDi { get; set; }      // 구분

        /// <summary>
        /// 품목코드
        /// </summary>
        public string ProductCode { get; set; }      // 품목코드

        /// <summary>
        /// 품목명
        /// </summary>
        public string ProductName { get; set; }      // 품목명

        /// <summary>
        /// 매출액
        /// </summary>
        public decimal OutAmount { get; set; }      // 매출액

        /// <summary>
        /// 수금액
        /// </summary>
        public decimal ReceiveAmount { get; set; }      // 수금액

        /// <summary>
        /// 잔고
        /// </summary>
        public decimal BalanceAmount { get; set; }      // 잔고

        /// <summary>
        /// 비고
        /// </summary>
        public string Remark { get; set; }      // 비고

        /// <summary>
        /// 순번
        /// </summary>
        public long Num { get; set; }

        /// <summary>
        /// 레코드수
        /// </summary>
        public long TotalCount { get; set; }
    }
}
