﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class TransCardView
    {
        /// <summary>
        /// 순번
        /// </summary>
        public Int64 NUM { get; set; }

        /// <summary>
        /// 레코드수
        /// </summary>
        [JsonPropertyName("totalCount")]
        public Int64 TOTAL_COUNT { get; set; }
        public int PRT_SEQ { get; set; }
        public string GUBUN { get; set; }

        /// <summary>
        /// 일자
        /// </summary>
        [JsonPropertyName("salDate")]
        public string SAL_DATE { get; set; }

        /// <summary>
        /// 일자 - yymmdd 형식
        /// </summary>
        [JsonPropertyName("salDateYymmdd")]
        public string SAL_DATE_YYMMDD
        {
            get
            {
                string result = "";
                DateTime saleDateTime;
                if (!string.IsNullOrWhiteSpace(SAL_DATE) && DateTime.TryParseExact(SAL_DATE, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDateTime))
                {
                    result = saleDateTime.ToString("yyyy.MM.dd");
                }
                return result;
            }
        }

        public DateTime? SAL_DT { get; set; }
        public string SAL_GB { get; set; }

        /// <summary>
        /// 전표번호
        /// </summary>
        [JsonPropertyName("ordNo")]
        public string ORD_NO { get; set; }

        /// <summary>
        /// 전표세부번호
        /// </summary>
        [JsonPropertyName("seqNo")]
        public int? SEQ_NO { get; set; }
        public string GB { get; set; }

        /// <summary>
        /// 제품코드
        /// </summary>
        [JsonPropertyName("itemCd")]
        public string ITEM_CD { get; set; }

        /// <summary>
        /// 제품명
        /// </summary>
        [JsonPropertyName("itemNm")]
        public string ITEM_NM { get; set; }
        /// <summary>
        /// 규격
        /// </summary>
        [JsonPropertyName("contentUnit")]
        public string contentUnit { get; set; }

        /// <summary>
        /// 수량
        /// </summary>
        [JsonPropertyName("salQty")]
        public decimal? SAL_QTY { get; set; }
        public decimal? GIV_QTY { get; set; }
        /// <summary>
        /// 단가
        /// </summary>
        [JsonPropertyName("salPrc")]
        public decimal? SAL_PRC { get; set; }
        public decimal? SAL_amt { get; set; }
        public decimal? SAL_vat { get; set; }

        /// <summary>
        /// 매출액
        /// </summary>
        [JsonPropertyName("outAmount")]
        public decimal? SAL_NET { get; set; }
        public decimal? AFT_AMT { get; set; }

        /// <summary>
        /// 수금액
        /// </summary>
        [JsonPropertyName("colAmt")]
        public decimal? COL_AMT { get; set; }
        public decimal? BIL_COL { get; set; }
        public int? TURN_DT { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        [JsonPropertyName("custCd")]
        public string CUST_CD { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        [JsonPropertyName("custNm")]
        public string CUST_NM { get; set; }

        /// <summary>
        /// 간납처코드
        /// </summary>
        [JsonPropertyName("eCustCd")]
        public string ECUST_CD { get; set; }

        /// <summary>
        /// 간납처명
        /// </summary>
        [JsonPropertyName("eCustNm")]
        public string ECUST_NM { get; set; }
        public string REMARK { get; set; }

        /// <summary>
        /// 잔고
        /// </summary>
        [JsonPropertyName("balanceAmount")]
        public decimal? RMD_AMT { get; set; }
        public decimal? BIL_AMT { get; set; }

        public decimal? T_RMD_AMT { get; set; }
        public string CHB_GB { get; set; }
        public string data_gb { get; set; }

        /// <summary>
        /// 체크박스 선택
        /// </summary>
        [JsonPropertyName("selected")]
        public string SELECTED 
        { 
            get
            {
                return "";
            }
        }

        /// <summary>
        /// 행 글자색
        /// </summary>
        [JsonPropertyName("trClass")]
        public string TrClass
        {
            get
            {
                string result = string.Empty;

                if ("BD".Equals(SAL_GB, StringComparison.OrdinalIgnoreCase))
                {
                    result = "clrRed";
                }
                //else if ("AD".Equals(SAL_GB, StringComparison.OrdinalIgnoreCase) && "24" == DATA_GB)
                //{
                //    result = "clrGreen";
                //}
                else if ("W" == GUBUN)  // 월계
                {
                    result = "clrBlue";
                }
                else if ("Y" == GUBUN)  // 년계
                {
                    result = "clrPurple";
                }

                return result;
            }
        }
    }
}
