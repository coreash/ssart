﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class BalanceCust
    {
        /// <summary>
        /// 순번
        /// </summary>
        [Key]
        public Int64 NUM { get; set; }

        public string CUST_CD { get; set; }
        public string CUST_NM { get; set; }
        public string BUSIN_NO { get; set; }
        public string CEO_NM { get; set; }
        public string ADDRESS { get; set; }
        public decimal TOT_AMT_J { get; set; }
        public decimal BIL_AMT_SUM { get; set; }
    }
}
