﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class TransCardSearch
    {
        /// <summary>
        /// 시작일
        /// </summary>
        private string _startDate;

        public string StartDate
        {
            get { return (_startDate ?? "").Replace("-", ""); }
            set { _startDate = value; }
        }

        /// <summary>
        /// 종료일
        /// </summary>
        private string _endDate;

        public string EndDate
        {
            get { return (_endDate ?? "").Replace("-", ""); }
            set { _endDate = value; }
        }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 간납처코드
        /// </summary>
        public string DropCd { get; set; }

        /// <summary>
        /// 페이지번호
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 페이지크기
        /// </summary>
        public int PageSize { get; set; }

        public bool IsValid
        {
            get
            {
                bool result = false;

                if (string.IsNullOrWhiteSpace(StartDate) && string.IsNullOrWhiteSpace(EndDate) && string.IsNullOrWhiteSpace(VenCd))
                {
                    result = true;
                }
                else if (DateTime.TryParseExact(StartDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime startDate) && 
                    DateTime.TryParseExact(EndDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime endDate) &&
                    (string.IsNullOrWhiteSpace(VenCd) || int.TryParse(VenCd, out int venCd)))
                {
                    result = true;
                }

                return result;
            }
        }

        public string VenNum { get; set; }
    }
}
