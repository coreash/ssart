﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class TransCardView2
    {
        /// <summary>
        /// 순번
        /// </summary>
        [Key]
        public Int64 NUM { get; set; }

        /// <summary>
        /// 레코드수
        /// </summary>
        [JsonPropertyName("totalCount")]
        public Int64 TOTAL_COUNT { get; set; }

        /// <summary>
        /// 데이터유형
        /// </summary>
        [JsonPropertyName("dataType")]
        public string DATA_TYPE { get; set; }

        /// <summary>
        /// 사업장코드
        /// </summary>
        [JsonPropertyName("plantCd")]
        public string PLANT_CD { get; set; }
        
        /// <summary>
        /// 주문구분
        /// </summary>
        [JsonPropertyName("salGb")]
        public string SAL_GB { get; set; }

        [JsonPropertyName("salGbText")]
        public string SAL_GB_TEXT
        {
            get
            {
                string result = SAL_GB ?? "";

                if (string.IsNullOrWhiteSpace(SAL_GB))
                {
                    return result;
                }

                switch (SAL_GB)
                {
                    case "AA": result = "증정용(영업부)"; 
                        break;
                    case "AD": result = "사업자매출"; 
                        break;
                    case "AH": result = "직원용"; 
                        break;
                    case "AJ": result = "자가소비"; 
                        break;
                    case "AK": result = "견본품(영업외)"; 
                        break;
                    case "AM": result = "수출"; 
                        break;
                    case "AN": result = "군납"; 
                        break;
                    case "AP": result = "기타"; 
                        break;
                    case "AR": result = "선출고"; 
                        break;
                    case "BD": result = "반품"; 
                        break;
                    case "BF": result = "인거반품"; 
                        break;
                    default: result = "";
                        break;
                }

                return result;
            }
        }

        /// <summary>
        /// 전표번호
        /// </summary>
        [JsonPropertyName("ordNo")]
        public string ORD_NO { get; set; }

        /// <summary>
        /// 전표세부번호
        /// </summary>
        [JsonPropertyName("seqNo")]
        public int SEQ_NO { get; set; }

        /// <summary>
        /// 일자
        /// </summary>
        [JsonPropertyName("salDt")]
        public string SAL_DT    { get; set; }

        /// <summary>
        /// 일자 - yymmdd 형식
        /// </summary>
        [JsonPropertyName("salDtYymmdd")]
        public string SAL_DT_YYMMDD
        {
            get
            {
                string result = "";
                DateTime saleDateTime;
                if (!string.IsNullOrWhiteSpace(SAL_DT) && DateTime.TryParseExact(SAL_DT, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDateTime))
                {
                    result = saleDateTime.ToString("yyyy.MM.dd");
                }
                return result;
            }
        }

        /// <summary>
        /// 자료구분
        /// </summary>
        [JsonPropertyName("dataGb")]
        public string DATA_GB   { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        [JsonPropertyName("custCd")]
        public string CUST_CD   { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        [JsonPropertyName("custNm")]
        public string CUST_NM { get; set; }

        /// <summary>
        /// 간납처코드
        /// </summary>
        [JsonPropertyName("eCustCd")]
        public string ECUST_CD  { get; set; }

        /// <summary>
        /// 간납처명
        /// </summary>
        [JsonPropertyName("eCustNm")]
        public string ECUST_NM  { get; set; }

        /// <summary>
        /// 부서코드
        /// </summary>
        [JsonPropertyName("deptCd")]
        public string DEPT_CD   { get; set; }

        /// <summary>
        /// 사원코드
        /// </summary>
        [JsonPropertyName("empCd")]
        public string EMP_CD    { get; set; }

        /// <summary>
        /// 유통구분
        /// </summary>
        [JsonPropertyName("utGb")]
        public string UT_GB     { get; set; }

        /// <summary>
        /// 제품코드
        /// </summary>
        [JsonPropertyName("itemCd")]
        public string ITEM_CD   { get; set; }

        /// <summary>
        /// 제품명
        /// </summary>
        [JsonPropertyName("itemNm")]
        public string ITEM_NM   { get; set; }

        /// <summary>
        /// 수량
        /// </summary>
        [JsonPropertyName("salQty")]
        public decimal SAL_QTY   { get; set; }

        /// <summary>
        /// 단가
        /// </summary>
        [JsonPropertyName("salPrc")]
        public double SAL_PRC   { get; set; }

        /// <summary>
        /// 공급가액
        /// </summary>
        [JsonPropertyName("salAmt")]
        public decimal SAL_AMT   { get; set; }

        /// <summary>
        /// 부가세
        /// </summary>
        [JsonPropertyName("salVat")]
        public decimal SAL_VAT   { get; set; }

        /// <summary>
        /// 수금액
        /// </summary>
        [JsonPropertyName("colAmt")]
        public decimal COL_AMT   { get; set; }

        /// <summary>
        /// 어음번호
        /// </summary>
        [JsonPropertyName("kbilno")]
        public string KBILNO    { get; set; }

        /// <summary>
        /// 만기일
        /// </summary>
        [JsonPropertyName("expDt")]
        public string EXP_DT    { get; set; }

        /// <summary>
        /// 계좌번호
        /// </summary>
        [JsonPropertyName("cbnkno")]
        public string CBNKNO    { get; set; }

        /// <summary>
        /// 카드번호
        /// </summary>
        [JsonPropertyName("cardNo")]
        public string CARD_NO { get; set; }

        /// <summary>
        /// 체크박스 선택
        /// </summary>
        [JsonPropertyName("selected")]
        public string SELECTED { get; set; }

        /// <summary>
        /// 매출액
        /// </summary>
        public decimal OutAmount
        {
            get
            {
                return SAL_AMT + SAL_VAT;
            }
        }

        /// <summary>
        /// 잔고
        /// </summary>
        [JsonPropertyName("balanceAmount")]
        public decimal BALANCE_AMT { get; set; }

        /// <summary>
        /// 행 글자색
        /// </summary>
        [JsonPropertyName("trClass")]
        public string TrClass 
        { 
            get
            {
                string result = string.Empty;

                if ("BD".Equals(SAL_GB, StringComparison.OrdinalIgnoreCase))
                {
                    result = "clrRed";
                }
                else if ("AD".Equals(SAL_GB, StringComparison.OrdinalIgnoreCase) && "24" == DATA_GB)
                {
                    result = "clrGreen";
                }
                else if ("3" == DATA_TYPE)  // 월계
                {
                    result = "clrBlue";
                }
                else if ("4" == DATA_TYPE)  // 년계
                {
                    result = "clrPurble";
                }

                return result;
            }
        }
    }
}
