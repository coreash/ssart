﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion.TransCards
{
    public class TransCardViewExcel
    {
        public string 일자 { get; set; }
        public string 전표번호 { get; set; }
        public string 구분 { get; set; }
        public string 간납처명 { get; set; }
        public string 품목명 { get; set; }
        public string 규격 { get; set; }
        public decimal 수량 { get; set; }
        public decimal 단가 { get; set; }
        public decimal 매출액 { get; set; }
        public decimal 수금액 { get; set; }
        public decimal 잔고 { get; set; }
    }
}
