﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Eorder.Models.Celltrion.TransCards
{
    /// <summary>
    /// 물적담보
    /// </summary>
    public class BalanceLienItem
    {
        /// <summary>
        /// 순번
        /// </summary>
        [Key]
        public Int64 NUM { get; set; }

        /// <summary>
        /// 담보종류
        /// </summary>
        public string Kind { get; set; }

        /// <summary>
        /// 담보금액
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// 만기일자
        /// </summary>
        public string ExpireDate { get; set; }

        /// <summary>
        /// 발행처
        /// </summary>
        public string GuarantorName { get; set; }
    }
}
