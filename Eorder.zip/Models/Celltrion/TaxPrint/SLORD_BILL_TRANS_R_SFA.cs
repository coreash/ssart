﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    /// <summary>
    /// 세금계산서 목록
    /// </summary>
    public class SLORD_BILL_TRANS_R_SFA
    {
        /// <summary>
        /// 주문일자
        /// </summary>
        public string SalDt { get; set; }
        /// <summary>
        /// 순번
        /// </summary>
        public Int32 TaxSeq { get; set; }
        /// <summary>
        /// 요약
        /// </summary>
        public string Summary { get; set; }
        /// <summary>
        /// 비고
        /// </summary>
        public string Bigo { get; set; }

        /// <summary>
        /// 공급가액
        /// </summary>
        public Int64 Amt { get; set; }
        /// <summary>
        /// 세액
        /// </summary>
        public Int64 Vat { get; set; }
        
    }
}
