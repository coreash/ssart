﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Celltrion
{
    /// <summary>
    /// 세금계산서 출력물
    /// </summary>
    public class SLORD_TAXBILL_PRINT_SFA
    {
        /// <summary>
        /// 공급받는자 거래처명
        /// </summary>
        public string CustNm { get; set; }
        /// <summary>
        /// 공급받는자 CEO명
        /// </summary>
        public string CeoNm { get; set; }
        /// <summary>
        /// 공급받는자 주소
        /// </summary>
        public string Addr { get; set; }
        /// <summary>
        /// 공급받는자 업태
        /// </summary>
        public string CatGoNm { get; set; }
        /// <summary>
        /// 공급받는자 종목
        /// </summary>
        public string BusinNm { get; set; }
        /// <summary>
        /// 공급받는자 사업자번호
        /// </summary>
        public string VenNum { get; set; }
        /// <summary>
        /// 일련번호(권/호)
        /// </summary>
        public string OrdNo { get; set; }
        /// <summary>
        /// 공급자 주소
        /// </summary>
        public string TaxAddr { get; set; }
        /// <summary>
        /// 공급자 사업자번호
        /// </summary>
        public string TaxVenNum { get; set; }
        /// <summary>
        /// 계산서 작성일
        /// </summary>
        public string TaxDate { get; set; }
        /// <summary>
        /// 매출월
        /// </summary>
        public string Month { get; set; }
        /// <summary>
        /// 매출일
        /// </summary>
        public string Day { get; set; }
        /// <summary>
        /// 요약( a제품 외 x건)
        /// </summary>
        public string Summary { get; set; }
        /// <summary>
        /// 공급가액
        /// </summary>
        public Int64 Amt { get; set; }
        /// <summary>
        /// 세액
        /// </summary>
        public Int64 Vat { get; set; }
        /// <summary>
        /// 전문의약품 금액
        /// </summary>
        public Int64 AmtChb1 { get; set; }
        /// <summary>
        /// 일반의약품 금액
        /// </summary>
        public Int64 AmtChb2 { get; set; }
        /// <summary>
        /// 합계
        /// </summary>
        public Int64 SumAmt { get; set; }
        /// <summary>
        /// 공란수
        /// </summary>
        public Int32 BlkCnt { get; set; }
        /// <summary>
        /// 공급가액 자리수
        /// </summary>
        public string CharAmt1 { get; set; }
        public string CharAmt2 { get; set; }
        public string CharAmt3 { get; set; }
        public string CharAmt4 { get; set; }
        public string CharAmt5 { get; set; }
        public string CharAmt6 { get; set; }
        public string CharAmt7 { get; set; }
        public string CharAmt8 { get; set; }
        public string CharAmt9 { get; set; }
        public string CharAmt10 { get; set; }
        /// <summary>
        /// 세액 자리수
        /// </summary>
        public string CharVat1 { get; set; }
        public string CharVat2 { get; set; }
        public string CharVat3 { get; set; }
        public string CharVat4 { get; set; }
        public string CharVat5 { get; set; }
        public string CharVat6 { get; set; }
        public string CharVat7 { get; set; }
        public string CharVat8 { get; set; }
        public string CharVat9 { get; set; }
        /// <summary>
        /// 비고
        /// </summary>
        public string BanTax { get; set; }
    }
}
