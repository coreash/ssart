﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models
{
    public class Paging: IPaging<object>
    {
        public int Count { get; set; }
        public IEnumerable<object> List { get; set; }
    }

    public interface IPaging<T>
    {
        int Count { get; set; }

        IEnumerable<T> List { get; set; }
    }

    
}
