﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo031
    {
        public string Eo31DropCd { get; set; }
        public string Eo31DropNm { get; set; }
        public string Eo31OwnerNm { get; set; }
        public string Eo31Tel { get; set; }
        public string Eo31ZipCode { get; set; }
        public string Eo31Address { get; set; }
        public string Eo31DelFlag { get; set; }
    }
}
