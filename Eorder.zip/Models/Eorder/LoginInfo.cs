﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class LoginInfo
    {
        public string userCd { get; set; }
        public string userNm { get; set; }
        public string id { get; set; }
        public string pwd { get; set; }
        public string venCd { get; set; }
        public string venNm { get; set; }
        public string userKind { get; set; }
        public string needChangePw { get; set; }
    }
}
