﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class ProcedureResult
    {
        /// <summary>
        /// 처리건수 - 등록, 수정, 삭제 건수
        /// </summary>
        public int ProcCount { get; set; }

        /// <summary>
        /// 처리시 사용한 키값
        /// </summary>
        public string ProcData { get; set; }

        /// <summary>
        /// 처리결과 메시지 - "OK", "ERROR"
        /// </summary>
        public string ProcMessage { get; set; }

        /// <summary>
        /// 처리에러 메시지
        /// </summary>
        public string ProcErrorMessage { get; set; }

        /// <summary>
        /// 처리시 생성된 추가 정보
        /// </summary>
        public string ProcReturnData { get; set; }
    }
}
