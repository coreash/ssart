﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDownStatusExcel
    {
        public string 거래처코드 { get; set; }
        public string 거래처명 { get; set; }
        public string 업로드현황 { get; set; }
    }
}
