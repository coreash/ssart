﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDownSearch
    {
        /// <summary>
        /// 시작일
        /// </summary>
        private string _startDate;

        public string StartDate
        {
            get { return (_startDate ?? "").Replace("-", ""); }
            set { _startDate = value; }
        }

        /// <summary>
        /// 종료일
        /// </summary>
        private string _endDate;

        public string EndDate
        {
            get { return (_endDate ?? "").Replace("-", ""); }
            set { _endDate = value; }
        }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 품목명
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 페이지번호
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 페이지크기
        /// </summary>
        public int PageSize { get; set; }

    }
}
