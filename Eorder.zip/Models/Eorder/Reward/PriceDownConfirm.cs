﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDownConfirm
    {
        public string DownDate { get; set; }
        public string VenCd { get; set; }
        public string DropCd { get; set; }
        public string StandardCd { get; set; }
        public int Quantity { get; set; }
        public int Seq { get; set; }

    }
}
