﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDown
    {
        /// <summary>
        /// 순번
        /// </summary>
        public long Num { get; set; }
        
        /// <summary>
        /// 레코드 개수
        /// </summary>
        public long TotalCount { get; set; }
        
        /// <summary>
        /// 인하일자
        /// </summary>
        public string DownDate { get; set; }

        /// <summary>
        /// 제품코드
        /// </summary>
        public string PhysicCd { get; set; }

        /// <summary>
        /// 인하전 단가
        /// </summary>
        public decimal PreUnitCost { get; set; }
        
        /// <summary>
        /// 인하후 단가
        /// </summary>
        public decimal UnitCost { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 간납처코드
        /// </summary>
        public string DropCd { get; set; }

        /// <summary>
        /// 표준코드
        /// </summary>
        public string StandardCd { get; set; }
        
        /// <summary>
        /// 거래처 업로드시 정보 중복제거용 순번
        /// </summary>
        public int? Seq { get; set; }

        /// <summary>
        /// 수량
        /// </summary>
        public int? Quantity { get; set; }
        
        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime? AddDate { get; set; }

        public string AddDateYymmdd
        {
            get
            {
                string result = "";
                if (AddDate != null)
                {
                    result = AddDate.Value.ToString("yyyyMMdd");
                }

                return result;
            }
        }

        /// <summary>
        /// 승인수량
        /// </summary>
        public int? ConfirmQuantity { get; set; }

        /// <summary>
        /// 승인일
        /// </summary>
        public string ConfirmDate { get; set; }

        /// <summary>
        /// 승인구분
        /// </summary>
        public string ConfirmFlag { get; set; }

        /// <summary>
        /// 제품명
        /// </summary>
        public string PhysicNm { get; set; }

        /// <summary>
        /// 규격
        /// </summary>
        public string Standard { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string VenNm { get; set; }

        /// <summary>
        /// 거래처 사업자번호
        /// </summary>
        public string VenNum { get; set; }

        /// <summary>
        /// 간납처명
        /// </summary>
        public string DropNm { get; set; }

        /// <summary>
        /// 간납처 우편번호
        /// </summary>
        public string DropZipCode { get; set; }

        /// <summary>
        /// 간납처 주소
        /// </summary>
        public string DropAddress { get; set; }

        /// <summary>
        /// 간납처 사업자번호
        /// </summary>
        public string DropVenNum { get; set; }

        /// <summary>
        /// 간납 담당자코드
        /// </summary>
        public string DropSalesManCd { get; set; }

        /// <summary>
        /// 간납 담당자명
        /// </summary>
        public string DropSalesManNm { get; set; }

        /// <summary>
        /// 3개월매출수량
        /// </summary>
        public int Last3MonthQuantity { get; set; }

        /// <summary>
        /// 차액
        /// </summary>
        public decimal DiffUnitCost
        {
            get { return PreUnitCost - UnitCost; }
        }

        /// <summary>
        /// 금액
        /// </summary>
        public decimal Amount { get { return DiffUnitCost * (ConfirmQuantity ?? 0); } }

        /// <summary>
        /// 체크박스 선택
        /// </summary>
        public string Selected { get; set; }
        
        public string IsShowCheckBox 
        { 
            get
            {
                string result = "Y";

                if (!string.IsNullOrWhiteSpace(ConfirmFlag) && ConfirmFlag == "Y")
                {
                    result = "N";
                }

                return result;
            }
        }

    }
}
