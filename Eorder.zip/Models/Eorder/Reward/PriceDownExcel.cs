﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDownExcel
    {
        public string 인하일자 { get; set; }
        public string 간납처코드 { get; set; }
        public string 표준코드 { get; set; }
        public int? 수량 { get; set; }

    }
}
