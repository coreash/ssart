﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Reward
{
    public class PriceDownExcelAdmin
    {
        public long 순번 { get; set; }
        public string 인하일자 { get; set; }
        public string 거래처코드 { get; set; }
        public string 거래처명 { get; set; }
        public string 사업자번호 { get; set; }
        public string 간납처코드 { get; set; }
        public string 간납처명 { get; set; }
        public string 주소 { get; set; }
        public string 우편번호 { get; set; }
        public string 간납담당자 { get; set; }
        public string 표준코드 { get; set; }
        public string 제품명 { get; set; }
        public string 규격 { get; set; }
        public decimal 인하전 { get; set; }
        public decimal 인하후 { get; set; }
        public decimal 차액 { get; set; }
        public int 최근3개월매출수량 { get; set; }
        public int? 보상수량 { get; set; }
        public decimal? 금액 { get; set; }
        public string 업로드일자 { get; set; }
    }
}
