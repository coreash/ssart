﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class ProductMap
    {
        public Eo030 eo030 { get; set; }
        public Eo031 eo031 { get; set; }
        public Eo040 eo040 { get; set; }
        public Eo041 eo041 { get; set; }

        public ProductMap(Eo030 eo030, Eo031 eo031, Eo040 eo040, Eo041 eo041)
        {
            this.eo030 = eo030;
            this.eo031 = eo031;
            this.eo040 = eo040;
            this.eo041 = eo041;
        }
    }
}
