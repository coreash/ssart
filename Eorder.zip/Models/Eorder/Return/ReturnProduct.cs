﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class ReturnProduct
    {
        #region 반품 가능 제품 목록
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CustCd { get; set; }
        /// <summary>
        /// 간납처코드
        /// </summary>
        public string ECustCd { get; set; }
        /// <summary>
        /// 제품코드
        /// </summary>
        public string ItemCd { get; set; }
        /// <summary>
        /// 단가
        /// </summary>
        public decimal DrugPrc { get; set; }
        /// <summary>
        /// 최종매출일
        /// </summary>
        public DateTime SalDt { get; set; }
        #endregion
    }

}
