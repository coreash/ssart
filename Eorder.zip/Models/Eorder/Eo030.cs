﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo030
    {
        public string Eo03VenCd { get; set; }
        public string Eo03VenNm { get; set; }
        public string Eo03VenNum { get; set; }
        public string Eo03OwnerNm { get; set; }
        public string Eo03Phone { get; set; }
        public string Eo03Fax { get; set; }
        public string Eo03ZipCode { get; set; }
        public string Eo03Address { get; set; }
        public string Eo03StopTradeGubun { get; set; }
        public string Eo03WarehouseZipCode { get; set; }
        public string Eo03WarehouseAddr { get; set; }
        public string Eo03LastOutDate { get; set; }
        public string Eo03LastReceiveDate { get; set; }
        public decimal? Eo03NoteAmount { get; set; }
        public decimal? Eo03NotReceiveAmount { get; set; }
        public int? Eo03RotationDay { get; set; }
        public decimal? Eo03TotBalance { get; set; }
        public decimal? Eo03ReceiveAmount { get; set; }
        public string Eo03RemarkLeader { get; set; }
        public string Eo03RemarkSales { get; set; }
        public DateTime? Eo03AuthDateLeader { get; set; }
        public DateTime? Eo03AuthDateOfficer { get; set; }
        public string Eo03DelFlag { get; set; }
        public string Eo03SalesMan { get; set; }
    }
}
