﻿using System;
using Eorder.Models.Celltrion;
using Eorder.Models.Celltrion.TransCards;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eorder_CelltrionContext : DbContext
    {
        public Eorder_CelltrionContext()
        {
        }

        public Eorder_CelltrionContext(DbContextOptions<Eorder_CelltrionContext> options)
            : base(options)
        {
        }

        [DbFunction("GET_ORDERDATE", "dbo")]
        public string GetOrderDate()
        {
            throw new NotSupportedException();
        }

        public virtual DbSet<Eo010> Eo010s { get; set; }
        public virtual DbSet<Eo030> Eo030s { get; set; }
        public virtual DbSet<Eo031> Eo031s { get; set; }
        public virtual DbSet<Eo040> Eo040s { get; set; }
        public virtual DbSet<Eo041> Eo041s { get; set; }
        public virtual DbSet<Eo042> Eo042s { get; set; }
        public virtual DbSet<Eo060> Eo060s { get; set; }
        public virtual DbSet<Eo061> Eo061s { get; set; }
        public virtual DbSet<Eo150> Eo150s { get; set; }
        public virtual DbSet<Eo160> Eo160s { get; set; }
        public virtual DbSet<EoboardNotice> EoboardNotices { get; set; }

        public virtual DbSet<EoOrderMemo> EoOrderMemos { get; set; }
        public virtual DbSet<EoOrderTime> EoOrderTimes { get; set; }
        public virtual DbSet<EoPopup> EoPopups { get; set; }
        public virtual DbSet<EoHoliday> EoHolidays { get; set; }
        public virtual DbSet<EoBag> EoBags { get; set; }
        public virtual DbSet<Eo033> Eo033s { get; set; }
        public virtual DbSet<Eo043> Eo043s { get; set; }
        public virtual DbSet<TransCardView> TransCardViews { get; set; }
        public virtual DbSet<BalanceCust> BalanceCusts { get; set; }
        public virtual DbSet<BalanceLienItem> BalanceLienItems { get; set; }
        public virtual DbSet<EoCollectMoney> EoCollectMonies { get; set; }
        
        public virtual DbSet<OrderSearchVenChk> OrderSearchVenChks { get; set; }
        public virtual DbSet<CM_CUST_AD_VW> CM_CUST_AD_VWs { get; set; }
        public virtual DbSet<EoCardPayment> EoCardPayments { get; set; }
        public virtual DbSet<KSNET_PGARG> KSNET_PGARGs { get; set; }
        public virtual DbSet<SLORD_BILL_TRANS_R_SFA> SLORD_BILL_TRANS_R_SFAs { get; set; }
        public virtual DbSet<SLORD_TAXBILL_PRINT_SFA> SLORD_TAXBILL_PRINT_SFAs { get; set; }
        public virtual DbSet<SL102M01_SFA> SL102M01_SFAs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Korean_Wansung_CI_AS");

            modelBuilder.Entity<Eo010>(entity =>
            {
                entity.HasKey(e => new { e.Eo01Gcode, e.Eo01Tcode });

                entity.ToTable("EO010");

                entity.HasComment("코드");

                entity.Property(e => e.Eo01Gcode)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("EO01_Gcode")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("마스터코드");

                entity.Property(e => e.Eo01Tcode)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO01_Tcode")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("디테일코드");

                entity.Property(e => e.Eo01AddDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EO01_Add_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("등록일시");

                entity.Property(e => e.Eo01DelFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO01_Del_Flag")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("삭제여부");

                entity.Property(e => e.Eo01Hnm)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("EO01_Hnm")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("한글명");
            });

            modelBuilder.Entity<Eo030>(entity =>
            {
                entity.HasKey(e => e.Eo03VenCd);

                entity.ToTable("EO030");

                entity.HasComment("거래처");

                entity.Property(e => e.Eo03VenCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Ven_Cd")
                    .HasDefaultValueSql("('00000')")
                    .HasComment("거래처코드");

                entity.Property(e => e.Eo03Address)
                    .IsRequired()
                    .HasMaxLength(1000)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Address")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("주소");

                entity.Property(e => e.Eo03AuthDateLeader)
                    .HasColumnType("datetime")
                    .HasColumnName("EO03_AuthDateLeader")
                    .HasComment("팀장승인일시");

                entity.Property(e => e.Eo03AuthDateOfficer)
                    .HasColumnType("datetime")
                    .HasColumnName("EO03_AuthDateOfficer")
                    .HasComment("영관승인일시");

                entity.Property(e => e.Eo03DelFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Del_Flag")
                    .IsFixedLength(true);

                entity.Property(e => e.Eo03Fax)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Fax")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("팩스번호");

                entity.Property(e => e.Eo03LastOutDate)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO03_LastOutDate")
                    .HasComment("최종판매일");

                entity.Property(e => e.Eo03LastReceiveDate)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO03_LastReceiveDate")
                    .HasComment("최종수금일");

                entity.Property(e => e.Eo03NotReceiveAmount)
                    .HasColumnType("decimal(19, 0)")
                    .HasColumnName("EO03_NotReceiveAmount")
                    .HasComment("미수금");

                entity.Property(e => e.Eo03NoteAmount)
                    .HasColumnType("decimal(19, 0)")
                    .HasColumnName("EO03_NoteAmount")
                    .HasComment("미도래어음");

                entity.Property(e => e.Eo03OwnerNm)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Owner_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("거래처대표자명");

                entity.Property(e => e.Eo03Phone)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Phone")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("전화번호");

                entity.Property(e => e.Eo03ReceiveAmount)
                    .HasColumnType("decimal(19, 0)")
                    .HasColumnName("EO03_ReceiveAmount")
                    .HasComment("수금예정액");

                entity.Property(e => e.Eo03RemarkLeader)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO03_RemarkLeader")
                    .HasComment("비고(팀장)");

                entity.Property(e => e.Eo03RemarkSales)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO03_RemarkSales")
                    .HasComment("비고(영업관리)");

                entity.Property(e => e.Eo03RotationDay)
                    .HasColumnName("EO03_RotationDay")
                    .HasComment("회전일");

                entity.Property(e => e.Eo03StopTradeGubun)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO03_StopTradeGubun")
                    .HasComment("거래정지구분(0:정상,1:거래정지),");

                entity.Property(e => e.Eo03TotBalance)
                    .HasColumnType("decimal(19, 0)")
                    .HasColumnName("EO03_TotBalance")
                    .HasComment("총잔액");

                entity.Property(e => e.Eo03VenNm)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Ven_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("거래처명");

                entity.Property(e => e.Eo03VenNum)
                    .IsRequired()
                    .HasMaxLength(14)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Ven_Num")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("거래처사업자번호");

                entity.Property(e => e.Eo03WarehouseAddr)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Warehouse_Addr")
                    .HasComment("창고소재지 주소");

                entity.Property(e => e.Eo03WarehouseZipCode)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Warehouse_ZipCode")
                    .HasComment("창고소재지 우편번호");

                entity.Property(e => e.Eo03ZipCode)
                    .IsRequired()
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Zip_Code")
                    .HasDefaultValueSql("('999-999')")
                    .HasComment("우편번호");
                entity.Property(e => e.Eo03SalesMan)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO03_Sales_Man")
                    .HasDefaultValueSql("('')")
                    .HasComment("담당자");
            });

            modelBuilder.Entity<Eo031>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("EO031");

                entity.HasComment("거래처별납품처");

                entity.Property(e => e.Eo31Address)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Address")
                    .HasComment("주소");

                entity.Property(e => e.Eo31DelFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Del_Flag")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("삭제여부");

                entity.Property(e => e.Eo31DropCd)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Drop_Cd")
                    .HasComment("납품처코드");

                entity.Property(e => e.Eo31DropNm)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Drop_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("납품처명");

                entity.Property(e => e.Eo31OwnerNm)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Owner_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("납품처대표자명");

                entity.Property(e => e.Eo31Tel)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EO31_Tel")
                    .HasComment("전화번호");

                entity.Property(e => e.Eo31ZipCode)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO31_ZipCode")
                    .HasComment("우편번호");
            });

            modelBuilder.Entity<Eo040>(entity =>
            {
                entity.HasKey(e => e.Eo04PhysicCd);

                entity.ToTable("EO040");

                entity.HasComment("제품");

                entity.Property(e => e.Eo04PhysicCd)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Physic_Cd")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("제품코드");

                entity.Property(e => e.Eo04AccUnit)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("EO04_Acc_Unit")
                    .HasComment("계산단위");

                entity.Property(e => e.Eo04DelFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Del_Flag")
                    .IsFixedLength(true)
                    .HasComment("삭제여부");

                entity.Property(e => e.Eo04InsuPrice)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("EO04_Insu_Price")
                    .HasComment("제품가격");

                entity.Property(e => e.Eo04PhysicEnm)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Physic_Enm")
                    .HasComment("제품영문명");

                entity.Property(e => e.Eo04PhysicNm)
                    .HasMaxLength(200)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Physic_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("제품명");

                entity.Property(e => e.Eo04Standard)
                    .IsRequired()
                    .HasMaxLength(120)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Standard")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("규격");

                entity.Property(e => e.Eo04StandardCd)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Standard_Cd")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("표준코드");

                entity.Property(e => e.Eo04UseGu)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO04_Use_Gu")
                    .HasDefaultValueSql("('0')")
                    .IsFixedLength(true)
                    .HasComment("사용구분");
                entity.Property(e => e.Eo04ChbGb)
                    .HasColumnName("EO04_CHB_GB")
                    .HasComment("처방구분");
                entity.Property(e => e.Eo04HouseGb)
                    .HasColumnName("EO04_House_Gb")
                    .HasComment("창고구분");
            });

            modelBuilder.Entity<Eo041>(entity =>
            {
                entity.HasKey(e => new { e.Eo041VenCd, e.Eo041DropCd, e.Eo041PhysicCd });

                entity.ToTable("EO041");

                entity.Property(e => e.Eo041VenCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Ven_Cd")
                    .HasComment("거래처코드");

                entity.Property(e => e.Eo041DropCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Drop_Cd")
                    .HasComment("납품처코드");

                entity.Property(e => e.Eo041PhysicCd)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Physic_Cd")
                    .HasComment("제품코드");

                entity.Property(e => e.Eo041DelFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Del_Flag")
                    .IsFixedLength(true);

                entity.Property(e => e.Eo041EndDate)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO041_End_Date")
                    .IsFixedLength(true)
                    .HasComment("종료일");

                entity.Property(e => e.Eo041StartDate)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Start_Date")
                    .IsFixedLength(true)
                    .HasComment("시작일");

                entity.Property(e => e.Eo041UnitPrice)
                    .HasColumnType("decimal(19, 2)")
                    .HasColumnName("EO041_Unit_Price")
                    .HasComment("출하가");
                entity.Property(e => e.Eo041CtrPYl)
                    .HasColumnType("decimal(19, 2)")
                    .HasColumnName("EO041_CTR_P_YL")
                    .HasComment("사전할인");
                entity.Property(e => e.Eo041HpinYl)
                    .HasColumnType("decimal(19, 2)")
                    .HasColumnName("EO041_HPIN_YL")
                    .HasComment("원내할인");
                entity.Property(e => e.Eo041SalesManCd)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Sales_Man_Cd")
                    .HasComment("담당자코드");
                entity.Property(e => e.Eo041PossibleQty)
                    .IsUnicode(false)
                    .HasColumnName("EO041_Possible_Qty")
                    .HasComment("주문가능수량");

            });

            modelBuilder.Entity<Eo042>(entity =>
            {
                entity.HasKey(e => new { e.Eo042Date, e.Eo042PhysicCd });

                entity.ToTable("EO042");

                entity.Property(e => e.Eo042Date)
                    .HasMaxLength(8)
                    .HasColumnName("EO042_Date")
                    .HasComment("인하일자");
                entity.Property(e => e.Eo042PhysicCd)
                    .HasMaxLength(10)
                    .HasColumnName("EO042_Physic_Cd")
                    .HasComment("제품코드");
                entity.Property(e => e.Eo042PreUnitCost)
                    .HasColumnType("decimal(19, 2)")
                    .HasColumnName("EO042_Pre_Unit_Cost")
                    .HasComment("이전단가");
                entity.Property(e => e.Eo042UnitCost)
                    .HasColumnType("decimal(19, 2)")
                    .HasColumnName("EO042_Unit_Cost")
                    .HasComment("이후단가");
                entity.Property(e => e.Eo042DelFlag)
                    .HasMaxLength(1)
                    .HasColumnName("EO042_Del_Flag")
                    .HasDefaultValueSql("('N')")
                    .HasComment("사용여부");
                entity.Property(e => e.Eo042AddDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EO042_Add_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("설정일");
            });
            modelBuilder.Entity<Eo060>(entity =>
            {
                entity.HasKey(e => e.Eo06UserCd);

                entity.ToTable("EO060");

                entity.HasComment("사원정보");

                entity.Property(e => e.Eo06UserCd)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO06_User_Cd")
                    .HasDefaultValueSql("('000000')")
                    .IsFixedLength(true)
                    .HasComment("사용자코드");

                entity.Property(e => e.Eo06AdminFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO06_ADMIN_FLAG")
                    .IsFixedLength(true)
                    .HasComment("관리자여부");

                entity.Property(e => e.Eo06DelFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO06_Del_Flag")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("삭제여부");

                entity.Property(e => e.Eo06Email)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EO06_EMAIL")
                    .HasComment("이메일");

                entity.Property(e => e.Eo06EnableLogin)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO06_ENABLE_LOGIN")
                    .IsFixedLength(true)
                    .HasComment("로그인가능");

                entity.Property(e => e.Eo06Fax)
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("EO06_Fax")
                    .HasComment("팩스번호");

                entity.Property(e => e.Eo06ModCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO06_Mod_Cd")
                    .HasDefaultValueSql("('999999')");

                entity.Property(e => e.Eo06ModDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EO06_Mod_Date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Eo06OfficeTel)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("EO06_OFFICE_TEL")
                    .HasComment("전화번호");

                entity.Property(e => e.Eo06PartMove)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO06_PART_MOVE")
                    .IsFixedLength(true)
                    .HasComment("부서이동");

                entity.Ignore(x => x.Eo06Password);

                entity.Property(e => e.Eo06Pw)
                    .HasColumnName("EO06_Pw")
                    .HasComment("비밀번호");

                entity.Property(e => e.Eo06PhoneTel)
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("EO06_PHONE_TEL")
                    .HasComment("휴대폰");

                entity.Property(e => e.Eo06RetireFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO06_RETIRE_FLAG")
                    .IsFixedLength(true)
                    .HasComment("퇴직여부");

                entity.Property(e => e.Eo06UserId)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("EO06_User_ID")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("사용자아이디");

                entity.Property(e => e.Eo06UserNm)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO06_User_Nm")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("사용자명");
            });

            modelBuilder.Entity<Eo061>(entity =>
            {
                entity.HasKey(e => e.Eo61Num);

                entity.ToTable("EO061");

                entity.HasComment("회원");

                entity.Property(e => e.Eo61Num)
                    .ValueGeneratedNever()
                    .HasColumnName("EO61_NUM")
                    .HasComment("회원번호");

                entity.Property(e => e.Eo61AddDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EO61_ADD_DATE")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("등록일시");

                entity.Property(e => e.Eo61AddNum)
                    .HasColumnName("EO61_ADD_NUM")
                    .HasComment("등록번호");

                entity.Property(e => e.Eo61Address)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("EO61_ADDRESS")
                    .HasDefaultValueSql("('')")
                    .HasComment("주소");

                entity.Property(e => e.Eo61CompanyName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EO61_COMPANY_NAME")
                    .HasComment("회사명");

                entity.Property(e => e.Eo61CompanyNum)
                    .IsRequired()
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .HasColumnName("EO61_COMPANY_NUM")
                    .HasDefaultValueSql("('')")
                    .IsFixedLength(true)
                    .HasComment("사업자번호");

                entity.Property(e => e.Eo61DelFlag)
                    .HasColumnName("EO61_DEL_FLAG")
                    .HasComment("삭제여부");

                entity.Property(e => e.Eo61Dong)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("EO61_DONG")
                    .HasDefaultValueSql("('')")
                    .HasComment("동");

                entity.Property(e => e.Eo61Email)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EO61_EMAIL")
                    .HasDefaultValueSql("('')")
                    .HasComment("이메일");

                entity.Property(e => e.Eo61Fax)
                    .IsRequired()
                    .HasMaxLength(16)
                    .IsUnicode(false)
                    .HasColumnName("EO61_Fax")
                    .HasDefaultValueSql("('')");

                entity.Property(e => e.Eo61Gugun)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("EO61_GUGUN")
                    .HasDefaultValueSql("('')")
                    .HasComment("구군");

                entity.Property(e => e.Eo61Id)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("EO61_ID")
                    .HasComment("회원아이디");

                entity.Property(e => e.Eo61ListCnt)
                    .HasColumnName("EO61_ListCnt")
                    .HasDefaultValueSql("((10))");

                entity.Property(e => e.Eo61MemberKind)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO61_MEMBER_KIND")
                    .IsFixedLength(true)
                    .HasComment("회원구분");

                entity.Property(e => e.Eo61MemberVen)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO61_MEMBER_VEN")
                    .HasComment("거래처코드");

                entity.Property(e => e.Eo61ModDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EO61_MOD_DATE")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("수정일시");

                entity.Property(e => e.Eo61ModNum)
                    .HasColumnName("EO61_MOD_NUM")
                    .HasComment("수정번호");

                entity.Property(e => e.Eo61OfficeTel)
                    .IsRequired()
                    .HasMaxLength(40)
                    .IsUnicode(false)
                    .HasColumnName("EO61_OFFICE_TEL")
                    .HasComment("회사전화번호");

                entity.Ignore(x => x.Eo61Pwd);
                
                entity.Property(e => e.Eo61Pw)
                    .IsRequired()
                    .HasColumnName("EO61_PW")
                    .HasComment("비밀번호");

                entity.Property(e => e.Eo61RoadArea)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("EO61_RoadArea")
                    .HasDefaultValueSql("('')")
                    .IsFixedLength(true)
                    .HasComment("도로명주소우편번호");

                entity.Property(e => e.Eo61RoadNm)
                    .HasMaxLength(500)
                    .IsUnicode(false)
                    .HasColumnName("EO61_Road_Nm")
                    .HasDefaultValueSql("('')")
                    .HasComment("도로명주소");

                entity.Property(e => e.Eo61RoadNmDetail)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EO61_Road_Nm_Detail")
                    .HasDefaultValueSql("('')")
                    .HasComment("도로명주소상세");

                entity.Property(e => e.Eo61Sido)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("EO61_SIDO")
                    .HasDefaultValueSql("('')")
                    .HasComment("시도");

                entity.Property(e => e.Eo61StockCd)
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO61_Stock_Cd")
                    .HasDefaultValueSql("('')")
                    .HasComment("재고코드");

                entity.Property(e => e.Eo61UserName)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO61_USER_NAME")
                    .HasComment("회원명");

                entity.Property(e => e.Eo61ZipCode)
                    .HasMaxLength(7)
                    .IsUnicode(false)
                    .HasColumnName("EO61_ZIP_CODE")
                    .HasDefaultValueSql("('')")
                    .IsFixedLength(true)
                    .HasComment("우편번호");
            });

            modelBuilder.Entity<Eo150>(entity =>
            {
                entity.HasKey(e => new { e.Eo15ReYyMmDd, e.Eo15RevenCd, e.Eo15ReSeq });

                entity.ToTable("EO150");

                entity.HasComment("주문");

                entity.Property(e => e.Eo15ReYyMmDd)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Re_YyMmDd")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("주문접수일자");

                entity.Property(e => e.Eo15RevenCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Reven_Cd")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("거래처코드");

                entity.Property(e => e.Eo15ReSeq)
                    .HasColumnName("EO15_Re_Seq")
                    .HasComment("주문순번");

                entity.Property(e => e.Eo15AddCd)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Add_Cd")
                    .HasDefaultValueSql("('999999')")
                    .IsFixedLength(true)
                    .HasComment("등록자코드");

                entity.Property(e => e.Eo15AddDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EO15_Add_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("등록일시");

                entity.Property(e => e.Eo15DropCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Drop_Cd")
                    .HasComment("납품처코드");

                entity.Property(e => e.Eo15Other)
                    .HasMaxLength(300)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Other")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("주문메모");

                entity.Property(e => e.Eo15SalesMan)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO15_SalesMan");

                entity.Property(e => e.Eo15SupplyPrice)
                    .HasColumnName("EO15_Supply_Price")
                    .HasComment("공급가");

                entity.Property(e => e.Eo15TaxPrice)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO15_Tax_Price")
                    .HasComment("세액");

                entity.Property(e => e.Eo15TotPrice)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO15_Tot_Price")
                    .HasComment("합계금액");

                entity.Property(e => e.Eo15ReturnFlag)
                    .HasColumnName("EO15_Return_Flag")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasComment("반려여부");
                entity.Property(e => e.Eo15ReturnMsg)
                    .HasColumnName("EO15_Return_Msg")
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasComment("반려메세지");
                entity.Property(e => e.Eo15ReturnUserCd)
                    .HasColumnName("EO15_Return_User_Cd")
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasComment("반려처리한 사용자코드");
                entity.Property(e => e.Eo15ReturnDate)
                    .HasColumnName("EO15_Return_Date")
                    .HasColumnType("smalldatetime")
                    .HasComment("반려일자");
                entity.Property(e => e.Eo15HouseGb)
                    .IsUnicode(false)
                    .HasColumnName("EO15_House_Gb");
                entity.Property(e => e.Eo15OrdGu)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Ord_Gu");
                entity.Property(e => e.Eo15ConfirmDateToIF)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Confirm_Date_ToIF");
                entity.Property(e => e.Eo15ConfirmUserCd)
                    .IsUnicode(false)
                    .HasColumnName("EO15_Confirm_User_Cd");

            });

            modelBuilder.Entity<Eo160>(entity =>
            {
                entity.HasKey(e => new { e.Eo16ReYyMmDd, e.Eo16RevenCd, e.Eo16ReSeq, e.Eo16ResubSeq });

                entity.ToTable("EO160");

                entity.HasComment("주문상세");

                entity.Property(e => e.Eo16ReYyMmDd)
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Re_YyMmDd")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("주문접수일자");

                entity.Property(e => e.Eo16RevenCd)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Reven_Cd")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("거래처코드");

                entity.Property(e => e.Eo16ReSeq)
                    .HasColumnName("EO16_Re_Seq")
                    .HasComment("주문순번");

                entity.Property(e => e.Eo16ResubSeq)
                    .HasColumnName("EO16_Resub_Seq")
                    .HasComment("주문상세순번");

                entity.Property(e => e.Eo16AddCd)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Add_Cd")
                    .HasDefaultValueSql("('999999')")
                    .IsFixedLength(true)
                    .HasComment("등록자코드");

                entity.Property(e => e.Eo16AddDate)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Add_Date")
                    .HasDefaultValueSql("('20010101')")
                    .IsFixedLength(true)
                    .HasComment("등록일시");

                entity.Property(e => e.Eo16ConfirmFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Confirm_Flag")
                    .HasDefaultValueSql("('N')")
                    .IsFixedLength(true)
                    .HasComment("확정여부");

                entity.Property(e => e.Eo16ConfirmQty)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Confirm_Qty")
                    .HasComment("확정수량");

                entity.Property(e => e.Eo16IfOrdNum)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO16_If_OrdNum")
                    .HasDefaultValueSql("('')")
                    .HasComment("ERP주문번호");

                entity.Property(e => e.Eo16ModCd)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Mod_Cd")
                    .IsFixedLength(true);

                entity.Property(e => e.Eo16ModDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EO16_Mod_Date");

                entity.Property(e => e.Eo16Oquantity)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Oquantity");

                entity.Property(e => e.Eo16Other)
                    .IsRequired()
                    .HasMaxLength(60)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Other")
                    .IsFixedLength(true)
                    .HasComment("주문상세메모");

                entity.Property(e => e.Eo16OutQuantity)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Out_Quantity")
                    .HasComment("출고수량");

                entity.Property(e => e.Eo16PhysicCd)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Physic_Cd")
                    .HasDefaultValueSql("(' ')")
                    .HasComment("제품코드");

                entity.Property(e => e.Eo16Quantity)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Quantity")
                    .HasComment("주문수량");

                entity.Property(e => e.Eo16ReDi)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Re_Di")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("주문상태코드디테일");

                entity.Property(e => e.Eo16ReDiGcode)
                    .IsRequired()
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("EO16_Re_Di_Gcode")
                    .HasDefaultValueSql("('0010')")
                    .IsFixedLength(true)
                    .HasComment("주문상태코드마스터");

                entity.Property(e => e.Eo16SupplyPrice)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Supply_Price")
                    .HasComment("공급가");

                entity.Property(e => e.Eo16TaxPrice)
                    .HasColumnType("decimal(18, 0)")
                    .HasColumnName("EO16_Tax_Price")
                    .HasComment("세액");
                entity.Property(e => e.Eo16PreUnitCost)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("EO16_Pre_Unit_Cost")
                    .HasComment("이전단가");
                entity.Property(e => e.Eo16UnitCost)
                    .HasColumnType("decimal(18, 2)")
                    .HasColumnName("EO16_Unit_Cost")
                    .HasComment("단가");
                entity.Property(e => e.Eo16ConfirmDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EO16_Confirm_Date")
                    .HasComment("승인일자");
                entity.Property(e => e.Eo16CtrPYl)
                    .HasColumnType("decimal(18,2)")
                    .HasColumnName("EO16_Ctr_P_Yl")
                    .HasComment("사전할인");
                entity.Property(e => e.Eo16HpinYl)
                    .HasColumnType("decimal(18,2)")
                    .HasColumnName("EO16_Hpin_Yl")
                    .HasComment("원내할인");
                entity.Property(e => e.Eo16InsuPrice)
                    .HasColumnType("decimal(18, 3)")
                    .HasColumnName("EO16_Insu_Price")
                    .HasComment("보험가");
            });

            modelBuilder.Entity<EoboardNotice>(entity =>
            {
                entity.HasKey(e => e.EobdNum);

                entity.ToTable("EOBoard_Notice");

                entity.HasComment("공지사항");

                entity.Property(e => e.EobdNum)
                    .HasColumnName("EOBd_Num")
                    .HasComment("번호");

                entity.Property(e => e.EobdContent)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("EOBd_Content")
                    .HasDefaultValueSql("('')")
                    .HasComment("내용");

                entity.Property(e => e.EobdDelFlag)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_Del_Flag")
                    .HasDefaultValueSql("('')")
                    .IsFixedLength(true)
                    .HasComment("삭제여부");

                entity.Property(e => e.EobdFileName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_File_Name")
                    .HasDefaultValueSql("('')")
                    .HasComment("첨부파일명");

                entity.Property(e => e.EobdFileName2)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_File_Name2")
                    .HasDefaultValueSql("('')")
                    .HasComment("첨부파일명2");

                entity.Property(e => e.EobdFileSize)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_File_Size")
                    .HasDefaultValueSql("('')")
                    .HasComment("첨부파일크기");

                entity.Property(e => e.EobdFileSize2)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_File_Size2")
                    .HasDefaultValueSql("('')")
                    .HasComment("첨부파일크기2");

                entity.Property(e => e.EobdModCd)
                    .HasColumnName("EOBd_Mod_Cd")
                    .HasComment("수정자코드");

                entity.Property(e => e.EobdModDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EOBd_Mod_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("수정일시");

                entity.Property(e => e.EobdReLevel).HasColumnName("EOBd_Re_Level");

                entity.Property(e => e.EobdReStep)
                    .HasColumnName("EOBd_Re_Step")
                    .HasComment("");

                entity.Property(e => e.EobdReadCnt)
                    .HasColumnName("EOBd_Read_Cnt")
                    .HasComment("조회수");

                entity.Property(e => e.EobdRef).HasColumnName("EOBd_Ref");

                entity.Property(e => e.EobdTitle)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("EOBd_Title")
                    .HasDefaultValueSql("('')")
                    .HasComment("제목");

                entity.Property(e => e.EobdWriteCd)
                    .HasColumnName("EOBd_Write_Cd")
                    .HasComment("작성자코드");

                entity.Property(e => e.EobdWriteDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EOBd_Write_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("작성일시");
            });

            modelBuilder.Entity<EoOrderMemo>(entity =>
            {
                entity.HasKey(e => new { e.EoNum });

                entity.ToTable("EO_OrderMemo");

                entity.HasComment("주문안내메모");

                entity.Property(e => e.EoNum)
                    .HasColumnName("EO_Num")
                    .UseIdentityColumn(1)
                    .HasComment("번호");

                entity.Property(e => e.EoMemo)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("EO_Memo")
                    .HasDefaultValueSql("(' ')")
                    .IsFixedLength(true)
                    .HasComment("메모");

                entity.Property(e => e.EoAddDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("EO_Add_Date")
                    .HasDefaultValueSql("(getdate())")
                    .HasComment("등록일시");
            });

            modelBuilder.Entity<EoOrderTime>(entity =>
            {
                entity.HasKey(e => new { e.Num });

                entity.ToTable("EO_OrderTime");

                entity.HasComment("주문시간관리");

                entity.Property(e => e.Num)
                    .HasColumnName("Num")
                    .UseIdentityColumn(1)
                    .HasComment("번호");

                entity.Property(e => e.CloseTime)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("CloseTime")
                    .IsFixedLength(true)
                    .HasComment("주문마감시간");

                entity.Property(e => e.StopTime)
                    .HasMaxLength(4)
                    .IsUnicode(false)
                    .HasColumnName("StopTime")
                    .IsFixedLength(true)
                    .HasComment("주문중지시간");

                entity.Property(e => e.UpdateTime)
                    .HasColumnType("datetime2")
                    .HasColumnName("UpdateTime")
                    .HasComment("수정시간");
            });
            modelBuilder.Entity<EoPopup>(entity =>
            {
                entity.HasKey(e => new { e.EopopNum });

                entity.ToTable("EO_Popup");
                entity.Property(e => e.EopopNum)
                    .HasColumnName("EOPop_Num");
                entity.Property(e => e.EopopTitle)
                    .HasColumnName("EOPop_Title");
                entity.Property(e => e.EopopContent)
                    .HasColumnName("EOPop_Content");
                entity.Property(e => e.EopopStartDate)
                    .HasColumnName("EOPop_Start_Date");
                entity.Property(e => e.EopopEndDate)
                    .HasColumnName("EOPop_End_Date");
                entity.Property(e => e.EopopReadCnt)
                    .HasColumnName("EOPop_Read_Cnt")
                    .HasDefaultValueSql("((0))");
                entity.Property(e => e.EopopFileName)
                    .HasColumnName("EOPop_File_Name")
                    .HasDefaultValueSql("('')");
                entity.Property(e => e.EopopFileSize)
                    .HasColumnName("EOPop_File_Size")
                    .HasDefaultValueSql("('')");
                entity.Property(e => e.EopopDelFlag)
                    .HasColumnName("EOPop_Del_Flag")
                    .HasDefaultValueSql("('')");
                entity.Property(e => e.EopopCook)
                    .HasColumnName("EOPop_Cook")
                    .HasDefaultValueSql("('')");
                entity.Property(e => e.EopopAddDate)
                    .HasColumnName("EOPop_Add_Date")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");
                entity.Property(e => e.EopopModDate)
                    .HasColumnName("EOPop_Mod_Date")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");
                entity.Property(e => e.EopopVenCd)
                    .HasColumnName("EOPop_Ven_Cd")
                    .HasDefaultValueSql("('')");
                entity.Property(e => e.EopopGubun)
                    .HasColumnName("EOPop_Gubun")
                    .HasDefaultValueSql("('0')");
                entity.Property(e => e.EopopLeft)
                    .HasColumnName("EOPop_Left")
                    .HasDefaultValueSql("((0))");
                entity.Property(e => e.EopopTop)
                    .HasColumnName("EOPop_Top")
                    .HasDefaultValueSql("((0))");
                entity.Property(e => e.EopopWidth)
                    .HasColumnName("EOPop_Width")
                    .HasDefaultValueSql("((0))");
                entity.Property(e => e.EopopHeight)
                    .HasColumnName("EOPop_Height")
                    .HasDefaultValueSql("((0))");

                entity.HasComment("팝업");

            });
            modelBuilder.Entity<EoHoliday>(entity =>
            {
                entity.HasKey(e => new { e.EodayTargetDate });

                entity.ToTable("EO_Holiday");
                entity.Property(e => e.EodayTargetDate)
                    .HasColumnName("EOday_Target_Date");
                entity.Property(e => e.EodayFlag)
                    .HasColumnName("EOday_Flag")
                    .HasDefaultValueSql("''");
                entity.Property(e => e.EodayAddDate)
                    .HasColumnName("EOday_Add_Date")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");
                entity.Property(e => e.EodayModDate)
                    .HasColumnName("EOday_Mod_Date")
                    .HasColumnType("smalldatetime")
                    .HasDefaultValueSql("(getdate())");

                entity.HasComment("공휴일");

            });

            modelBuilder.Entity<EoBag>(entity =>
            {
                entity.HasKey(e => new { e.EobgNum });

                entity.ToTable("EOBag");
                entity.Property(e => e.EobgNum)
                    .HasColumnName("EOBG_Num");
                entity.Property(e => e.EobgType)
                    .HasColumnName("EOBG_Type");
                entity.Property(e => e.EobgVenCd)
                    .HasColumnName("EOBG_Ven_Cd");
                entity.Property(e => e.EobgDropCd)
                    .HasColumnName("EOBG_Drop_Cd");
                entity.Property(e => e.EobgPhysicCd)
                    .HasColumnName("EOBG_Physic_Cd");
                entity.Property(e => e.EobgUserCd)
                    .HasColumnName("EOBG_UserCd");
                entity.Property(e => e.EobgPrice)
                    .HasColumnName("EOBG_Price");
                entity.Property(e => e.EobgQty)
                    .HasColumnName("EOBG_Qty");
                entity.Property(e => e.EobgDelFlag)
                    .HasDefaultValueSql("('N')")
                    .HasColumnName("EOBG_Del_Flag");
                entity.Property(e => e.EobgAddDate)
                    .HasColumnType("datetime")
                    .HasColumnName("EOBG_Add_Date")
                    .HasDefaultValueSql("(getdate())");
                entity.HasComment("장바구니");

            });

            modelBuilder.Entity<Eo033>(entity =>
            {
                entity.HasKey(e => new { e.Eo033VenCd, e.Eo033DropCd });

                entity.ToTable("EO033");
                entity.Property(e => e.Eo033VenCd)
                    .HasColumnName("EO033_Ven_Cd");
                entity.Property(e => e.Eo033DropCd)
                    .HasColumnName("EO033_Drop_Cd");
                entity.Property(e => e.Eo033SalesManCd)
                    .HasColumnName("EO033_Sales_Man_Cd");
                entity.Property(e => e.Eo033AddDate)
                    .HasColumnName("EO033_Add_Date");
                entity.HasComment("매출처별간납처");

            });

            modelBuilder.Entity<Eo043>(entity =>
            {
                entity.HasKey(e => new { e.Eo43VenCd, e.Eo43PhysicCd});

                entity.ToTable("EO043");
                entity.Property(e => e.Eo43VenCd)
                    .HasColumnName("EO43_Ven_Cd");
                entity.Property(e => e.Eo43PhysicCd)
                    .HasColumnName("EO43_Physic_Cd");
                entity.HasComment("관심제품");

            });

            modelBuilder.Entity<EoCollectMoney>(entity =>
            {
                entity.HasKey(e => new { e.YYYYMM, e.VenCd});
                entity.ToTable("EOCollectMoney");

                entity.Property(e => e.YYYYMM)
                    .HasColumnName("YYYYMM");
                entity.Property(e => e.VenCd)
                    .HasColumnName("VenCd");
                entity.Property(e => e.ExpireDate)
                    .HasColumnName("ExpireDate");
                entity.Property(e => e.BankName)
                    .HasColumnName("BankName");
                entity.Property(e => e.BankAccount)
                    .HasColumnName("BankAccount");
                entity.Property(e => e.Price)
                    .HasColumnName("Price");
                entity.Property(e => e.PayFlag)
                    .HasColumnName("PayFlag");
                entity.Property(e => e.AddUserCd)
                    .HasColumnName("AddUserCd");
                entity.Property(e => e.AddDate)
                    .HasColumnType("smalldatetime")
                    .HasColumnName("AddDate")
                    .HasDefaultValueSql("(getdate())");
            });
            modelBuilder.Entity<OrderSearchVenChk>(e => e.HasNoKey());
            modelBuilder.Entity<CM_CUST_AD_VW>(e => e.HasNoKey());
            modelBuilder.Entity<TransCardView>(e => e.HasNoKey());
            modelBuilder.Entity<KSNET_PGARG>(e => e.HasNoKey());
            modelBuilder.Entity<SLORD_BILL_TRANS_R_SFA>(e => e.HasNoKey());
            modelBuilder.Entity<SLORD_TAXBILL_PRINT_SFA>(e => e.HasNoKey());
            modelBuilder.Entity<SL102M01_SFA>(e => e.HasNoKey());
            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
