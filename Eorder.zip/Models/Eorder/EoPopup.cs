﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class EoPopup
    {
        public long EopopNum { get; set; }
        public string EopopTitle { get; set; }
        public string EopopContent { get; set; }
        public string EopopStartDate { get; set; }
        public string EopopEndDate { get; set; }
        public long EopopReadCnt { get; set; }
        public string EopopFileName { get; set; }
        public string EopopFileSize { get; set; }
        public string EopopDelFlag { get; set; }

        public string EopopCook { get; set; }
        public DateTime EopopAddDate { get; set; }
        public DateTime EopopModDate { get; set; }
        public string EopopVenCd { get; set; }
        public string EopopGubun { get; set; }
        public int EopopLeft { get; set; }
        public int EopopTop { get; set; }
        public int EopopWidth { get; set; }
        public int EopopHeight { get; set; }
    }
}
