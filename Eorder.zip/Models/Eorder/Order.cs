﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class Order
    {
        public List<EoBag> eoBags { get; set; }
        public string memo { get; set; }
    }
}
