﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo010
    {
        public string Eo01Gcode { get; set; }
        public string Eo01Tcode { get; set; }
        public string Eo01Hnm { get; set; }
        public string Eo01DelFlag { get; set; }
        public DateTime Eo01AddDate { get; set; }
    }
}
