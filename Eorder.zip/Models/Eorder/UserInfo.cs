﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class UserInfo
    {
        public Eo030 eo030 { get; set; }
        public Eo061 eo061 { get; set; }
    }
}
