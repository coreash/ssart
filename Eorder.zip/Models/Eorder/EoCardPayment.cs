﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    [Table("EOCardPayment")]
    public class EoCardPayment
    {
        [Column("EOCP_OrderNumb"), Key]
        public string EocpOrderNumber { get; set; }
        [Column("EOCP_Ven_Cd")]
        public string EocpVenCd { get; set; }
        [Column("EOCP_OrderName")]
        public string EocpOrderName { get; set; }
        [Column("EOCP_Email")]
        public string EocpEmail { get; set; }
        [Column("k_aid")]
        public string aid { get; set; }
        [Column("k_code")]
        public string code { get; set; }
        [Column("k_tid")]
        public string tid { get; set; }
        [Column("k_tradeDateTime")]
        public string tradeDateTime { get; set; }
        [Column("k_totalAmount")]
        public Int32? totalAmount { get; set; }
        [Column("k_respCode")]
        public string respCode { get; set; }
        [Column("k_respMessage")]
        public string respMessage { get; set; }
        [Column("k_payload")]
        public string payload { get; set; }
        [Column("k_issuerCardType")]
        public string issuerCardType { get; set; }
        [Column("k_issuerCardName")]
        public string issuerCardName { get; set; }
        [Column("k_purchaseCardType")]
        public string purchaseCardType { get; set; }
        [Column("k_purchaseCardName")]
        public string purchaseCardName { get; set; }
        [Column("k_approvalNumb")]
        public string approvalNumb { get; set; }
        [Column("k_cardNumb")]
        public string cardNumb { get; set; }
        [Column("k_expiryDate")]
        public string expiryDate { get; set; }
        [Column("k_installMonth")]
        public Int32? installMonth { get; set; }
        [Column("k_cardType")]
        public string cardType { get; set; }
        [Column("k_partCancelYn")]
        public string partCancelYn{ get; set; }
        [Column("EOCP_Add_Date")]
        public DateTime? EocpAddDate { get; set; }
        [Column("EOCP_Add_Cd")]
        public long EocpAddCd { get; set; }
        [Column("EOCP_Slip_Dt")]
        public DateTime? EocpSlipDt { get; set; }
        [Column("EOCP_Slip_No")]
        public Int32? EocpSlipNo { get; set; }
    }

    /// <summary>
    /// 결제요청포멧
    /// </summary>
    public class ReqCardPay
    {
        /// <summary>
        /// 상점아이디
        /// </summary>
        public string mid { get; set; }
        /// <summary>
        /// 자체 주문번호
        /// </summary>
        public string orderNumb { get; set; }
        /// <summary>
        /// 주문자명
        /// </summary>
        public string userName { get; set; }
        /// <summary>
        /// 이메일
        /// </summary>
        public string userEmail { get; set; }
        /// <summary>
        /// 상품구분
        /// </summary>
        public string productType { get; set; }
        /// <summary>
        /// 상품명(최대50byte)
        /// </summary>
        public string productName { get; set; }
        /// <summary>
        /// 총금액
        /// </summary>
        public Int32 totalAmount { get; set; }
        /// <summary>
        /// 면세금액
        /// </summary>
        public Int32 taxFreeAmount { get; set; }
        /// <summary>
        /// 리턴받을 데이터
        /// </summary>
        public string payload { get; set; }
        /// <summary>
        /// 이자구분
        /// </summary>
        public string interestType { get; set; }
        /// <summary>
        /// 카드번호
        /// </summary>
        public string cardNumb { get; set; }
        /// <summary>
        /// 유효기간
        /// </summary>
        public string expiryDate { get; set; }
        /// <summary>
        /// 할부
        /// </summary>
        public short installMonth { get; set; }
        /// <summary>
        /// 통화타입
        /// </summary>
        public string currencyType { get; set; }
    }
    public class RespCardPay
    {
        public string aid { get; set; }
        public string code { get; set; }
        public string message { get; set; }
        public EoCardPayment data { get; set; }
    }

    /// <summary>
    /// 결제시 대상 월 및 거래처코드
    /// </summary>
    public class PayloadData
    {
        public string targetMonth { get; set; }
        public string venCd { get; set; }
    }

    public class EoCardPaymentForExcel
    {
        public Int32 순번 { get; set; }
        public string 결제상태{ get; set; }
        public string 사업부 { get; set; }
        public string 승인일 { get; set; }
        public string 승인시간 { get; set; }
        public string 승인번호 { get; set; }
        public Int32? 승인금액 { get; set; }
        public string 카드사 { get; set; }
        public string 카드번호 { get; set; }
        public string 유효기한 { get; set; }
        public Int32? 할부개월 { get; set; }
    }

    public class CardPaymentList 
    {
        public EoCardPayment cardPayment { get; set; }
        //입금 여부
        public KSNET_PGARG ksnet { get; set; }
    }
}
