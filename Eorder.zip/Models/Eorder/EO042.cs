﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class Eo042
    {
        #region 약가인하
        /// <summary>
        /// 약가인하 일자
        /// </summary>
        public string Eo042Date { get; set; }
        /// <summary>
        /// 제품코드
        /// </summary>
        public string Eo042PhysicCd { get; set; }
        /// <summary>
        /// 이전단가
        /// </summary>
        public decimal Eo042PreUnitCost { get; set; }
        /// <summary>
        /// 이후단가
        /// </summary>
        public decimal Eo042UnitCost { get; set; }
        /// <summary>
        /// 사용여부
        /// </summary>
        public string Eo042DelFlag { get; set; }
        /// <summary>
        /// 설정일
        /// </summary>
        public DateTime Eo042AddDate { get; set; }
        #endregion
    }
}
