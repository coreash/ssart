﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.CollectMoney
{
    public class EoCollectMoneyPrint
    {
        public EoCollectMoney eoCollectMoney { get; set; }
        public Eo030 eo030 { get; set; }
    }
}
