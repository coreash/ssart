﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.CollectMoney
{
    public class EoCollectMoneyMap
    {
        /// <summary>
        /// 순번
        /// </summary>
        [Key]
        public Int64 NUM { get; set; }

        /// <summary>
        /// 레코드수
        /// </summary>
        public Int64 TotalCount { get; set; }

        /// <summary>
        /// 년월
        /// </summary>
        public string YyyyMm { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string VenNm { get; set; }

        /// <summary>
        /// 만기일
        /// </summary>
        public string ExpireDate { get; set; }

        /// <summary>
        /// 은행명
        /// </summary>
        public string BankName { get; set; }

        /// <summary>
        /// 계좌번호
        /// </summary>
        public string BankAccount { get; set; }

        /// <summary>
        /// 수금금액
        /// </summary>
        public Int64 Price { get; set; }

        /// <summary>
        /// 등록자코드
        /// </summary>
        public string AddUserCd { get; set; }

        /// <summary>
        /// 등록자명
        /// </summary>
        public string AddUserNm { get; set; }

        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime AddDate { get; set; }

        public string AddDateFormat
        {
            get
            {
                return AddDate.ToString("yyyy-MM-dd HH:mm:ss");
            }
        }

    }
}
