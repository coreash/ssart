﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.CollectMoney
{
    public class EoCollectMoneySearch
    {
        /// <summary>
        /// 년월
        /// </summary>
        private string _collectMonth;

        public string CollectMonth
        {
            get { return (_collectMonth ?? "").Replace("-", ""); }
            set { _collectMonth = value; }
        }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 페이지번호
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 페이지크기
        /// </summary>
        public int PageSize { get; set; }
    }
}
