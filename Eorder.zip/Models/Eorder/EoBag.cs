﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class EoBag
    {
        public long EobgNum { get; set; }
        /// <summary>
        /// 장바구니 구분(O: 주문, R: 반품)
        /// </summary>
        public string EobgType { get; set; }
        public string EobgVenCd { get; set; }
        public string EobgDropCd { get; set; }
        public string EobgPhysicCd { get; set; }
        public string EobgUserCd { get; set; }
        public decimal EobgPrice { get; set; }
        public long EobgQty { get; set; }
        public string EobgDelFlag { get; set; }
        public DateTime EobgAddDate { get; set; }

    }

}
