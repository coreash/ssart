﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo061
    {
        public long Eo61Num { get; set; }
        public string Eo61Id { get; set; }
        public string Eo61Pwd { get; set; }
        public string Eo61Pw { get; set; }
        public string Eo61UserName { get; set; }
        public string Eo61CompanyNum { get; set; }
        public string Eo61CompanyName { get; set; }
        public string Eo61OfficeTel { get; set; }
        public string Eo61ZipCode { get; set; }
        public string Eo61Sido { get; set; }
        public string Eo61Gugun { get; set; }
        public string Eo61Dong { get; set; }
        public string Eo61Address { get; set; }
        public string Eo61Email { get; set; }
        public string Eo61MemberKind { get; set; }
        public string Eo61MemberVen { get; set; }
        public bool Eo61DelFlag { get; set; }
        public string Eo61AddNum { get; set; }
        public DateTime Eo61AddDate { get; set; }
        public string Eo61ModNum { get; set; }
        public DateTime Eo61ModDate { get; set; }
        public string Eo61RoadNm { get; set; }
        public string Eo61RoadNmDetail { get; set; }
        public string Eo61StockCd { get; set; }
        public int? Eo61ListCnt { get; set; }
        public string Eo61RoadArea { get; set; }
        public string Eo61Fax { get; set; }
    }
}
