﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class EoOrderMemo
    {
        public long EoNum { get; set; }
        public string EoMemo { get; set; }
        public DateTime EoAddDate{ get; set; }
    }
}
