﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo160
    {
        public string Eo16ReYyMmDd { get; set; }
        public string Eo16RevenCd { get; set; }
        public short Eo16ReSeq { get; set; }
        public short Eo16ResubSeq { get; set; }
        public string Eo16PhysicCd { get; set; }
        public decimal Eo16PreUnitCost { get; set; }
        public decimal Eo16UnitCost { get; set; }
        public decimal Eo16Quantity { get; set; }
        public decimal Eo16Oquantity { get; set; }
        public decimal Eo16SupplyPrice { get; set; }
        public decimal Eo16TaxPrice { get; set; }
        public decimal Eo16OutQuantity { get; set; }
        public string Eo16ReDiGcode { get; set; }
        public string Eo16ReDi { get; set; }
        public string Eo16AddDate { get; set; }
        public string Eo16AddCd { get; set; }
        public string Eo16Other { get; set; }
        public string Eo16ConfirmFlag { get; set; }
        public decimal Eo16ConfirmQty { get; set; }
        public string Eo16IfOrdNum { get; set; }
        public DateTime? Eo16ModDate { get; set; }
        public string Eo16ModCd { get; set; }
        public DateTime? Eo16ConfirmDate { get; set; }
        /// <summary>
        /// 원내할인
        /// </summary>
        public decimal Eo16HpinYl { get; set; }
        /// <summary>
        /// 사전할인
        /// </summary>
        public decimal Eo16CtrPYl { get; set; }
        public decimal Eo16InsuPrice { get; set; }
    }
}
