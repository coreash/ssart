﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class EoHoliday
    {
        public string EodayTargetDate { get; set; }
        public string EodayFlag { get; set; }
        public DateTime EodayAddDate { get; set; }
        public DateTime EodayModDate { get; set; }
    }
}
