﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Sales
{
    /// <summary>
    /// 매출/재고 업로드 : 매출자료 검색조건
    /// </summary>
    public class EoSaleSearch
    {
        /// <summary>
        /// 매출월
        /// </summary>
        private string _saleMonth;

        public string SaleMonth
        {
            get { return (_saleMonth ?? "").Replace("-", ""); }
            set { _saleMonth = value; }
        }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 매출처명
        /// </summary>
        public string SaleVenName { get; set; }
        
        /// <summary>
        /// 페이지번호
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// 페이지크기
        /// </summary>
        public int PageSize { get; set; }
    }
}
