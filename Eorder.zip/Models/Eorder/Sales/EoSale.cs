﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Sales
{
    /// <summary>
    /// 매출/재고 업로드 : 매출자료 검색목록
    /// </summary>
    public class EoSale
    {
        /// <summary>
        /// 기본키
        /// </summary>
        [Key]
        public long Code { get; set; }

        /// <summary>
        /// 매출일
        /// </summary>
        public string SaleDate { get; set; }
        public string SaleDateYymmdd 
        { 
            get
            {
                string result = "";
                DateTime saleDateTime;
                if (!string.IsNullOrWhiteSpace(SaleDate) && DateTime.TryParseExact(SaleDate, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out saleDateTime))
                {
                    result = saleDateTime.ToString("yyyy.MM.dd");
                }
                return result;
            }
        }

        /// <summary>
        /// 매출처명
        /// </summary>
        public string SaleVenName { get; set; }
        
        /// <summary>
        /// 우편번호
        /// </summary>
        public string ZipCode { get; set; }
        
        /// <summary>
        /// 주소
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// 표준코드
        /// </summary>
        public string StandardCode { get; set; }

        /// <summary>
        /// 품목명
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 규격
        /// </summary>
        public string Standard { get; set; }

        /// <summary>
        /// 매출수량
        /// </summary>
        public int SaleQuantity { get; set; }

        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime AddDate { get; set; }

        public string AddDateYymmdd
        {
            get
            {
                return AddDate.ToString("yyyy.MM.dd");
            }
        }

        /// <summary>
        /// 등록자
        /// </summary>
        public long AddUserCd { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string AddVenCd { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string AddVenNm { get; set; }

        /// <summary>
        /// 순번
        /// </summary>
        public long Num { get; set; }

        /// <summary>
        /// 레코드수
        /// </summary>
        public long TotalCount { get; set; }
    }
}
