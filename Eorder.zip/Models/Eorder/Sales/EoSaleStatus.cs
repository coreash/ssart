﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Sales
{
    public class EoSaleStatus
    {
        public string VenCd { get; set; }
        public string VenNm { get; set; }
        public string Status { get; set; }

    }
}
