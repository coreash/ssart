﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Sales
{
    public class EoSaleStatusExcel
    {
        public string 거래처코드 { get; set; }
        public string 거래처명 { get; set; }
        public string 업로드현황 { get; set; }

    }
}
