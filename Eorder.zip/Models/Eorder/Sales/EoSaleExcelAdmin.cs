﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Sales
{
    /// <summary>
    /// 매출/재고 업로드 : 매출자료 엑셀다운로드 칼럼명(관리자용)
    /// </summary>
    public class EoSaleExcelAdmin
    {
        /// <summary>
        /// 순번
        /// </summary>
        public long 순번 { get; set; }

        public string 등록일 { get; set; }

        /// <summary>
        /// 매출일
        /// </summary>
        public string 매출일 { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string 거래처코드 { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string 거래처명 { get; set; }

        /// <summary>
        /// 매출처명
        /// </summary>
        public string 매출처명 { get; set; }
        
        /// <summary>
        /// 주소
        /// </summary>
        public string 주소 { get; set; }

        /// <summary>
        /// 우편번호
        /// </summary>
        public string 우편번호 { get; set; }
        
        /// <summary>
        /// 표준코드
        /// </summary>
        public string 표준코드 { get; set; }

        /// <summary>
        /// 품목명
        /// </summary>
        public string 품목명 { get; set; }

        /// <summary>
        /// 규격
        /// </summary>
        public string 규격 { get; set; }

        /// <summary>
        /// 매출수량
        /// </summary>
        public int 매출수량 { get; set; }

    }
}
