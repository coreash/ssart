﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo041
    {
        public string Eo041VenCd { get; set; }
        public string Eo041DropCd { get; set; }
        public string Eo041PhysicCd { get; set; }
        public string Eo041StartDate { get; set; }
        public string Eo041EndDate { get; set; }
        public decimal Eo041UnitPrice { get; set; }
        public string Eo041DelFlag { get; set; }
        /// <summary>
        /// 사전 할인
        /// </summary>
        public decimal Eo041CtrPYl { get; set; }
        /// <summary>
        /// 원내 할인
        /// </summary>
        public decimal? Eo041HpinYl { get; set; }
        /// <summary>
        /// 담당자코드
        /// </summary>
        public string Eo041SalesManCd { get; set; }
        /// <summary>
        /// 주문가능수량
        /// </summary>
        public int Eo041PossibleQty { get; set; }
    }
}
