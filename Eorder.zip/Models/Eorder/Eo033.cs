﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class Eo033
    {
        public string Eo033VenCd { get; set; }
        public string Eo033DropCd { get; set; }
        public string Eo033SalesManCd { get; set; }
        public DateTime Eo033AddDate { get; set; }
    }
}
