﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo150
    {
        public string Eo15ReYyMmDd { get; set; }
        public string Eo15RevenCd { get; set; }
        public short Eo15ReSeq { get; set; }
        public string Eo15Other { get; set; }
        public double Eo15SupplyPrice { get; set; }
        public decimal Eo15TaxPrice { get; set; }
        public decimal Eo15TotPrice { get; set; }
        public DateTime Eo15AddDate { get; set; }
        public string Eo15AddCd { get; set; }
        public string Eo15SalesMan { get; set; }
        public string Eo15DropCd { get; set; }
        public string Eo15ReturnFlag { get; set; }
        public string Eo15ReturnMsg { get; set; }
        public string Eo15ReturnUserCd { get; set; }
        public DateTime? Eo15ReturnDate { get; set; }
        /// <summary>
        /// 창고구분
        /// </summary>
        public string Eo15HouseGb { get; set; }
        /// <summary>
        /// 주문구분(O: 주문, R: 반품, W: 약가보상
        /// </summary>
        public string Eo15OrdGu { get; set; }
        /// <summary>
        /// 승인시 지정일자(반품, 약가보상)
        /// </summary>
        public string Eo15ConfirmDateToIF { get; set; }
        /// <summary>
        /// 승인 사원 코드
        /// </summary>
        public string Eo15ConfirmUserCd { get; set; }
    }
}
