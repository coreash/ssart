﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Stocks
{
    /// <summary>
    /// 매출/재고 업로드 : 재고자료 검색 목록
    /// </summary>
    public class EoStock
    {
        /// <summary>
        /// 기본키
        /// </summary>
        [Key]
        public long Code { get; set; }

        /// <summary>
        /// 년월
        /// </summary>
        public string StockMonth { get; set; }
        
        /// <summary>
        /// 표준코드
        /// </summary>
        public string StandardCode { get; set; }
        
        /// <summary>
        /// 품목명
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// 규격
        /// </summary>
        public string Standard { get; set; }

        /// <summary>
        /// 재고
        /// </summary>
        public int StockQuantity { get; set; }

        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime AddDate { get; set; }

        /// <summary>
        /// 등록자
        /// </summary>
        public long AddUserCd { get; set; }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string AddVenCd { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string AddVenNm { get; set; }

        /// <summary>
        /// 순번
        /// </summary>
        public long Num { get; set; }
        
        /// <summary>
        /// 레코드수
        /// </summary>
        public long TotalCount { get; set; }
    }
}
