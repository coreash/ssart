﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Stocks
{
    /// <summary>
    /// 매출/재고 업로드 : 재고 엑셀다운로드 칼럼명(관리자용)
    /// </summary>
    public class EoStockExcelAdmin
    {
        /// <summary>
        /// 순번
        /// </summary>
        public long 순번 { get; set; }

        /// <summary>
        /// 년월
        /// </summary>
        public string 년월 { get; set; }
        
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string 거래처코드 { get; set; }

        /// <summary>
        /// 거래처명
        /// </summary>
        public string 거래처명 { get; set; }

        /// <summary>
        /// 표준코드
        /// </summary>
        public string 표준코드 { get; set; }
        
        /// <summary>
        /// 품목명
        /// </summary>
        public string 품목명 { get; set; }

        /// <summary>
        /// 규격
        /// </summary>
        public string 규격 { get; set; }

        /// <summary>
        /// 재고
        /// </summary>
        public int 재고수량 { get; set; }

    }
}
