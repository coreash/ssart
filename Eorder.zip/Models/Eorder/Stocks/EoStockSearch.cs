﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder.Stocks
{
    /// <summary>
    /// 매출/재고 업로드 : 재고자료 검색조건
    /// </summary>
    public class EoStockSearch
    {
        /// <summary>
        /// 재고년월
        /// </summary>
        private string _stockMonth;

        public string StockMonth
        {
            get { return (_stockMonth ?? "").Replace("-", ""); }
            set { _stockMonth = value; }
        }

        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }

        /// <summary>
        /// 페이지번호
        /// </summary>
        public int Page { get; set; }
        
        /// <summary>
        /// 페이지크기
        /// </summary>
        public int PageSize { get; set; }
    }
}
