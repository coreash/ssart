﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class Eo030SelectOptionList
    {
        public string Eo03VenCd { get; set; }
        public string Eo03VenNm { get; set; }
    }
}
