﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class EoOrderTime
    {
        public long Num { get; set; }
        public string CloseTime { get; set; }
        public string StopTime { get; set; }
        public DateTime UpdateTime { get; set; }
    }
}
