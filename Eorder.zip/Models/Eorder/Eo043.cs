﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class Eo043
    {
        public string Eo43VenCd { get; set; }
        public string Eo43PhysicCd { get; set; }
    }
}
