﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class EoboardNotice
    {
        public long EobdNum { get; set; }
        public long EobdRef { get; set; }
        public int EobdReLevel { get; set; }
        public int EobdReStep { get; set; }
        public string EobdWriteCd { get; set; }
        public string EobdTitle { get; set; }
        public string EobdContent { get; set; }
        public long EobdReadCnt { get; set; }
        public string EobdDelFlag { get; set; }
        public string EobdFileName { get; set; }
        public string EobdFileSize { get; set; }
        public string EobdFileName2 { get; set; }
        public string EobdFileSize2 { get; set; }
        public DateTime EobdWriteDate { get; set; }
        public DateTime EobdModDate { get; set; }
        public string EobdModCd { get; set; }
    }
}
