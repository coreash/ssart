﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class EoCollectMoney
    {
        /// <summary>
        /// 수금월
        /// </summary>
        public string YYYYMM { get; set; }
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }
        /// <summary>
        /// 만료일자
        /// </summary>
        public string ExpireDate { get; set; }
        /// <summary>
        /// 은행명
        /// </summary>
        public string BankName { get; set; }
        /// <summary>
        /// 계좌번호
        /// </summary>
        public string BankAccount { get; set; }
        /// <summary>
        /// 금액
        /// </summary>
        public long Price { get; set; }
        public string PayFlag { get; set; }
        /// <summary>
        /// 등록자코드
        /// </summary>
        public string AddUserCd { get; set; }
        /// <summary>
        /// 등록일
        /// </summary>
        public DateTime AddDate { get; set; }
    }
}
