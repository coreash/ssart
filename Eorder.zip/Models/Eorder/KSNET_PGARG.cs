﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    [Table("KSNET_PGARG")]
    public class KSNET_PGARG
    {
        /// <summary>
        /// 데이터구분(DC:신용카드)
        /// </summary>
        public string data_sele { get; set; }
        /// <summary>
        /// 거래번호
        /// </summary>
        public string pg_deal_numb { get; set; }
        /// <summary>
        /// 승인구분
        /// </summary>
        public string auth_code { get; set; }
        /// <summary>
        /// 거래일자
        /// </summary>
        public string deal_start_date { get; set; }
        /// <summary>
        /// 거래시간
        /// </summary>
        public string deal_start_time { get; set; }
        /// <summary>
        /// 카드번호
        /// </summary>
        public string card_numb { get; set; }
        /// <summary>
        /// 발급사코드
        /// </summary>
        public string make_gove_code { get; set; }
        /// <summary>
        /// 매입사코드
        /// </summary>
        public string purc_gove_code { get; set; }
        /// <summary>
        /// 유효기간
        /// </summary>
        public string avail_time { get; set; }
        /// <summary>
        /// 할부개월수
        /// </summary>
        public string allo_mont { get; set; }
        /// <summary>
        /// 금액
        /// </summary>
        public string amount { get; set; }
        /// <summary>
        /// 승인번호
        /// </summary>
        public string appr_numb { get; set; }
        /// <summary>
        /// 주문번호
        /// </summary>
        public string order_numb { get; set; }
        /// <summary>
        /// 주문자명
        /// </summary>
        public string order_pers_name { get; set; }
        /// <summary>
        /// 상품명
        /// </summary>
        public string order_prod_code { get; set; }
        /// <summary>
        /// 매입요청일자
        /// </summary>
        public string purc_requ_date { get; set; }
        /// <summary>
        /// 매입완료일자
        /// </summary>
        public string purc_fini_date { get; set; }
        /// <summary>
        /// 지급예정일
        /// </summary>
        public string pay_prea_date { get; set; }
        /// <summary>
        /// 수수료
        /// </summary>
        public string fee { get; set; }
        /// <summary>
        /// 부가세
        /// </summary>
        public string fee_vat { get; set; }
        /// <summary>
        /// 체크카드구분
        /// </summary>
        public string card_type { get; set; }
        /// <summary>
        /// 실지급일자
        /// </summary>
        public string deal_pay_fini_date { get; set; }
        /// <summary>
        /// 등록일자
        /// </summary>
        public DateTime addDate { get; set; }
        [Column("EO_Slip_Dt")]
        public DateTime? EoSlipDt { get; set; }
        [Column("EO_Slip_No")]
        public Int32? EoSlipNo { get; set; }
    }
}
