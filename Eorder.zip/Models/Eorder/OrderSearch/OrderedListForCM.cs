﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class OrderedListForCM
    {
        #region 주문내역(SL101M01, SL101S01)
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string CustCd { get; set; }
        /// <summary>
        /// 간납처코드
        /// </summary>
        public string ECustCd { get; set; }
        /// <summary>
        /// 제품코드
        /// </summary>
        public string ItemCd { get; set; }
        /// <summary>
        /// 주문수량
        /// </summary>
        public decimal SalQty { get; set; }
        #endregion
    }
}
