﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class OrderSearchMaster
    {
        public long IDX { get; set; }
        public string ReYyMmDd { get; set; }
        public string RevenCd { get; set; }
        public short ReSeq { get; set; }
        public string Other { get; set; }
        public double SupplyPrice { get; set; }
        public decimal TaxPrice { get; set; }
        public decimal TotPrice { get; set; }
        public string AddDate { get; set; }
        public string AddCd { get; set; }
        public string VenNm { get; set; }
        public string DropCd { get; set; }
        public string DropName { get; set; }
        public string ProductName { get; set; }
        public string STATUS { get; set; }
        public string selected { get; set; }
        public string returnFlag { get; set; }
        public string returnMsg { get; set; }
        public int Cnt { get; set; }
        public double SumSupplyPrice { get; set; }
        public decimal SumTaxPrice { get; set; }
        public decimal SumTotPrice { get; set; }
        public string IfOrdNum { get; set; }
        public string MaxReDi { get; set; }
    }
}
