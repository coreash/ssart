﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public partial class OrderSearchDetailExcel
    {
        public long 순번 { get; set; }
        public string 주문접수일자 { get; set; }
        public string 주문일자 { get; set; }
        public string 전표번호 { get; set; }
        public string 사업자번호 { get; set; }
        public string 거래처코드 { get; set; }
        public string 거래처명 { get; set; }
        public string 간납처코드 { get; set; }
        public string 간납처명 { get; set; }
        public string 표준코드 { get; set; }
        public string 품목코드 { get; set; }
        public string 품목명 { get; set; }
        public string 규격 { get; set; }
        public string 단가 { get; set; }
        public decimal 주문수량 { get; set; }
        public decimal 출고수량 { get; set; }
        public decimal 공급가 { get; set; }
        public decimal 세액 { get; set; }
        public decimal 합계금액 { get; set; }
        public string 상태 { get; set; }
        public string 주문메모 { get; set; }
        public string 반품사유 { get; set; }
        public string 고액 { get; set; }
        public string 회전 { get; set; }
        public string 잔고 { get; set; }
        public string 담보 { get; set; }
        public string 승인ID { get; set; }
    }
}
