﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class OrderSearchVenChk
    {
        /// <summary>
        /// 거래처코드
        /// </summary>
        public string VenCd { get; set; }
        /// <summary>
        /// 간납처코드
        /// </summary>
        public string DropCd { get; set; }
        /// <summary>
        /// 신용불량체크
        /// </summary>
        public string CredCk { get; set; }
        /// <summary>
        /// 여신한도체크
        /// </summary>
        public string LmtCk { get; set; }
        /// <summary>
        /// 고액잔고체크
        /// </summary>
        public string RmdCk { get; set; }
        /// <summary>
        /// 회전불량체크
        /// </summary>
        public string TurnCk { get; set; }
        /// <summary>
        /// 요주의처체크
        /// </summary>
        public string DngrCk { get; set; }
        /// <summary>
        /// 할증초과체크
        /// </summary>
        public string SpcCk { get; set; }
        /// <summary>
        /// 품절구분체크
        /// </summary>
        public string AbsCk { get; set; }
        /// <summary>
        /// 상호인확인
        /// </summary>
        public string SignCk { get; set; }
        /// <summary>
        /// 잔고확인
        /// </summary>
        public string JanCk { get; set; }
        /// <summary>
        /// 도매처담보확보율확인
        /// </summary>
        public string ScrtCk { get; set; }
    }
}
