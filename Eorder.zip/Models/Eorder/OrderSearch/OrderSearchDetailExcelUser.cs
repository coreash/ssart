﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Models.Eorder
{
    public class OrderSearchDetailExcelUser
    {
        public long 순번 { get; set; }
        public string 주문접수일자 { get; set; }
        public string 주문일자 { get; set; }
        public string 사업자번호 { get; set; }
        public string 간납처명 { get; set; }
        public string 표준코드 { get; set; }
        public string 품목명 { get; set; }
        public string 규격 { get; set; }
        public string 단가 { get; set; }
        public decimal 주문수량 { get; set; }
        public decimal 출고수량 { get; set; }
        public decimal 공급가 { get; set; }
        public decimal 세액 { get; set; }
        public decimal 합계금액 { get; set; }
        public string 상태 { get; set; }
        public string 주문메모 { get; set; }
        public string 반품사유 { get; set; }
    }
}
