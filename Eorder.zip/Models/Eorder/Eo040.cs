﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo040
    {
        public string Eo04PhysicCd { get; set; }
        public string Eo04PhysicNm { get; set; }
        public string Eo04PhysicEnm { get; set; }
        public string Eo04StandardCd { get; set; }
        public string Eo04Standard { get; set; }
        public decimal Eo04AccUnit { get; set; }
        public decimal Eo04InsuPrice { get; set; }
        public string Eo04UseGu { get; set; }
        public string Eo04DelFlag { get; set; }
        /// <summary>
        /// 처방구분
        /// 1: 처방, 2: 비처방
        /// </summary>
        public string Eo04ChbGb { get; set; }
        /// <summary>
        /// 창고구분
        /// 0003: 오창(*)
        /// 9101:지오영(케미칼)
        /// 9110: 쥴릭(바이오)
        /// </summary>
        public string Eo04HouseGb { get; set; }
    }
}
