﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Eorder.Models.Eorder
{
    public partial class Eo060
    {
        public string Eo06UserCd { get; set; }
        public string Eo06UserId { get; set; }
        public string Eo06UserNm { get; set; }
        public string Eo06Password { get; set; }
        public string Eo06Pw { get; set; }
        public string Eo06PhoneTel { get; set; }
        public string Eo06OfficeTel { get; set; }
        public string Eo06Fax { get; set; }
        public string Eo06Email { get; set; }
        public string Eo06RetireFlag { get; set; }
        public string Eo06PartMove { get; set; }
        public string Eo06AdminFlag { get; set; }
        public string Eo06EnableLogin { get; set; }
        public string Eo06DelFlag { get; set; }
        public DateTime? Eo06ModDate { get; set; }
        public string Eo06ModCd { get; set; }
    }
}
