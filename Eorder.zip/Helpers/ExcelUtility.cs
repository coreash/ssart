﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eorder.Helpers
{
    public class ExcelUtility
    {
        #region + === 엑셀다운로드 ===

        // Extensively modifed from https://techbrij.com/export-excel-xls-xlsx-asp-net-npoi-epplus
        // Credit still holds to the writer of the function
        public IWorkbook WriteExcelWithNPOI<T>(List<T> data, string extension = "xlsx")
        {
            // Get DataTable
            DataTable dt = ConvertListToDataTable(data);
            // Instantiate Wokrbook
            IWorkbook workbook;
            if (extension == "xlsx")
            {
                workbook = new XSSFWorkbook();
            }
            else if (extension == "xls")
            {
                workbook = new HSSFWorkbook();
            }
            else
            {
                throw new Exception("The format '" + extension + "' is not supported.");
            }

            ISheet sheet1 = workbook.CreateSheet("Sheet 1");

            //make a header row
            IRow row1 = sheet1.CreateRow(0);

            // 2021.08.12 - 간납처코드 칼럼 셀 서식 텍스트 설정
            ICellStyle textCellStyle = workbook.CreateCellStyle();
            textCellStyle.DataFormat = workbook.CreateDataFormat().GetFormat("@");

            for (int j = 0; j < dt.Columns.Count; j++)
            {

                ICell cell = row1.CreateCell(j);
                string columnName = dt.Columns[j].ToString();
                cell.SetCellValue(columnName);

                // 2021.08.12 - 간납처코드 칼럼 셀 서식 텍스트 설정
                if (!string.IsNullOrWhiteSpace(columnName) && columnName == "간납처코드")
                {
                    sheet1.SetDefaultColumnStyle(j, textCellStyle);
                }
            }

            //loops through data
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row = sheet1.CreateRow(i + 1);
                for (int j = 0; j < dt.Columns.Count; j++)
                {

                    ICell cell = row.CreateCell(j);
                    string columnName = dt.Columns[j].ToString();
                    cell.SetCellValue(dt.Rows[i][columnName].ToString());
                    cell.CellStyle.WrapText = true; // NOT WORKING

                    // 2021.08.12 - 간납처코드 칼럼 셀 서식 텍스트 설정
                    if (!string.IsNullOrWhiteSpace(columnName) && columnName == "간납처코드")
                    {
                        cell.CellStyle = textCellStyle;
                    }
                }
            }
            // Auto size columns
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < row1.LastCellNum; j++)
                {
                    sheet1.AutoSizeColumn(j);
                }
            }

            return workbook;
        }

        // Credit: Accepted answer at https://social.msdn.microsoft.com/Forums/vstudio/en-US/6ffcb247-77fb-40b4-bcba-08ba377ab9db/converting-a-list-to-datatable?forum=csharpgeneral
        private DataTable ConvertListToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
               TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }

        #endregion

        #region + === 엑셀업로드 (엑셀 -> DataTable) ===

        public DataTable ConvertExcelToDataTable(IFormFile file, string webRootPath, DataTable dt)
        {
            string folderName = "UploadExcel";
            string newPath = Path.Combine(webRootPath, folderName);
            StringBuilder sb = new StringBuilder();

            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }

            if (file.Length > 0)
            {
                string sFileExtension = Path.GetExtension(file.FileName).ToLower();
                ISheet sheet;
                string fullPath = Path.Combine(newPath, file.FileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    file.CopyTo(stream);
                    stream.Position = 0;

                    if (sFileExtension == ".xls")
                    {
                        HSSFWorkbook hssfwb = new HSSFWorkbook(stream); //This will read the Excel 97-2000 formats  
                        sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook  
                    }
                    else
                    {
                        XSSFWorkbook hssfwb = new XSSFWorkbook(stream); //This will read 2007 Excel format  
                        sheet = hssfwb.GetSheetAt(0); //get first sheet from workbook   
                    }

                    IRow headerRow = sheet.GetRow(0); //Get Header Row
                    int cellCount = headerRow.LastCellNum;
                    //sb.Append("<table class='table table-bordered'><tr>");

                    //for (int j = 0; j < cellCount; j++)
                    //{
                    //    NPOI.SS.UserModel.ICell cell = headerRow.GetCell(j);

                    //    if (cell == null || string.IsNullOrWhiteSpace(cell.ToString())) continue;

                    //    sb.Append("<th>" + cell.ToString() + "</th>");
                    //}

                    //sb.Append("</tr>");
                    //sb.AppendLine("<tr>");
                    try
                    {
                        for (int i = (sheet.FirstRowNum + 1); i <= sheet.LastRowNum; i++) //Read Excel File
                        {
                            IRow row = sheet.GetRow(i);
                            if (row == null) continue;

                            if (row.Cells.All(d => d.CellType == CellType.Blank)) continue;

                            DataRow dr = dt.NewRow();
                            for (int j = row.FirstCellNum; j < cellCount; j++)
                            {
                                var currCell = row.GetCell(j);

                                if (currCell != null)
                                {
                                    //sb.Append("<td>" + row.GetCell(j).ToString() + "</td>");
                                    dr[j] = currCell.CellType.Equals(CellType.Numeric) ? currCell.NumericCellValue.ToString().Trim() : currCell.ToString().Trim();
                                }
                            }
                            //sb.AppendLine("</tr>");
                            dt.Rows.Add(dr);
                        }
                    }
                    catch (Exception e)
                    {
                        throw;
                    }
                    //sb.Append("</table>");
                }

                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                }
            }
            return dt;
        }

        #endregion

        #region + === 엑셀 워크북 변환 ===

        public byte[] GetFileContentsWorkbook(IWorkbook workbook)
        {
            // =================================================================
            // Credit for two stream since workbook.write() closes the first one: https://stackoverflow.com/a/36584861/6336270 
            MemoryStream tempStream = null;
            MemoryStream stream = null;
            try
            {
                // 1. Write the workbook to a temporary stream
                tempStream = new MemoryStream();
                workbook.Write(tempStream);
                // 2. Convert the tempStream to byteArray and copy to another stream
                var byteArray = tempStream.ToArray();
                stream = new MemoryStream();
                stream.Write(byteArray, 0, byteArray.Length);
                stream.Seek(0, SeekOrigin.Begin);
                // 3. Return file
                return stream.ToArray();
            }
            finally
            {
                if (tempStream != null) tempStream.Dispose();
                if (stream != null) stream.Dispose();
            }
            // -----------------------------------------------------------------
        }
        #endregion
    }
}
