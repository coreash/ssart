using Eorder.Middlewares;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDistributedMemoryCache();
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(20);
                options.Cookie.HttpOnly = true;
                options.Cookie.IsEssential = true;
            });
#if DEBUG
            
#else
            services.AddWebOptimizer(pipeline => {
                pipeline.MinifyJsFiles("js/*.js");
                pipeline.MinifyCssFiles("css/*.css");
            });
#endif            
            services.AddResponseCompression(options => options.Providers.Add<GzipCompressionProvider>()); ;
            services.AddControllersWithViews();
            services.AddSwaggerGen();

            var conn = Configuration["ConnectionStrings:BaseDatabase"];
            services.AddDbContext<Eorder_CelltrionContext>(options => options.UseSqlServer(conn));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            // �Ʒ��� GlobalErrorHandlingMiddleware �� ��ü
            //else
            //{
            //    app.UseExceptionHandler("/Home/Error");
            //}
#if DEBUG
#else
            app.UseWebOptimizer();
#endif
            app.UseSerilogRequestLogging();

            app.UseStaticFiles();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Eorder API V1");
            });
            app.UseRouting();

            app.UseAuthorization();

            app.UseSession();
            app.UseResponseCompression();

            app.UseMiddleware<GlobalErrorHandlingMiddleware>();                 // �Ϲݿ�û, Ajax ��û �����Ͽ� ����
            app.UseStatusCodePagesWithRedirects("/Home/Error?statusCode={0}");  // ��Ÿ ���� ���信 ���� ���� ����������

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapControllerRoute(
                    name: "MyArea",
                    pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
                );
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}"
                );
            });
            
        }
    }
}
