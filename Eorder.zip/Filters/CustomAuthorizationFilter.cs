﻿using Eorder.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Filters
{
    /// <summary>
    /// 사용자 인증 필터 : 세션을 기준으로 로그인 여부를 확인하는 필터
    /// </summary>
    public class CustomAuthorizationFilter : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            // 로그인 Controller 제외한 다른 요청에 대해서 세션 확인
            if (context.HttpContext.Request.RouteValues["controller"] != null &&
                !context.HttpContext.Request.RouteValues["controller"].ToString().Equals("Login", StringComparison.OrdinalIgnoreCase))
            {
                // 세션값이 없는 경우 비인증으로 판단하여 일반요청이나 Ajax 요청을 구분하여 다르게 처리
                if (string.IsNullOrWhiteSpace(context.HttpContext.GetSessionName("UC")))
                {
                    // Ajax 요청인 경우 statusCode = 401 리턴
                    if (context.HttpContext.Request.IsAjaxRequest())
                    {
                        context.Result = new StatusCodeResult(StatusCodes.Status401Unauthorized);
                    }
                    else    // 일반요청인 경우 로그인 페이지로 이동
                    {
                        context.Result = new RedirectToRouteResult(
                            new RouteValueDictionary(new
                            {
                                action = "index",
                                controller = "login",
                                area = "main"
                            })
                        );
                    }
                }
            }
        }
    }
}
