﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder
{
    public static class ObjectExtension
    {
        public static byte[] GetUtf8Bytes(this string src)
        {
            return Encoding.UTF8.GetBytes($"{src}");
        }
        public static byte[] GetUnicodeBytes(this string src)
        {
            return Encoding.Unicode.GetBytes($"{src}");
        }

        public static string GetStringFromUtf8Bytes(this byte[] src)
        {
            return Encoding.UTF8.GetString(src);
        }

    }
}
