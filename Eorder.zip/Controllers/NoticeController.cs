﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class NoticeController : ControllerCommon
    {
        public IActionResult Index()
        {
            return View("List");
        }

        public IActionResult V()
        {
            if (SESSION_USERKIND.Equals("A"))
            {
                return View("Write");
            }
            else
            {
                return View("View");
            }
        }

    }
}
