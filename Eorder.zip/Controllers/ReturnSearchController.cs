﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class ReturnSearchController : ControllerCommon
    {
        public IActionResult Index()
        {
            return View("List");
        }

        public IActionResult V()
        {
            return View("View");
        }

        public IActionResult Print()
        {
            return View();
        }
    }
}
