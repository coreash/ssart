﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Eorder.Helpers;
using Eorder.Models.Eorder;
using Eorder.Models.Celltrion.TransCards;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;

namespace Eorder.Controllers
{
    public class TransCardController : ControllerCommon
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public TransCardController(Eorder_CelltrionContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        /// <summary>
        /// 거래원장 목록
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            if (IsAdmin || IsSales)
            {
                ViewBag.IsAdmin = "true";
                ViewBag.NoRowsColSpan = "13";
                ViewBag.SaleVenClass = "";
                ViewBag.SearchVenSelectClass = "nm w168";
            }
            else
            {
                ViewBag.IsAdmin = "false";
                ViewBag.NoRowsColSpan = "12";
                ViewBag.SaleVenClass = "mgl0";
                ViewBag.SearchVenSelectClass = "nm w230";
            }

            return View();
        }

        /// <summary>
        /// 거래원장 엑셀파일 다운로드
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IActionResult DownloadExcel([FromQuery] TransCardSearch param)
        {
            string srchFlag = "";
            if (SESSION_USERKIND.Equals("U") && string.IsNullOrWhiteSpace(param.VenCd))
            {
                param.VenCd = SESSION_VENCD;
                srchFlag = "VN";
            }

            param.VenCd = param.VenCd?.Trim() ?? "";
            param.Page = 1;
            param.PageSize = 99999999;
            param.DropCd = param.DropCd ?? "";
            List<TransCardView> items = null;

            if (param.IsValid)
            {
                var startDate = new SqlParameter("@StartDate", param.StartDate);
                var endDate = new SqlParameter("@EndDate", param.EndDate);
                var venCd = new SqlParameter("@VenCd", param.VenCd);
                var dropCd = new SqlParameter("@DropCd", param.DropCd);
                var flag = new SqlParameter("@Flag", srchFlag);
                //var pageNo = new SqlParameter("@PageNo", param.Page);
                //var pageSize = new SqlParameter("@PageSize", param.PageSize);

                //string sql = @"
                //    EXEC UP_TRANS_CARD_LIST_SELECT
                //          @StartDate
                //        , @EndDate
                //        , @VenCd
                //        , @PageNo
                //        , @PageSize 
                //    ";
                //items = _context.TransCardViews
                //    .FromSqlRaw(sql, startDate, endDate, venCd, pageNo, pageSize)
                //    .ToList();

                string sql = @"
                    EXEC UP_TRANS_CARD_LIST_SELECT
                          @StartDate
                        , @EndDate
                        , @VenCd
                        , @DropCd
                        , @Flag
                    ";
                items = _context.TransCardViews
                    .FromSqlRaw(sql, startDate, endDate, venCd, dropCd, flag)
                    .ToList();
            }
            else
            {
                items = new List<TransCardView>();
            }

            string extension = "xlsx";
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;

            // 관리자, 회원 - 거래처코드, 거래처명 칼럼 포함여부 예외처리, 칼럼명 한글처리
            List<TransCardViewExcelAdmin> excelAdminItems = new List<TransCardViewExcelAdmin>();
            List<TransCardViewExcel> excelItems = new List<TransCardViewExcel>();
            if (IsAdmin || IsSales)
            {
                foreach (var item in items)
                {
                    excelAdminItems.Add(new TransCardViewExcelAdmin
                    {
                        일자 = item.SAL_DATE,
                        전표번호 = item.ORD_NO,
                        구분 = item.GB,
                        거래처명 = item.CUST_NM,
                        간납처명 = item.ECUST_NM,
                        품목명 = item.ITEM_NM,
                        규격 = item.contentUnit ?? "",
                        수량 = item.SAL_QTY ?? 0,
                        단가 = item.SAL_PRC ?? 0,
                        매출액 = item.SAL_NET ?? 0,
                        수금액 = item.COL_AMT ?? 0,
                        잔고 = item.RMD_AMT ?? 0
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelAdminItems, extension);
            }
            else
            {
                foreach (var item in items)
                {
                    excelItems.Add(new TransCardViewExcel
                    {
                        일자 = item.SAL_DATE,
                        전표번호 = item.ORD_NO,
                        구분 = item.GB,
                        간납처명 = item.ECUST_NM,
                        품목명 = item.ITEM_NM,
                        매출액 = item.SAL_NET ?? 0,
                        규격 = item.contentUnit ?? "",
                        수량 = item.SAL_QTY ?? 0,
                        단가 = item.SAL_PRC ?? 0,
                        수금액 = item.COL_AMT ?? 0,
                        잔고 = item.RMD_AMT ?? 0
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelItems, extension);
            }

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "재고자료_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 거래원장 : 수금액 업로드 ??? => 수정 : 프로시저 수정 필요
        /// </summary>
        /// <returns></returns>
        public IActionResult UploadExcelReceive()
        {
            IFormFile file = Request.Form.Files[0];
            string excelDate = Request.Form["excelDate"].ToString().Replace("-", "");
            string userCd = SESSION_USERCD;
            string venCd = SESSION_VENCD;
            if (IsAdmin || IsSales)
            {
                venCd = "";     // ??? - 관리자인 경우 거래처코드, 거래처명 정보 처리 방법 정의 필요함
            }

            string webRootPath = _environment.WebRootPath;
            ExcelUtility excel = new ExcelUtility();
            DataTable dt = GetExcelReceiveDataTable();
            dt = excel.ConvertExcelToDataTable(file, webRootPath, dt);

            ProcedureResult item = null;
            _context.LoadStoredProc("dbo.UP_EOSALES_INSERT")
                .AddParam("@SaleMonth", excelDate)
                .AddParam("@VenCd", venCd)
                .AddParam("@UserCd", userCd)
                .AddParam(new SqlParameter { ParameterName = "@UDTT_EOSales", SqlDbType = SqlDbType.Structured, TypeName = "dbo.UDTT_EOSales", Value = dt })
                .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

            return Ok(item);
        }

        /// <summary>
        /// 거래원장 : 인쇄
        /// </summary>
        /// <returns></returns>
        public IActionResult Print([FromQuery] TransCardSearch param)
        {
            string srchFlag = "";
            if (SESSION_USERKIND.Equals("U") && string.IsNullOrWhiteSpace(param.VenCd))
            {
                param.VenCd = SESSION_VENCD;
                srchFlag = "VN";
            }

            param.VenCd = param.VenCd?.Trim() ?? "";
            param.Page = 1;
            param.PageSize = 99999999;
            param.DropCd = param.DropCd ?? "";

            PrintVM model = new PrintVM();
            List<TransCardView> items = null;

            if (!param.IsValid)
            {
                return View(model);
            }

            // 프로시저로 변경
            //string sql = SqlOpenRowSetQueryString.GetQueryStringTransCards(param);
            //List<TransCardView> items = _context.TransCardViews.FromSqlRaw(sql).ToList();

            //// 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            ////            //모호한 데이터 타입의 경우 정확하게 맞추지 않으면 Return이 되긴되는데
            ////            //특정 컬럼값이 null 값으로 들어온다던가 하는 현상
            //List<TransCardView> items = null;
            //_context.LoadStoredProc("dbo.UP_TRANS_CARD_LIST_SELECT")
            //    .AddParam("@StartDate", param.StartDate)
            //    .AddParam("@EndDate", param.EndDate)
            //    .AddParam("@VenCd", param.VenCd)
            //    .AddParam("@PageNo", param.Page)
            //    .AddParam("@PageSize", param.PageSize)
            //    .Exec(r => items = r.ToList<TransCardView>());

            var startDate = new SqlParameter("@StartDate", param.StartDate);
            var endDate = new SqlParameter("@EndDate", param.EndDate);
            var venCd = new SqlParameter("@VenCd", param.VenCd);
            var dropCd = new SqlParameter("@DropCd", param.DropCd);
            var flag = new SqlParameter("@Flag", srchFlag);
            //var pageNo = new SqlParameter("@PageNo", param.Page);
            //var pageSize = new SqlParameter("@PageSize", param.PageSize);

            //string sql = @"
            //        EXEC UP_TRANS_CARD_LIST_SELECT
            //              @StartDate
            //            , @EndDate
            //            , @VenCd
            //            , @PageNo
            //            , @PageSize 
            //        ";
            //items = _context.TransCardViews
            //    .FromSqlRaw(sql, startDate, endDate, venCd, pageNo, pageSize)
            //    .ToList();

            string sql = @"
                    EXEC UP_TRANS_CARD_LIST_SELECT
                          @StartDate
                        , @EndDate
                        , @VenCd
                        , @DropCd
                        , @Flag
                    ";
            items = _context.TransCardViews
                .FromSqlRaw(sql, startDate, endDate, venCd, dropCd, flag)
                .ToList();

            model.TransCardViews = items;

            return View(model);
        }

        /// <summary>
        /// 거래원장 : 잔고확인서
        /// </summary>
        /// <returns></returns>
        public IActionResult PrintBalance(string dt)
        {
            var paramVenCd = new SqlParameter("@VenCd", SESSION_VENCD);
            var paramBaseDate = new SqlParameter("@BaseDate", dt);

            // 거래처 기본정보
            //List<BalanceCust> balanceCusts = null;
            List<BalanceCust> balanceCust = new List<BalanceCust>();
            string sql = @" EXEC UP_TRANS_CARD_SELECT_BALANCE_TEST @VenCd, @BaseDate ";
            balanceCust = _context.BalanceCusts
                .FromSqlRaw(sql, paramVenCd, paramBaseDate)
                .ToList();

            var model = new BalancePrintList();
            var list = new List<BalancePrintVM>();

            foreach(var item in balanceCust)
            {
                var obj = new BalancePrintVM();

                obj.CustCode = item.CUST_CD;
                obj.CustName = item.CUST_NM;
                obj.BaseDate = dt.Replace("-", "");
                obj.ConfirmDate = System.DateTime.Now.ToString("yyyyMMdd");
                obj.VenNum = item.BUSIN_NO;
                obj.Address = item.ADDRESS;
                obj.Owner = item.CEO_NM;

                List<BalancePrintItem> balancePrintItems = new List<BalancePrintItem>();

                balancePrintItems.Add(new BalancePrintItem()
                {
                    Kind = "외상매입금",
                    SheetBalanceAmount = null,
                    CustBalanceAmount = item?.TOT_AMT_J ?? 0,
                    DifferenceAmount = null,
                    Remark = ""
                });

                balancePrintItems.Add(new BalancePrintItem()
                {
                    Kind = "미도래어음",
                    SheetBalanceAmount = null,
                    CustBalanceAmount = item?.BIL_AMT_SUM ?? 0,
                    DifferenceAmount = null,
                    Remark = ""
                });

                obj.BalancePrintItems = balancePrintItems;

                var paramCustCd = new SqlParameter("@VenCd", item.CUST_CD);

                // 물적담보
                List<BalanceLienItem> lienItems = null;
                sql = @" EXEC UP_TRANS_CARD_BALANCE_LIEN_SELECT @VenCd ";
                lienItems = _context.BalanceLienItems
                    .FromSqlRaw(sql, paramCustCd)
                    .ToList();

                if (lienItems == null)
                {
                    lienItems = new List<BalanceLienItem>();
                }

                obj.LienItems = lienItems;
                list.Add(obj);
            }
            model.balanceList = list;

            return View(model);
        }

        /// <summary>
        /// 거래원장 : 수금요청서
        /// </summary>
        /// <returns></returns>
        public IActionResult PrintReceive()
        {
            return View();
        }


        #region + === Private Method ===
        private DataTable GetExcelReceiveDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("standardCode", typeof(string));
            dt.Columns.Add("productName", typeof(string));
            dt.Columns.Add("standard", typeof(string));
            dt.Columns.Add("stockQuantity", typeof(int));

            return dt;
        }
        #endregion
    }
}
