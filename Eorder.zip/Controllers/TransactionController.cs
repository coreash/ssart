﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class TransactionController : Controller
    {
        public IActionResult Index()
        {
            return View("List");
        }

        public IActionResult Print()
        {
            return View("TransDocPrint");
        }

        // 약가보상신청 - 관리자
        public IActionResult PharmPrice()
        {
            return View();
        }

        // 약가보상신청 - 사용자
        public IActionResult PharmPriceUser()
        {
            return View();
        }
    }
}
