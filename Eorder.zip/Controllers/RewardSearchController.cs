﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Eorder.Controllers
{
    public class RewardSearchController : ControllerCommon
    {
        public IActionResult Index()
        {
            return View("List");
        }

        public IActionResult V()
        {
            if (IsAdmin || IsSales)
            {
                return View("ViewConfirm");
            }
            else
            {
                return View("View");
            }
        }
        public IActionResult Print()
        {
            return View();
        }
    }
}
