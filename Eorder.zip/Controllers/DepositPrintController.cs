﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class DepositPrintController : Controller
    {
        public IActionResult Index()
        {
            return View("DepositList");
        }

        public IActionResult Print()
        {
            return View("DepositPrint");
        }
    }
}
