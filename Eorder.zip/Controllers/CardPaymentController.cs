﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class CardPaymentController : Controller
    {
        public IActionResult Index()
        {
            return View("CardPayment");
        }
        public IActionResult Print()
        {
            return View("CardPrint");
        }
    }
}
