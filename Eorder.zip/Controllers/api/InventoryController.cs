﻿using Eorder.Models;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class InventoryController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public InventoryController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 재고 가져오기
        /// </summary>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public ActionResult<Paging> GetInventory(string type, string word)
        {
            IEnumerable<TRANS_STOCK_VW> items = null;
            string venCd = SESSION_USERKIND.Equals("U") ? SESSION_VENCD : "";

            try
            {
                _context.LoadStoredProc("dbo.UP_SELECT_TRANS_STOCK_VW")
                    .Exec(r => items = r.ToList<TRANS_STOCK_VW>());

                if (!string.IsNullOrEmpty(venCd))
                {
                    var ven = (from eo030 in _context.Eo030s
                              where eo030.Eo03VenCd.Equals(venCd)
                              where eo030.Eo03DelFlag.Equals("N")
                              select eo030).FirstOrDefault();
                    items = from ii in items
                            join eo041 in _context.Eo041s on ii.ItemCd equals eo041.Eo041PhysicCd
                            join eo030 in _context.Eo030s on eo041.Eo041VenCd equals eo030.Eo03VenCd
                            where eo041.Eo041DelFlag.Equals("N")
                            where eo030.Eo03DelFlag.Equals("N")
                            where eo030.Eo03VenNum.Equals(ven.Eo03VenNum)
                            select ii;
                }
                items = items.Distinct();

                if (!string.IsNullOrEmpty(word))
                {
                    if (type.Equals("nm")) items = items.Where(x => x.ItemNm.Contains(word));
                    if (type.Equals("stdCd")) items = items.Where(x => x.StandardCd != null && x.StandardCd.Trim().Equals(word));
                    if (type.Equals("cd")) items = items.Where(x => x.ItemCd.Trim().Equals(word));
                }
                var count = items.Count();

                return new Paging
                {
                    Count = count,
                    List = items
                        .OrderBy(x => x.ItemNm).ToList()
                };
            }
            catch
            {
                throw;
            }
        }
    }
}
