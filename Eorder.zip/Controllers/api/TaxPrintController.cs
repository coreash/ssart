﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class TaxPrintController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        public TaxPrintController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 세금계산서 목록
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("TaxList")]
        public ActionResult<List<SLORD_BILL_TRANS_R_SFA>> GetTaxList(string startDate, string endDate, string venCd)
        {
            var items = new List<SLORD_BILL_TRANS_R_SFA>();

            if (SESSION_USERKIND.Equals("U")) venCd = SESSION_VENCD;

            _context.LoadStoredProc("dbo.[UP_SELECT_TAXPRINT_LIST]")
                .AddParam("@START_DATE", startDate.Replace("-",""))
                .AddParam("@END_DATE", endDate.Replace("-", ""))
                .AddParam("@VEN_CD", venCd ?? "")
                .Exec(r => items = r.ToList<SLORD_BILL_TRANS_R_SFA>());
            return items;
        }

        /// <summary>
        /// 세금계산서 상세
        /// </summary>
        /// <param name="yyyy"></param>
        /// <param name="mm"></param>
        /// <param name="taxSeq"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("TaxPrint")]
        public ActionResult<SLORD_TAXBILL_PRINT_SFA> GetTaxPrint(string yyyy, string mm, Int32 taxSeq)
        {
            var items = new SLORD_TAXBILL_PRINT_SFA();

            _context.LoadStoredProc("dbo.[UP_SELECT_TAXPRINT_DETAIL]")
                .AddParam("@YYYY", yyyy)
                .AddParam("@MM", mm)
                .AddParam("@TAX_SEQ", taxSeq)
                .Exec(r => items = r.FirstOrDefault<SLORD_TAXBILL_PRINT_SFA>());
            return items;
        }
    }
}
