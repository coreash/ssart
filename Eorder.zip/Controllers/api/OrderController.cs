﻿using Eorder.Models;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public OrderController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 제품검색
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <param name="type"></param>
        /// <param name="phyNm"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        [HttpGet]
        public ActionResult<Paging> GetOrder(string venCd, string dropCd, string type, string phyNm, string bagType)
        {
            if(!IsAdmin && !IsSales)
            {
                venCd = SESSION_VENCD;
            }
            if(string.IsNullOrEmpty(dropCd))
            {
                return new Paging
                {
                    Count = 0,
                    List = null
                };
            }
            string today = DateTime.Now.ToString("yyyyMMdd");
            IEnumerable<TRANS_STOCK_VW> stocks = GetStocks();
            var ven = (from eo030 in _context.Eo030s
                       where eo030.Eo03VenCd.Equals(venCd)
                       select eo030).FirstOrDefault();
            var eorder = (from eo041 in _context.Eo041s
                         join eo030 in _context.Eo030s on eo041.Eo041VenCd equals eo030.Eo03VenCd
                         join eo031 in _context.Eo031s on eo041.Eo041DropCd equals eo031.Eo31DropCd
                         join eo040 in _context.Eo040s on eo041.Eo041PhysicCd equals eo040.Eo04PhysicCd
                         join eo043 in (
                            from eo043 in _context.Eo043s
                            where eo043.Eo43VenCd.Equals(venCd)
                            select eo043
                            ) on eo040.Eo04PhysicCd equals eo043.Eo43PhysicCd into vv
                         from tmp in vv.DefaultIfEmpty()
                         join eo042 in (
                            from eo042 in _context.Eo042s
                            where eo042.Eo042DelFlag.Equals("N")
                            select eo042
                         ) on eo040.Eo04PhysicCd equals eo042.Eo042PhysicCd into ww
                         from tmp2 in ww.DefaultIfEmpty()
                          where eo030.Eo03DelFlag.Equals("N")
                         where eo030.Eo03VenNum.Equals(ven.Eo03VenNum) 
                         where eo040.Eo04DelFlag.Equals("N")
                         where eo040.Eo04UseGu != "N"
                         where eo031.Eo31DelFlag.Equals("N")
                          where eo041.Eo041DelFlag.Equals("N")
                          where eo041.Eo041DropCd.Equals(dropCd)
                         where eo041.Eo041StartDate.CompareTo(today) <= 0
                         where eo041.Eo041EndDate.CompareTo(today) >= 0
                         select new { eo040, eo041, eo043 = tmp, eo042 = tmp2 }).ToList();

            var items = from dt in eorder
                        join st in stocks on dt.eo040.Eo04PhysicCd.Trim() equals st.ItemCd.Trim() into vv
                        from tmp in vv.DefaultIfEmpty()
                        select new { eo040 = dt.eo040, eo041 = dt.eo041, eo043 = dt.eo043, eo042 = dt.eo042, stock = tmp };

            if (bagType.Equals("W"))
            {
                /// 약가보상인 경우
                items = items.Where(x => x.eo042 != null);
            }
            if (!string.IsNullOrEmpty(phyNm)) items = items.Where(x => x.eo040.Eo04PhysicNm.Contains(phyNm));
            if (!string.IsNullOrEmpty(type))
            {
                if (type.Equals("interest")) items = items.Where(x => x.eo043 != null);
                if (type.Equals("reorder"))
                {
                    var baseDate = DateTime.Now.AddMonths(-3).ToString("yyyyMMdd");

                    var ordered = from eo160 in _context.Eo160s
                                  where eo160.Eo16RevenCd.Equals(venCd)
                                  where eo160.Eo16ReYyMmDd.CompareTo(baseDate) >= 0
                                  group eo160 by eo160.Eo16PhysicCd into g
                                  select new { physicCd = g.Key };

                    items = from tmp in items
                            join o in ordered on tmp.eo040.Eo04PhysicCd.Trim() equals o.physicCd.Trim()
                            select tmp;
                }
            }

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderBy(x => x.eo040.Eo04PhysicNm).ToList()
            };
        }

        /// <summary>
        /// 반품 제품 검색(미사용, 08.13 제품 검색과 동일한 기준으로 조회되면 된다고 함. 이유송 과장)
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <param name="type"></param>
        /// <param name="phyNm"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Return")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<Paging> GetRetOrder(string venCd, string dropCd, string type, string phyNm, int page, int pageSize)
        {
            if (!IsAdmin && !IsSales)
            {
                venCd = SESSION_VENCD;
            }
            if (string.IsNullOrEmpty(dropCd))
            {
                return new Paging
                {
                    Count = 0,
                    List = null
                };
            }

            List<ReturnProduct> ifList = null;
            try
            {
                var query = _context.LoadStoredProc("dbo.UP_SELECT_RETURN_LIST")
                    .AddParam("@CUST_CD", venCd)
                    .AddParam("@DROP_CD", dropCd);

                query.Exec(r => ifList = r.ToList<ReturnProduct>());
            }
            catch
            {
                throw;
            }
            List<Eo040> eo040 = (from p in _context.Eo040s select p).ToList();

            var items = from i in ifList
                        join p in eo040 on i.ItemCd equals p.Eo04PhysicCd
                        select new { eo040 = p, history = i};
            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderBy(x => x.eo040.Eo04PhysicNm).ToList()
                    .Skip(pageSize * (page - 1))
                    .Take(pageSize).ToList()
            };
        }

        /// <summary>
        /// 주문메모
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("OrderMemo")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<EoOrderMemo> OrderMemo()
        {
            EoOrderMemo eoOrderMemo = _context.EoOrderMemos.OrderByDescending(x=>x.EoAddDate).First();
            return eoOrderMemo;
        }

        /// <summary>
        /// 주문메모 수정
        /// </summary>
        /// <param name="eoOrderMemo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("OrderMemo")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<EoOrderMemo> PostOrderMemo(EoOrderMemo eoOrderMemo)
        {
            eoOrderMemo.EoAddDate = DateTime.Now;

            _context.EoOrderMemos.Add(eoOrderMemo);
            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateException)
            {
                throw;
            }

            return eoOrderMemo;
        }

        /// <summary>
        /// 주문시간
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("OrderTime")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<EoOrderTime> OrderTime()
        {
            EoOrderTime eoOrderTime = _context.EoOrderTimes.OrderByDescending(x=>x.UpdateTime).First();
            return eoOrderTime;
        }

        /// <summary>
        /// 주문시간 수정
        /// </summary>
        /// <param name="eoOrderTime"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("OrderTime")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<EoOrderTime> PostOrderTime(EoOrderTime eoOrderTime)
        {
            eoOrderTime.UpdateTime = DateTime.Now;

            _context.EoOrderTimes.Add(eoOrderTime);
            _context.SaveChanges();

            return eoOrderTime;
        }

        /// <summary>
        /// 관심제품 등록
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Route("Interest")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public Eo043 PostEo043(Eo043 eo043)
        {
            if (!IsAdmin && !IsSales) eo043.Eo43VenCd = SESSION_VENCD;

            _context.Eo043s.Add(eo043);
            _context.SaveChanges();

            return eo043;
        }

        /// <summary>
        /// 관심제품 삭제
        /// </summary>
        /// <param name="eo043"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("Interest")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]        
        public ActionResult DeleteEo043(Eo043 eo043)
        {
            if (!IsAdmin && !IsSales) eo043.Eo43VenCd = SESSION_VENCD;

            _context.Eo043s.Remove(eo043);
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 주문등록
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("OrderInsert")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<IEnumerable<Eo040>> OrderInsert(Order order)
        {
            
            Eo150 newEo150 = null;
            string today = DateTime.Now.ToString("yyyyMMdd");

            IEnumerable<TRANS_STOCK_VW> stocks = GetStocks();

            #region 재고체크
            var invalidStockList = from ord in order.eoBags
                                   join st in stocks on ord.EobgPhysicCd equals st.ItemCd
                                   where st.StorQty <= 0
                                   select ord ;
            if(invalidStockList.Count() > 0)
            {
                var eo040 = _context.Eo040s.ToList();
                var list = from r in invalidStockList.ToList()
                           join phy in eo040 on r.EobgPhysicCd equals phy.Eo04PhysicCd
                           where phy.Eo04DelFlag.Equals("N")
                           select phy;
                return list.ToList();
            }
            #endregion

            #region 담당자 목록(groupby 거래처/간납처/담당자/창고구분)
            var salesList = (from o in order.eoBags
                        join eo030 in _context.Eo030s on o.EobgDropCd equals eo030.Eo03VenCd
                        join eo040 in _context.Eo040s on o.EobgPhysicCd equals eo040.Eo04PhysicCd
                        join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals 
                                                                                 new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                        where eo041.Eo041DelFlag.Equals("N")
                        where eo030.Eo03DelFlag.Equals("N")
                        where eo041.Eo041StartDate.CompareTo(today) <= 0
                        where eo041.Eo041EndDate.CompareTo(today) >= 0
                        group eo041 by new { eo041.Eo041VenCd, eo041.Eo041DropCd, eo030.Eo03SalesMan, eo040.Eo04HouseGb } into vv
                        select vv.Key ) .ToList();
            #endregion
            #region 단가 목록
            List<Eo041> priceList = (from o in order.eoBags
                             join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals
                                                                                      new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                             where eo041.Eo041StartDate.CompareTo(today) <= 0
                             where eo041.Eo041EndDate.CompareTo(today) >= 0
                             select eo041).ToList();
            #endregion

            #region 주문등록
            /// 거래처/간납처/담당자별로 마스터 등록
            /// 단가 재적용
            
            foreach (var salesMan in salesList)
            {
                _context.LoadStoredProc("dbo.UP_ORDER_INSERT_MASTER")
                   .AddParam("@VENCD", salesMan.Eo041VenCd)
                   .AddParam("@OTHER", order.memo)
                   .AddParam("@SUPPLYPRICE", 0)
                   .AddParam("@TAXPRICE", 0)
                   .AddParam("@TOTALPRICE", 0)
                   .AddParam("@USERCD", SESSION_USERCD)
                   .AddParam("@DROPCD", salesMan.Eo041DropCd)
                   .AddParam("@SALESMAN", salesMan.Eo03SalesMan)
                   .AddParam("@HOUSEGB", salesMan.Eo04HouseGb)
                   .AddParam("@ORD_GU", "O")
                   .Exec(r => newEo150 = r.FirstOrDefault<Eo150>());

                decimal sumSupplyPrice = 0;
                decimal sumTaxPrice = 0;

                var bags = (from b in order.eoBags
                            join eo040 in _context.Eo040s on b.EobgPhysicCd equals eo040.Eo04PhysicCd
                            join eo030 in _context.Eo030s on b.EobgDropCd equals eo030.Eo03VenCd
                            join p in priceList on new { vc = b.EobgVenCd.Trim(), dc = b.EobgDropCd.Trim(), pc = b.EobgPhysicCd.Trim() } equals
                                                              new { vc = p.Eo041VenCd.Trim(), dc = p.Eo041DropCd.Trim(), pc = p.Eo041PhysicCd.Trim() }
                            where b.EobgVenCd.Equals(salesMan.Eo041VenCd)
                            where b.EobgDropCd.Equals(salesMan.Eo041DropCd)
                            where eo040.Eo04HouseGb.Equals(salesMan.Eo04HouseGb)
                            where eo030.Eo03SalesMan.Equals(salesMan.Eo03SalesMan)
                            select new { eobag = b, eo041 = p, insuPrice = eo040.Eo04InsuPrice }).ToList();
                short idx = 1;
                foreach(var item in bags)
                {
                    Eo160 eo160 = new Eo160 { };

                    eo160.Eo16RevenCd = item.eobag.EobgVenCd;
                    eo160.Eo16ReYyMmDd = newEo150.Eo15ReYyMmDd;
                    eo160.Eo16ReSeq = newEo150.Eo15ReSeq;
                    eo160.Eo16ResubSeq = idx++;
                    eo160.Eo16PhysicCd = item.eobag.EobgPhysicCd;
                    eo160.Eo16UnitCost = GetOrderPrice(item.insuPrice, item.eo041, "O");
                    eo160.Eo16InsuPrice = item.insuPrice;
                    eo160.Eo16Quantity = item.eobag.EobgQty;
                    eo160.Eo16SupplyPrice = Math.Ceiling(eo160.Eo16UnitCost * eo160.Eo16Quantity / 11 * 10);
                    eo160.Eo16TaxPrice = eo160.Eo16UnitCost * eo160.Eo16Quantity - eo160.Eo16SupplyPrice;
                    eo160.Eo16OutQuantity = 0;
                    eo160.Eo16ReDiGcode = "0010";
                    eo160.Eo16ReDi = "1";
                    eo160.Eo16Other = "";
                    eo160.Eo16IfOrdNum = "";
                    eo160.Eo16ConfirmFlag = "";
                    eo160.Eo16ConfirmQty = 0;
                    eo160.Eo16CtrPYl = item.eo041.Eo041CtrPYl;
                    eo160.Eo16HpinYl = item.eo041.Eo041HpinYl ?? 0;
                    eo160.Eo16AddCd = SESSION_USERCD;
                    eo160.Eo16AddDate = DateTime.Now.ToString("yyyyMMdd");

                    sumSupplyPrice += eo160.Eo16SupplyPrice;
                    sumTaxPrice += eo160.Eo16TaxPrice;

                    _context.Eo160s.Add(eo160);
                }

                newEo150.Eo15SupplyPrice = (double)sumSupplyPrice;
                newEo150.Eo15TaxPrice = sumTaxPrice;
                newEo150.Eo15TotPrice = sumSupplyPrice + sumTaxPrice;
                _context.Entry(newEo150).State = EntityState.Modified;
            }

            #endregion

            try
            {
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }

            return NoContent();
        }
        
        /// <summary>
        /// 반품등록
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ReturnInsert")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<IEnumerable<Eo040>> ReturnInsert(Order order)
        {
            Eo150 newEo150 = null;
            string today = DateTime.Now.ToString("yyyyMMdd");

            #region 담당자 목록(groupby 거래처/간납처/담당자/창고구분)
            var salesList = (from o in order.eoBags
                             join eo030 in _context.Eo030s on o.EobgDropCd equals eo030.Eo03VenCd
                             join eo040 in _context.Eo040s on o.EobgPhysicCd equals eo040.Eo04PhysicCd
                             join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals
                                                                                      new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                             where eo041.Eo041DelFlag.Equals("N")
                             where eo030.Eo03DelFlag.Equals("N")
                             where eo041.Eo041StartDate.CompareTo(today) <= 0
                             where eo041.Eo041EndDate.CompareTo(today) >= 0
                             group eo041 by new { eo041.Eo041VenCd, eo041.Eo041DropCd, eo030.Eo03SalesMan, eo040.Eo04HouseGb } into vv
                             select vv.Key).ToList();
            #endregion
            #region 단가 목록
            List<Eo041> priceList = (from o in order.eoBags
                                     join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals
                                                                                              new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                                     where eo041.Eo041StartDate.CompareTo(today) <= 0
                                     where eo041.Eo041EndDate.CompareTo(today) >= 0
                                     select eo041).ToList();
            #endregion

            #region 주문등록
            /// 거래처/간납처/담당자별로 마스터 등록
            /// 단가 재적용

            foreach (var salesMan in salesList)
            {
                _context.LoadStoredProc("dbo.UP_ORDER_INSERT_MASTER")
                   .AddParam("@VENCD", salesMan.Eo041VenCd)
                   .AddParam("@OTHER", order.memo)
                   .AddParam("@SUPPLYPRICE", 0)
                   .AddParam("@TAXPRICE", 0)
                   .AddParam("@TOTALPRICE", 0)
                   .AddParam("@USERCD", SESSION_USERCD)
                   .AddParam("@DROPCD", salesMan.Eo041DropCd)
                   .AddParam("@SALESMAN", salesMan.Eo03SalesMan)
                   .AddParam("@HOUSEGB", salesMan.Eo04HouseGb)
                   .AddParam("@ORD_GU", "R")
                   .Exec(r => newEo150 = r.FirstOrDefault<Eo150>());

                decimal sumSupplyPrice = 0;
                decimal sumTaxPrice = 0;

                var bags = (from b in order.eoBags
                            join eo040 in _context.Eo040s on b.EobgPhysicCd equals eo040.Eo04PhysicCd
                            join eo030 in _context.Eo030s on b.EobgDropCd equals eo030.Eo03VenCd
                            join p in priceList on new { vc = b.EobgVenCd.Trim(), dc = b.EobgDropCd.Trim(), pc = b.EobgPhysicCd.Trim() } equals
                                                              new { vc = p.Eo041VenCd.Trim(), dc = p.Eo041DropCd.Trim(), pc = p.Eo041PhysicCd.Trim() }
                            where b.EobgVenCd.Equals(salesMan.Eo041VenCd)
                            where b.EobgDropCd.Equals(salesMan.Eo041DropCd)
                            where eo040.Eo04HouseGb.Equals(salesMan.Eo04HouseGb)
                            where eo030.Eo03SalesMan.Equals(salesMan.Eo03SalesMan)
                            select new { eobag = b, eo041 = p, insuPrice = eo040.Eo04InsuPrice }).ToList();
                short idx = 1;
                foreach (var item in bags)
                {
                    Eo160 eo160 = new Eo160 { };

                    eo160.Eo16RevenCd = item.eobag.EobgVenCd;
                    eo160.Eo16ReYyMmDd = newEo150.Eo15ReYyMmDd;
                    eo160.Eo16ReSeq = newEo150.Eo15ReSeq;
                    eo160.Eo16ResubSeq = idx++;
                    eo160.Eo16PhysicCd = item.eobag.EobgPhysicCd;
                    eo160.Eo16UnitCost = GetOrderPrice(item.insuPrice, item.eo041, "R");
                    eo160.Eo16InsuPrice = item.insuPrice;
                    eo160.Eo16Quantity = item.eobag.EobgQty;
                    eo160.Eo16SupplyPrice = Math.Ceiling(eo160.Eo16UnitCost * eo160.Eo16Quantity / 11 * 10);
                    eo160.Eo16TaxPrice = eo160.Eo16UnitCost * eo160.Eo16Quantity - eo160.Eo16SupplyPrice;
                    eo160.Eo16OutQuantity = 0;
                    eo160.Eo16ReDiGcode = "0010";
                    eo160.Eo16ReDi = "1";
                    eo160.Eo16Other = "";
                    eo160.Eo16IfOrdNum = "";
                    eo160.Eo16ConfirmFlag = "";
                    eo160.Eo16ConfirmQty = 0;
                    eo160.Eo16CtrPYl = item.eo041.Eo041CtrPYl;
                    eo160.Eo16HpinYl = item.eo041.Eo041HpinYl ?? 0;
                    eo160.Eo16AddCd = SESSION_USERCD;
                    eo160.Eo16AddDate = DateTime.Now.ToString("yyyyMMdd");

                    sumSupplyPrice += eo160.Eo16SupplyPrice;
                    sumTaxPrice += eo160.Eo16TaxPrice;

                    eo160.Eo16SupplyPrice = eo160.Eo16SupplyPrice * -1;
                    eo160.Eo16TaxPrice = eo160.Eo16TaxPrice * -1;

                    _context.Eo160s.Add(eo160);
                }

                newEo150.Eo15SupplyPrice = (double)sumSupplyPrice *-1;
                newEo150.Eo15TaxPrice = sumTaxPrice *-1;
                newEo150.Eo15TotPrice = (sumSupplyPrice + sumTaxPrice) *-1;
                _context.Entry(newEo150).State = EntityState.Modified;
            }

            #endregion

            try
            {
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }

            return NoContent();
        }

        /// <summary>
        /// 약가보상등록
        /// </summary>
        /// <param name="order"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("RewardInsert")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<IEnumerable<Eo040>> RewardInsert(Order order)
        {
            Eo150 newEo150 = null;
            string today = DateTime.Now.ToString("yyyyMMdd");
            short seq = 0;

            #region 담당자 목록(groupby 거래처/간납처/담당자/창고구분)
            var salesList = (from o in order.eoBags
                             join eo030 in _context.Eo030s on o.EobgDropCd equals eo030.Eo03VenCd
                             join eo040 in _context.Eo040s on o.EobgPhysicCd equals eo040.Eo04PhysicCd
                             join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals
                                                                                      new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                             where eo041.Eo041DelFlag.Equals("N")
                             where eo030.Eo03DelFlag.Equals("N")
                             where eo041.Eo041StartDate.CompareTo(today) <= 0
                             where eo041.Eo041EndDate.CompareTo(today) >= 0
                             group eo041 by new { eo041.Eo041VenCd, eo041.Eo041DropCd, eo030.Eo03SalesMan, eo040.Eo04HouseGb } into vv
                             select vv.Key).ToList();
            #endregion
            #region 단가 목록
            var priceList = (from o in order.eoBags
                             join eo041 in _context.Eo041s on new { vc = o.EobgVenCd.Trim(), dc = o.EobgDropCd.Trim(), pc = o.EobgPhysicCd.Trim() } equals
                                                                                      new { vc = eo041.Eo041VenCd.Trim(), dc = eo041.Eo041DropCd.Trim(), pc = eo041.Eo041PhysicCd.Trim() }
                             join eo042 in _context.Eo042s on o.EobgPhysicCd.Trim() equals eo042.Eo042PhysicCd.Trim()
                             where eo041.Eo041StartDate.CompareTo(today) <= 0
                             where eo041.Eo041EndDate.CompareTo(today) >= 0
                             where eo042.Eo042DelFlag.Equals("N")
                             select new { eo041, eo042 } ).ToList();
            #endregion

            #region 주문등록
            /// 거래처/간납처/담당자별로 마스터 등록
            /// 단가 재적용

            foreach (var salesMan in salesList)
            {
                var bags = (from b in order.eoBags
                            join eo040 in _context.Eo040s on b.EobgPhysicCd equals eo040.Eo04PhysicCd
                            join eo030 in _context.Eo030s on b.EobgDropCd equals eo030.Eo03VenCd
                            join p in priceList on new { vc = b.EobgVenCd.Trim(), dc = b.EobgDropCd.Trim(), pc = b.EobgPhysicCd.Trim() } equals
                                                              new { vc = p.eo041.Eo041VenCd.Trim(), dc = p.eo041.Eo041DropCd.Trim(), pc = p.eo041.Eo041PhysicCd.Trim() }
                            where b.EobgVenCd.Equals(salesMan.Eo041VenCd)
                            where b.EobgDropCd.Equals(salesMan.Eo041DropCd)
                            where eo040.Eo04HouseGb.Equals(salesMan.Eo04HouseGb)
                            where eo030.Eo03SalesMan.Equals(salesMan.Eo03SalesMan)
                            select new { eobag = b, eo041 = p.eo041, eo042 = p.eo042, insuPrice = eo040.Eo04InsuPrice }).ToList();

                for (int intGu = 0; intGu < 2; intGu++)
                {
                    /// 0 : 반품, 1: 매출
                    _context.LoadStoredProc("dbo.UP_ORDER_INSERT_MASTER")
                   .AddParam("@VENCD", salesMan.Eo041VenCd)
                   .AddParam("@OTHER", order.memo)
                   .AddParam("@SUPPLYPRICE", 0)
                   .AddParam("@TAXPRICE", 0)
                   .AddParam("@TOTALPRICE", 0)
                   .AddParam("@USERCD", SESSION_USERCD)
                   .AddParam("@DROPCD", salesMan.Eo041DropCd)
                   .AddParam("@SALESMAN", salesMan.Eo03SalesMan)
                   .AddParam("@HOUSEGB", salesMan.Eo04HouseGb)
                   .AddParam("@ORD_GU", "W")
                   .AddParam("@SEQ", seq)
                   .Exec(r => newEo150 = r.FirstOrDefault<Eo150>());

                    decimal sumSupplyPrice = 0;
                    decimal sumTaxPrice = 0;

                    if (intGu == 0) seq = newEo150.Eo15ReSeq;

                    short idx = 1;
                    foreach (var item in bags)
                    {
                        Eo160 eo160 = new Eo160 { };

                        eo160.Eo16RevenCd = item.eobag.EobgVenCd;
                        eo160.Eo16ReYyMmDd = newEo150.Eo15ReYyMmDd;
                        eo160.Eo16ReSeq = newEo150.Eo15ReSeq;
                        eo160.Eo16ResubSeq = idx++;
                        eo160.Eo16PhysicCd = item.eobag.EobgPhysicCd;
                        eo160.Eo16PreUnitCost = GetOrderPrice(item.eo042.Eo042PreUnitCost, item.eo041, "R");

                        if (intGu == 0)
                        {
                            eo160.Eo16InsuPrice = item.eo042.Eo042PreUnitCost;
                            eo160.Eo16UnitCost = GetOrderPrice(item.eo042.Eo042PreUnitCost, item.eo041, "R");
                        }
                        else
                        {
                            eo160.Eo16InsuPrice = item.eo042.Eo042UnitCost;
                            eo160.Eo16UnitCost = GetOrderPrice(item.eo042.Eo042UnitCost, item.eo041, "O");
                        }
                        
                        eo160.Eo16Quantity = item.eobag.EobgQty;
                        eo160.Eo16SupplyPrice = Math.Ceiling(eo160.Eo16UnitCost * eo160.Eo16Quantity / 11 * 10);
                        eo160.Eo16TaxPrice = eo160.Eo16UnitCost * eo160.Eo16Quantity - eo160.Eo16SupplyPrice;
                        eo160.Eo16OutQuantity = 0;
                        eo160.Eo16ReDiGcode = "0010";
                        eo160.Eo16ReDi = "1";
                        eo160.Eo16Other = "";
                        eo160.Eo16IfOrdNum = "";
                        eo160.Eo16ConfirmFlag = "";
                        eo160.Eo16ConfirmQty = 0;
                        eo160.Eo16CtrPYl = item.eo041.Eo041CtrPYl;
                        eo160.Eo16HpinYl = item.eo041.Eo041HpinYl ?? 0;
                        eo160.Eo16AddCd = SESSION_USERCD;
                        eo160.Eo16AddDate = DateTime.Now.ToString("yyyyMMdd");

                        sumSupplyPrice += eo160.Eo16SupplyPrice;
                        sumTaxPrice += eo160.Eo16TaxPrice;

                        if (intGu == 0)
                        {
                            eo160.Eo16SupplyPrice *= -1;
                            eo160.Eo16TaxPrice *= -1;
                        }

                        _context.Eo160s.Add(eo160);
                    }

                    if (intGu == 0)
                    {
                        sumSupplyPrice *= -1;
                        sumTaxPrice *= -1;
                    }

                    newEo150.Eo15SupplyPrice = (double)sumSupplyPrice;
                    newEo150.Eo15TaxPrice = sumTaxPrice;
                    newEo150.Eo15TotPrice = (sumSupplyPrice + sumTaxPrice);
                    _context.Entry(newEo150).State = EntityState.Modified;
                }
                
            }

            #endregion

            try
            {
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }

            return NoContent();
        }

        /// <summary>
        /// 주문내역
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <param name="physicCd"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("OrderedList")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<Eo160> GetOrderHistory(string venCd, string dropCd, string physicCd)
        {
            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;
            var baseDate = DateTime.Now.AddMonths(-3).ToString("yyyyMMdd");
            var items = from eo150 in _context.Eo150s
                        join eo160 in _context.Eo160s on new { d = eo150.Eo15ReYyMmDd, s = eo150.Eo15ReSeq } equals
                                                                                 new { d = eo160.Eo16ReYyMmDd, s = eo160.Eo16ReSeq }
                        where eo150.Eo15ReYyMmDd.CompareTo(baseDate) >= 0
                        where eo150.Eo15RevenCd.Equals(venCd)
                        where eo150.Eo15DropCd.Equals(dropCd)
                        where eo160.Eo16PhysicCd.Equals(physicCd)
                        orderby eo150.Eo15AddDate descending
                        select eo160;
            try
            {
                return items.ToList();
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// 재고목록 가져오기
        /// </summary>
        /// <returns></returns>
        private IEnumerable<TRANS_STOCK_VW>  GetStocks()
        {
            IEnumerable<TRANS_STOCK_VW> stocks = null;
            _context.LoadStoredProc("dbo.UP_SELECT_TRANS_STOCK_VW")
                    .Exec(r => stocks = r.ToList<TRANS_STOCK_VW>());
            return stocks;
        }

        /// <summary>
        /// 단가 할인율 처리
        /// 원내 -> 사전 할인 순으로 각각 적용시마다 반올림 또는 버림 처리
        /// </summary>
        /// <param name="unitPrice"></param>
        /// <param name="ctrp"></param>
        /// <param name="hpin"></param>
        /// <returns></returns>
        private decimal GetOrderPrice(decimal insuPrice, Eo041 item, string flag)
        {
            decimal unitPrice = insuPrice;
            if (item.Eo041HpinYl != null && (decimal)item.Eo041HpinYl > 0) unitPrice = CalDecimal(unitPrice - (unitPrice * ((decimal)item.Eo041HpinYl / 100)), flag);
            if (item.Eo041CtrPYl > 0) unitPrice = CalDecimal(unitPrice - (unitPrice * (item.Eo041CtrPYl / 100)), flag);
            return unitPrice;
        }

        /// <summary>
        /// 매출, 반품에 따른 소숫점 처리
        /// 매출 : 반올림
        /// 반품 : 버림
        /// </summary>
        /// <param name="price"></param>
        /// <param name="flag"></param>
        /// <returns></returns>
        private decimal CalDecimal(decimal price, string flag)
        {
            return flag.Equals("O") ? Math.Round(price) : Math.Floor(price);
        }
    }
}
