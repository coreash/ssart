﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eorder.Models.Eorder;
using Eorder.Models;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Net;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class NoticeController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public NoticeController(Eorder_CelltrionContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // GET: api/Notice
        [HttpGet]
        public ActionResult<Paging> GetEoboardNotices(string type, string word, int page, int pageSize)
        {
            //IQueryable<EoboardNotice> items = _context.EoboardNotices
            //       .Where(x=>x.EobdDelFlag.Equals("N"));

            var items = from eoNotice in _context.EoboardNotices
                             join eo060 in _context.Eo060s  on eoNotice.EobdWriteCd equals eo060.Eo06UserCd into vv
                           from mem in vv.DefaultIfEmpty()
                           select new { eoNotice, eo060 = mem };


            if (!string.IsNullOrEmpty(word))
            {
                if (type.Equals("title")) items = items.Where(x => x.eoNotice.EobdTitle.Contains(word));
                if (type.Equals("content")) items = items.Where(x => x.eoNotice.EobdContent.Contains(word));
            }
            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderByDescending(x => x.eoNotice.EobdNum).ToList()
                    .Skip(pageSize * (page - 1))
                    .Take(pageSize).ToList()
            };
        }

        // GET: api/Notice/5
        [HttpGet("{id}")]
        public ActionResult<EoboardNotice> GetEoboardNotice(long id)
        {
            var eoboardNotice = _context.EoboardNotices.Find(id);

            if (eoboardNotice == null)
            {
                return NotFound();
            }

            eoboardNotice.EobdReadCnt++;
            _context.Entry(eoboardNotice).State = EntityState.Modified;
            _context.SaveChanges();

            return eoboardNotice;
        }

        // PUT: api/Notice/5
        [HttpPut("{id}")]
        public IActionResult PutEoboardNotice( long id, [FromForm] string title, [FromForm] string content, IFormFile file = null)
        {
            EoboardNotice eoboardNotice = _context.EoboardNotices.Find(id);
            if (eoboardNotice == null) return NotFound();

            eoboardNotice.EobdTitle = title;
            eoboardNotice.EobdContent = content;
            eoboardNotice.EobdModCd = SESSION_USERCD;
            eoboardNotice.EobdModDate = DateTime.Now;

            eoboardNotice = SaveFile(eoboardNotice, file);

            _context.Entry(eoboardNotice).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EoboardNoticeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Notice
        [HttpPost]
        public ActionResult<EoboardNotice> PostEoboardNotice([FromForm] string title, [FromForm] string content, IFormFile file = null)
        {
            EoboardNotice eoboardNotice = new EoboardNotice
            {
                EobdTitle = title,
                EobdContent = content
            };
            eoboardNotice.EobdWriteDate = DateTime.Now;
            eoboardNotice.EobdWriteCd = SESSION_USERCD;
            eoboardNotice.EobdModDate = DateTime.Now;
            eoboardNotice.EobdModCd = SESSION_USERCD;

            eoboardNotice = SaveFile(eoboardNotice, file);

            _context.EoboardNotices.Add(eoboardNotice);
            _context.SaveChanges();

            return CreatedAtAction("GetEoboardNotice", new { id = eoboardNotice.EobdNum }, eoboardNotice);
        }

        // DELETE: api/Notice/5
        [HttpDelete("{id}")]
        public IActionResult DeleteEoboardNotice(long id)
        {
            var eoboardNotice = _context.EoboardNotices.Find(id);
            if (eoboardNotice == null)
            {
                return NotFound();
            }

            _context.EoboardNotices.Remove(eoboardNotice);
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 파일삭제
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("RemoveFile/{id}")]
        public IActionResult RemoveFile(long id)
        {
            var eoboardNotice = _context.EoboardNotices.Find(id);
            if (eoboardNotice == null)
            {
                return NotFound();
            }
            eoboardNotice.EobdFileName = string.Empty;
            eoboardNotice.EobdFileSize = string.Empty;

            _context.Entry(eoboardNotice).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EoboardNoticeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        /// <summary>
        /// 파일 다운로드
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Download")]
        public IActionResult Download(string fileName)
        {
            var path = Path.Combine(_environment.WebRootPath, "UploadFile\\Notice");
            var filePath =  Path.Combine(path, fileName);

            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            try
            {
                var ret = new FileContentResult(System.IO.File.ReadAllBytes(filePath), "application/octet-stream");
                ret.FileDownloadName = fileName;
                return ret;
            }
            catch{ 
                return StatusCode(StatusCodes.Status500InternalServerError); 
            }
        }

        /// <summary>
        /// 파일 저장
        /// </summary>
        /// <param name="eoNotice"></param>
        /// <param name="file"></param>
        /// <returns></returns>
        private EoboardNotice SaveFile(EoboardNotice eoNotice, IFormFile file)
        {
            if (file?.Length > 0)
            {
                var path = Path.Combine(_environment.WebRootPath, "UploadFile\\Notice");
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);

                var fileName = DateTime.Now.ToString("yyyyMMddHHmmss_") + file.FileName;
                path = Path.Combine(path, fileName);
                using (var stream = System.IO.File.Create(path))
                {
                    file.CopyTo(stream);
                    eoNotice.EobdFileName = fileName;
                    eoNotice.EobdFileSize = file.Length.ToString();
                }
            }
            return eoNotice;
        }

        private bool EoboardNoticeExists(long id)
        {
            return _context.EoboardNotices.Any(e => e.EobdNum == id);
        }
    }
}
