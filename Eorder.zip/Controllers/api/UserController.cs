﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eorder.Models.Eorder;
using Eorder.Models;
using System.Security.Cryptography;
using System.Text;
using Eorder.Helpers;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class UserController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public UserController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        // GET: api/User
        [HttpGet]
        public ActionResult<Paging> GetEo061s(string type1, string type2, string word, int page, int pageSize)
        {
            var items = from eo030 in _context.Eo030s
                        join eo061 in _context.Eo061s on eo030.Eo03VenCd equals eo061.Eo61MemberVen into vv
                        from mem in vv.DefaultIfEmpty()
                        where string.IsNullOrEmpty(eo030.Eo03VenNum) == false
                        select new { eo030, eo061 = mem };
            if (!string.IsNullOrEmpty(type1))
            {
                if(type1.Equals("Y")) items = items.Where(x => x.eo061 != null);
                else items = items.Where(x => x.eo061 == null);
            }
            if (!string.IsNullOrEmpty(word))
            {
                if (type2.Equals("id")) items = items.Where(x => x.eo061.Eo61Id.Equals(word));
                if (type2.Equals("nm")) items = items.Where(x => x.eo030.Eo03OwnerNm.Contains(word));
                if (type2.Equals("vn")) items = items.Where(x => x.eo030.Eo03VenNm.Contains(word));
                if (type2.Equals("vnum")) items = items.Where(x => x.eo030.Eo03VenNum.Replace("-", "").Equals(word.Replace("-", "")));
            }
            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderBy(x => x.eo030.Eo03VenNm).ToList()
                    .Skip(pageSize * (page - 1))
                    .Take(pageSize).ToList()
            };
        }

        // GET: api/User/5
        [HttpGet("{id}")]
        public ActionResult<UserInfo> GetEo061(string id)
        {
            var items = from eo030 in _context.Eo030s
                        join eo061 in _context.Eo061s on eo030.Eo03VenCd equals eo061.Eo61MemberVen into vv
                        from mem in vv.DefaultIfEmpty()
                        select new { eo030, eo061 = mem };

            var item = items.SingleOrDefault(x => x.eo030.Eo03VenCd.Equals(id));

            if (item == null)
            {
                return NotFound();
            }

            return new UserInfo {
                eo030 = item.eo030,
                eo061 = item.eo061
            };
        }

        /// <summary>
        /// 회원정보
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("Info")]
        public ActionResult<UserInfo> GetInfo()
        {

            var items = _context.Eo061s
                        .Join(_context.Eo030s, x => x.Eo61MemberVen, y => y.Eo03VenCd, (x, y) => new { eo061 = x, eo030 = y })
                        .Where(x => x.eo061.Eo61Num.Equals(Int32.Parse(SESSION_USERCD)));
            //.SingleOrDefault();
            var item = items.SingleOrDefault();
            if (item == null)
            {
                return NotFound();
            }

            return new UserInfo
            {
                eo030 = item.eo030,
                eo061 = item.eo061
            };
        }

        // PUT: api/User/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public IActionResult PutEo061(long id, Eo061 eo061)
        {
            var hashObj = new HashBytesForMsSql();
            eo061.Eo61ModDate = DateTime.Now;
            eo061.Eo61ModNum = SESSION_USERCD;
            eo061.Eo61Pw = hashObj.GetHashData(eo061.Eo61Pwd);
            if (id != eo061.Eo61Num)
            {
                return BadRequest();
            }

            _context.Entry(eo061).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Eo061Exists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/User
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public ActionResult<Eo061> PostEo061(Eo061 eo061)
        {
            var hashObj = new HashBytesForMsSql();
            List<Eo061> data = _context.Eo061s.ToList();
            var num = data.Count() > 0 ? data.Max(x => x.Eo61Num) : 0;
            eo061.Eo61Num = num + 1;
            eo061.Eo61AddDate = DateTime.Now;
            eo061.Eo61AddNum = SESSION_USERCD;
            eo061.Eo61ModDate = DateTime.Now;
            eo061.Eo61ModNum = SESSION_USERCD;
            eo061.Eo61Pw = hashObj.GetHashData(eo061.Eo61Pwd);

            _context.Eo061s.Add(eo061);
            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateException e)
            {
                if (Eo061Exists(eo061.Eo61Num))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetEo061", new { id = eo061.Eo61Num }, eo061);
        }

        // DELETE: api/User/5
        [HttpDelete("{id}")]
        public IActionResult DeleteEo061(long id)
        {
            var eo061 = _context.Eo061s.Find(id);
            if (eo061 == null)
            {
                return NotFound();
            }

            _context.Eo061s.Remove(eo061);
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 담당자정보
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("SalesInfo")]
        public ActionResult<Eo060> GetSalesInfo()
        {
            return _context.Eo060s.Find(SESSION_USERCD);
        }

        /// <summary>
        /// 담당자정보 수정
        /// </summary>
        /// <param name="id"></param>
        /// <param name="eo060"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("SalesInfo/{id}")]
        public IActionResult PutEo060(string id, Eo060 eo060)
        {
            eo060.Eo06ModCd = SESSION_USERCD;
            eo060.Eo06ModDate = DateTime.Now;
            _context.Entry(eo060).State = EntityState.Modified;
            _context.SaveChanges();

            return NoContent();
        }

        [HttpGet]
        [Route("existsID")]
        public bool ExistsID(string id)
        {
            return _context.Eo061s.Any(e => e.Eo61Id.Equals(id));
        }
        private bool Eo061Exists(long id)
        {
            return _context.Eo061s.Any(e => e.Eo61Num == id);
        }

        
    }
}
