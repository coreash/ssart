﻿using Eorder.Helpers;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class CardController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly string KSPAY_WEBHOST_URL;
        private readonly string KSPAY_MID;
        private readonly string KSPAY_API_KEY;
        public CardController(Eorder_CelltrionContext context)
        {
            _context = context;
            KSPAY_WEBHOST_URL = "https://pay.ksnet.co.kr/kspay/webfep/api/v1//card/pay/noncert";
#if DEBUG
            KSPAY_MID = "2999199990";
            KSPAY_API_KEY = "pgapi Mjk5OTE5OTk5MDpNQTAxOjNEMUVBOEVBRUM0NzA1MTFBMkIyNUVFMzQwRkI5ODQ4";
#else
            //KSPAY_MID = "2999199990";
            //KSPAY_API_KEY = "pgapi Mjk5OTE5OTk5MDpNQTAxOjNEMUVBOEVBRUM0NzA1MTFBMkIyNUVFMzQwRkI5ODQ4";
            KSPAY_MID = "2001106019";
            KSPAY_API_KEY = "pgapi MjAwMTEwNjAxOTpNQTAxOkNEMUJFNTMzNEM2ODM5MEM2N0EzOTI5RjNBRDI1RjIw";
#endif
        }

        /// <summary>
        /// 카드결제목록
        /// </summary>
        /// <param name="type"></param>
        /// <param name="word"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("CardPaymentList")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<CardPaymentList> GetCardList(string type, string word, string startDate, string endDate)
        {
            var items = GetData(type, word, startDate, endDate);

            return items.ToList();
        }

        /// <summary>
        /// 결제 대상 가져오기(이전달)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("PayInfo")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<EoCollectMoney> GetPayInfo()
        {
            if (string.IsNullOrEmpty(SESSION_VENCD)) return null;
            var today = DateTime.Now.ToString("yyyyMMdd");
            var prevMonth = DateTime.Now.AddMonths(-1).ToString("yyyyMM");

            var ven = (from v in _context.Eo030s
                       where v.Eo03VenCd.Equals(SESSION_VENCD)
                       select v).FirstOrDefault();
            var items = from c in _context.EoCollectMonies
                        join v in _context.Eo030s on c.VenCd equals v.Eo03VenCd
                        where v.Eo03VenNum.Equals(ven.Eo03VenNum)
                        where c.YYYYMM.Equals(prevMonth)
                        ///where c.ExpireDate.CompareTo(today) >= 0
                        where !c.PayFlag.Equals("Y")
                        select c;
            /* 강제고정
            var vens = (from v in _context.Eo030s
                        where v.Eo03VenNum.Equals(ven.Eo03VenNum)
                        select v).ToList();
            var items = new List<EoCollectMoney>();
            int cnt = 1;
           foreach (var item in vens)
            {
                items.Add(new EoCollectMoney { 
                    Price = 1000 * cnt,
                    VenCd = item.Eo03VenCd,
                    YYYYMM = DateTime.Now.ToString("yyyyMM"),
                    ExpireDate = "20220101"
                });
                cnt++;
            }
            */
            
            return items.ToList();
        }

        /// <summary>
        /// 결제 진행
        /// </summary>
        /// <param name="payInfo"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Pay")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public string PostPay(ReqCardPay payInfo)
        {
            var objPayload = SetPayloadData(payInfo.payload);

            //payInfo.totalAmount = 100;  // 테스트용으로 100원만..

            payInfo.mid = KSPAY_MID;
            payInfo.orderNumb = GetOrderNumb(objPayload);

            //아래 항목들은 고정
            payInfo.productType = "REAL";
            payInfo.interestType = "PG";
            payInfo.currencyType = "KRW";
            payInfo.taxFreeAmount = 0;

            try
            {
                var eoCardPayment = SavePayment_PrePay(payInfo, objPayload);
                if (eoCardPayment == null)
                {
                    throw new BadHttpRequestException("Internal Server Error", 500);
                }
                var request = (HttpWebRequest)WebRequest.Create(KSPAY_WEBHOST_URL);

                request.Method = "POST";
                request.ContentType = "application/json; utf-8";
                request.Headers.Add("Authorization", KSPAY_API_KEY);

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    var json = JsonConvert.SerializeObject(payInfo);
                    streamWriter.Write(json);
                }

                var response = (HttpWebResponse)request.GetResponse();
                using (var streamReader = new StreamReader(response.GetResponseStream()))
                {
                    var apiResult = streamReader.ReadToEnd();

                    // 리턴받은 결제정보 저장
                    var obj = JsonConvert.DeserializeObject<RespCardPay>(apiResult);

                    eoCardPayment.aid = obj.aid;
                    eoCardPayment.code = obj.code;
                    eoCardPayment.respCode = obj.data.respCode;
                    eoCardPayment.respMessage = obj.data.respMessage;
                    eoCardPayment.tid = obj.data.tid;
                    eoCardPayment.tradeDateTime = obj.data.tradeDateTime;
                    eoCardPayment.payload = obj.data.payload;
                    eoCardPayment.issuerCardType = obj.data.issuerCardType;
                    eoCardPayment.issuerCardName = obj.data.issuerCardName;
                    eoCardPayment.purchaseCardType = obj.data.purchaseCardType;
                    eoCardPayment.purchaseCardName = obj.data.purchaseCardName;
                    eoCardPayment.approvalNumb = obj.data.approvalNumb;
                    eoCardPayment.cardNumb = obj.data.cardNumb;
                    eoCardPayment.expiryDate = obj.data.expiryDate;
                    eoCardPayment.installMonth = obj.data.installMonth;
                    eoCardPayment.cardType = obj.data.cardType;
                    eoCardPayment.partCancelYn = obj.data.partCancelYn;

                    _context.Entry(eoCardPayment).State = EntityState.Modified;
                    _context.SaveChanges();
                    try
                    {
                        var query = _context.LoadStoredProc("dbo.UP_INSERT_SLIP_CARD")
                            .AddParam("@ORDERNUMB", eoCardPayment.EocpOrderNumber)
                            .AddParam("@USER_CD", eoCardPayment.EocpAddCd)
                            .AddParam("@I_TYPE", "CARD_A")
                            .AddParam("@TID", "")
                            .AddParam("@RET_CNT", out IOutParam<Int32> retParam);
                        query.ExecNonQuery();

                        if(retParam.Value <= 0)
                        {
                            _context.LoadStoredProc("dbo.[UP_SMS_SEND]")
                            .AddParam("@ToMobile", "010-3169-0578")
                            .AddParam("@Contents", string.Format("E-ORDER 셀트리온 카드승인 전표처리 오류 [{0}]", eoCardPayment.EocpOrderNumber))
                        .ExecNonQuery();
                        }
                    }
                    catch(Exception e)
                    {
                        _context.LoadStoredProc("dbo.[UP_SMS_SEND]")
                            .AddParam("@ToMobile", "010-3169-0578")
                            .AddParam("@Contents", string.Format("E-ORDER 셀트리온 카드승인 전표처리 오류 [{0}]", eoCardPayment.EocpOrderNumber))
                        .ExecNonQuery();
                    }
                    
                    return apiResult;
                }
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 엑셀 다운로드
        /// </summary>
        /// <param name="opt"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ExcelDown")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult ExcelDown([FromBody] SearchOption opt)
        {
            var excel = new ExcelUtility();
            IWorkbook workbook = null;
            string extension = "xlsx";

            var items = GetData(opt.type, opt.word, opt.startDate, opt.endDate).ToList();
            var excelItems = new List<EoCardPaymentForExcel>();

            for (int ii = 0, l = items.Count(); ii < l; ii++)
            {
                var item = items[ii];
                DateTime? tradeDateTime = !string.IsNullOrEmpty(item.cardPayment.tradeDateTime) ? DateTime.ParseExact(item.cardPayment.tradeDateTime, "yyyyMMddHHmmss", null) : null;
                var venPrefix = item.cardPayment.EocpVenCd.Substring(0, 1);
                excelItems.Add(new EoCardPaymentForExcel
                {
                    순번 = ii + 1,
                    결제상태 = item.cardPayment.code.Equals("A0200") ? "정상결제" : "결제실패",
                    사업부 = venPrefix.Equals("0") ? "케미칼" : venPrefix.Equals("2") ? "바이오" : "다케다",
                    승인일 = tradeDateTime?.ToString("yyyy.MM.dd") ?? "",
                    승인시간 = tradeDateTime?.ToString("HH:mm") ?? "",
                    승인번호 = item.cardPayment.approvalNumb,
                    승인금액 = item.cardPayment.totalAmount,
                    카드사 = item.cardPayment.purchaseCardName,
                    카드번호 = item.cardPayment.cardNumb,
                    유효기한 = item.cardPayment.expiryDate,
                    할부개월 = item.cardPayment.installMonth
                });
            }
            workbook = excel.WriteExcelWithNPOI(excelItems, extension);

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "결제목록_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 출력물 데이터 가져오기
        /// </summary>
        /// <param name="orderNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("PrintData")]
        public ActionResult<EoCardPayment> GetPrintData(string orderNumber)
        {
            var obj = from o in _context.EoCardPayments
                      where o.EocpOrderNumber.Equals(orderNumber)
                      select o;
            return obj.FirstOrDefault();
        }

        /// <summary>
        /// 새 주문번호
        /// </summary>
        /// <param name="targetMonth"></param>
        /// <param name="venCd"></param>
        /// <returns></returns>
        private string GetOrderNumb(PayloadData payload)
        {

            var items = (from p in _context.EoCardPayments
                         where p.EocpVenCd.Equals(payload.venCd)
                         where p.EocpOrderNumber.Substring(0, 6).Equals(payload.targetMonth)
                         orderby p.EocpOrderNumber descending
                         select p.EocpOrderNumber).FirstOrDefault();
            var newOrderNumb = "";

            if (items != null)
            {
                string newSeq = "0000" + (Int32.Parse(items.Substring(12)) + 1).ToString();
                newOrderNumb = payload.targetMonth + payload.venCd + newSeq.Substring(newSeq.Length - 5);
            }
            else
            {
                newOrderNumb = payload.targetMonth + payload.venCd + "00001";
            }
            return newOrderNumb;
        }

        /// <summary>
        /// Payload 값에서 거래처코드, 타겟월 추출
        /// </summary>
        /// <param name="payload"></param>
        /// <returns></returns>
        private PayloadData SetPayloadData(string payload)
        {
            var aryTmp = payload.Split('|');
            if (aryTmp.Length != 2) return null;

            return new PayloadData
            {
                targetMonth = aryTmp[0],
                venCd = aryTmp[1]
            };
        }

        /// <summary>
        /// 주문번호 및 기초정보 저장
        /// </summary>
        /// <param name="payinfo"></param>
        /// <param name="payload"></param>
        /// <returns></returns>
        private EoCardPayment SavePayment_PrePay(ReqCardPay payinfo, PayloadData payload)
        {
            var newCardPayment = new EoCardPayment
            {
                EocpOrderNumber = payinfo.orderNumb,
                EocpVenCd = payload.venCd,
                EocpOrderName = payinfo.userName,
                EocpEmail = payinfo.userEmail,
                EocpAddCd = Int32.Parse(SESSION_USERCD),
                EocpAddDate = DateTime.Now,
                totalAmount = payinfo.totalAmount
            };
            _context.EoCardPayments.Add(newCardPayment);
            _context.SaveChanges();

            return newCardPayment;
        }

        /// <summary>
        /// 결제 목록
        /// </summary>
        /// <param name="type"></param>
        /// <param name="word"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        private IEnumerable<CardPaymentList> GetData(string type, string word, string startDate, string endDate)
        {
            var ven = (from v in _context.Eo030s
                       where v.Eo03VenCd.Equals(SESSION_VENCD)
                       where v.Eo03DelFlag.Equals("N")
                       select v).FirstOrDefault();

            var items = from c in _context.EoCardPayments
                        join p in _context.KSNET_PGARGs on c.tid equals p.pg_deal_numb into vv
                        from tmp in vv.DefaultIfEmpty()
                        join v in _context.Eo030s on c.EocpVenCd equals v.Eo03VenCd
                        where v.Eo03VenNum.Equals(ven.Eo03VenNum)
                        where c.EocpAddDate >= DateTime.Parse(startDate)
                        where c.EocpAddDate < DateTime.Parse(endDate).AddDays(1)
                        orderby c.EocpAddDate descending
                        select new CardPaymentList { cardPayment = c, ksnet = tmp};

            if (!string.IsNullOrEmpty(word))
            {
                if (type == "an") items = items.Where(x => x.cardPayment.approvalNumb.Equals(word));
                if (type == "vn") items = items.Where(x => x.cardPayment.purchaseCardName.Contains(word));
            }
            return items;
        }

        public class SearchOption
        {
            public string type { get; set; }
            public string word { get; set; }
            public string startDate { get; set; }
            public string endDate { get; set; }
        }
    }
}
