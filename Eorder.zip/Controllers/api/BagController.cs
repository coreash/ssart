﻿using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class BagController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public BagController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 장바구니 가져오기
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IEnumerable<dynamic> GetEoBag(string venCd, string bagType)
        {
            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;
            if (string.IsNullOrEmpty(venCd)) return null;
            List<OrderedListForCM> ifList = null;
            string baseDate = DateTime.Now.ToString("yyyyMM") + "01";

            var ven = (from eo030 in _context.Eo030s
                       where eo030.Eo03VenCd.Equals(venCd)
                       select eo030).FirstOrDefault();

            var query = _context.LoadStoredProc("dbo.UP_SELECT_ORDERED_CM_LIST")
                    .AddParam("@VEN_CD", "")
                    .AddParam("@DROP_CD", "")
                    .AddParam("@VEN_NUM", ven.Eo03VenNum);

            query.Exec(r => ifList = r.ToList<OrderedListForCM>());

            var lists = (from eoBag in _context.EoBags
                         join eo030 in _context.Eo030s on eoBag.EobgVenCd equals eo030.Eo03VenCd
                         join eo031 in _context.Eo031s on eoBag.EobgDropCd equals eo031.Eo31DropCd
                         join eo040 in _context.Eo040s on eoBag.EobgPhysicCd equals eo040.Eo04PhysicCd
                         join eo041 in _context.Eo041s on new { vc = eoBag.EobgVenCd, dc = eoBag.EobgDropCd, pc = eoBag.EobgPhysicCd } equals
                                                                                 new { vc = eo041.Eo041VenCd, dc = eo041.Eo041DropCd, pc = eo041.Eo041PhysicCd }
                         join ordered in (
                            from m in _context.Eo150s
                            join d in _context.Eo160s on new { d = m.Eo15ReYyMmDd, s = m.Eo15ReSeq } equals
                                                                            new { d = d.Eo16ReYyMmDd, s = d.Eo16ReSeq }
                            where m.Eo15ReYyMmDd.CompareTo(baseDate) >= 0
                            group new { m, d } by new { m.Eo15RevenCd, m.Eo15DropCd, d.Eo16PhysicCd } into vv
                            select new
                            {
                                VenCd = vv.Key.Eo15RevenCd,
                                DropCd = vv.Key.Eo15DropCd,
                                PhysicCd = vv.Key.Eo16PhysicCd,
                                SumQty = (decimal?)vv.Sum(x => x.d.Eo16Quantity)
                            }
                         ) on new { vc = eo041.Eo041VenCd, dc = eo041.Eo041DropCd, pc = eo041.Eo041PhysicCd } equals
                                new { vc = ordered.VenCd, dc = ordered.DropCd, pc = ordered.PhysicCd } into ord
                         from tmp in ord.DefaultIfEmpty()

                         where eo030.Eo03VenNum.Equals(ven.Eo03VenNum) &&
                                    eoBag.EobgType.Equals(bagType) &&
                                    eoBag.EobgUserCd.Equals(SESSION_USERCD) &&
                                    eo040.Eo04DelFlag.Equals("N")
                         select new { eoBag, eo040, eo031, eo041
                                            , SumQty = tmp.SumQty == null ? 0 : tmp.SumQty 
                                            , SumQtyFourMonth = (decimal?)0 }).ToList();

            var items = (from ll in lists
                        join o in ifList on new { vc = ll.eo041.Eo041VenCd.Trim(), 
                                                              dc = ll.eo041.Eo041DropCd.Trim(), 
                                                              pc = ll.eo041.Eo041PhysicCd.Trim()
                        } equals
                        new { 
                            vc = o.CustCd.Trim(), 
                            dc = o.ECustCd.Trim(), 
                            pc = o.ItemCd.Trim()
                        } into vv
                        from tmp in vv.DefaultIfEmpty()
                        select new { ll.eoBag, ll.eo040, ll.eo031, ll.eo041, SumQty = ll.SumQty, 
                            SumQtyFourMonth = (decimal?)tmp?.SalQty ?? 0}).ToList();

            var groups = (from list in items
                          group list by new { dropCd = list.eo031.Eo31DropCd, dropNm = list.eo031.Eo31DropNm } into vv
                          select vv.Key).ToList();

            List<EoBagList> retBagList = new List<EoBagList>();
            foreach (var item in groups)
            {
                var obj = (from o in items
                           where o.eoBag.EobgDropCd.Equals(item.dropCd)
                           select new EoBagInfo { EoBag = o.eoBag, Eo040 = o.eo040, Eo041 = o.eo041, 
                                                                OrderedQty = o.SumQty, OrderedQtyFourMonth = o.SumQtyFourMonth });

                EoBagList newItem = new EoBagList()
                {
                    Eo31DropNm = item.dropNm,
                    BagList = obj.ToList()
                };
                retBagList.Add(newItem);
            }

            return retBagList;
        }

        /// <summary>
        /// 장바구니 담기
        /// </summary>
        /// <param name="eoBag"></param>
        /// <returns></returns>
        [HttpPost]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<List<EoBag>> PostEoBag(List<EoBag> eoBags)
        {
            for (int ii = 0, l = eoBags.Count; ii < l; ii++)
            {
                EoBag eoBag = eoBags[ii];

                eoBag.EobgUserCd = SESSION_USERCD;
                //eoBag.EobgNum = null;

                EoBag item = ExistBag(eoBag);

                if (item == null)
                {
                    _context.EoBags.Add(eoBag);
                }
                else
                {
                    item.EobgPrice = eoBag.EobgPrice;
                    item.EobgQty = item.EobgQty + eoBag.EobgQty;
                    item.EobgAddDate = DateTime.Now;
                    _context.Entry(item).State = EntityState.Modified;
                }
            }
            try
            {
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }

            return eoBags;
        }

        /// <summary>
        /// 장바구니 수정
        /// </summary>
        /// <param name="eoBag"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<EoBag> PutEoBag(long id, EoBag eoBag)
        {
            if (id != eoBag.EobgNum)
            {
                return NotFound();
            }

            eoBag.EobgUserCd = SESSION_USERCD;
            eoBag.EobgAddDate = DateTime.Now;

            _context.Entry(eoBag).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }

            return NoContent();
        }

        /// <summary>
        /// 장바구니 일괄 삭제
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <returns></returns>
        [HttpDelete]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult DeleteBagAll(EoBag eoBag)
        {
            string venCd = eoBag.EobgVenCd;

            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;

            var ven = (from eo030 in _context.Eo030s
                       where eo030.Eo03VenCd.Equals(venCd)
                       select eo030).FirstOrDefault();
            var newEoBag = from eobags in _context.EoBags
                           join eo030 in _context.Eo030s on eobags.EobgVenCd equals eo030.Eo03VenCd
                           where eo030.Eo03VenNum.Equals(ven.Eo03VenNum)
                           where eobags.EobgType.Equals(eoBag.EobgType)
                           where eobags.EobgUserCd.Equals(SESSION_USERCD)
                           select eobags;

            _context.EoBags.RemoveRange(newEoBag.ToArray());
            _context.SaveChanges();

            return NoContent();
        }

        private EoBag ExistBag(EoBag eoBag)
        {
            return _context.EoBags.Where(x => x.EobgType.Equals(eoBag.EobgType) &&
                                                                      x.EobgVenCd.Equals(eoBag.EobgVenCd) &&
                                                                      x.EobgDropCd.Equals(eoBag.EobgDropCd) &&
                                                                      x.EobgPhysicCd.Equals(eoBag.EobgPhysicCd) &&
                                                                      x.EobgUserCd.Equals(eoBag.EobgUserCd)).FirstOrDefault();
        }

        public class EoBagList
        {
            public string Eo31DropNm { get; set; }
            public IEnumerable<EoBagInfo> BagList { get; set; }

        }
        public class EoBagInfo
        {
            public EoBag EoBag { get; set; }
            public Eo040 Eo040 { get; set; }
            public Eo041 Eo041 { get; set; }
            public decimal? OrderedQty { get; set; }
            public decimal? OrderedQtyFourMonth { get; set; }
        }
    }
}