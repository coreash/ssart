﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eorder.Models.Eorder;
using Eorder.Models;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class ProductController : ControllerBase
    {
        private readonly Eorder_CelltrionContext _context;

        public ProductController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        // GET: api/Product
        [HttpGet]
        public ActionResult<Paging> GetEo040s(string type, string word)
        {
            var items = from eo040 in _context.Eo040s
                        join eo042 in (
                            from t in _context.Eo042s
                            where t.Eo042DelFlag.Equals("N")
                            select t
                        ) on eo040.Eo04PhysicCd equals eo042.Eo042PhysicCd into vv
                        from tmp in vv.DefaultIfEmpty()
                        where eo040.Eo04DelFlag.Equals("N")
                        select new { eo040, eo042 = tmp } ;

            if (!string.IsNullOrEmpty(word))
            {
                if (type.Equals("nm")) items = items.Where(x => x.eo040.Eo04PhysicNm.Contains(word));
                if (type.Equals("stdCd")) items = items.Where(x => x.eo040.Eo04StandardCd.Equals(word));
                if (type.Equals("cd")) items = items.Where(x => x.eo040.Eo04PhysicCd.Equals(word));
            }

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderBy(x => x.eo040.Eo04PhysicNm).ToList()
            };
        }

        // GET: api/Product/5
        [HttpGet("{id}")]
        public ActionResult<Eo040> GetEo040(string id)
        {
            var eo040 = _context.Eo040s.Find(id);

            if (eo040 == null)
            {
                return NotFound();
            }

            return eo040;
        }

        // PUT: api/Product/5
        [HttpPut("{id}")]
        public IActionResult PutEo040(string id, Eo040 eo040)
        {
            if (id != eo040.Eo04PhysicCd.Trim())
            {
                return BadRequest();
            }

            _context.Entry(eo040).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Eo040Exists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Product
        [HttpPost]
        public ActionResult<Eo040> PostEo040(Eo040 eo040)
        {
            _context.Eo040s.Add(eo040);
            _context.SaveChanges();

            return CreatedAtAction("GetEo040", new { id = eo040.Eo04PhysicCd }, eo040);
        }

        // DELETE: api/Product/5
        [HttpDelete("{id}")]
        public IActionResult DeleteEo040(string id)
        {
            var eo040 = _context.Eo040s.Find(id);
            if (eo040 == null)
            {
                return NotFound();
            }

            _context.Eo040s.Remove(eo040);
            _context.SaveChanges();

            return NoContent();
        }

        private bool Eo040Exists(string id)
        {
            return _context.Eo040s.Any(e => e.Eo04PhysicCd == id);
        }


        /// <summary>
        /// 약가인하 설정
        /// </summary>
        /// <param name="eo042"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("PriceDown")]
        public ActionResult<Eo042> PostEo042(Eo042 eo042)
        {
            eo042.Eo042Date = eo042.Eo042Date.Replace("-", "");

            if (Eo042Exists(eo042))
            {
                eo042.Eo042DelFlag = "N";
                eo042.Eo042AddDate = DateTime.Now;
                _context.Entry(eo042).State = EntityState.Modified;
            }
            else
            {
                _context.Eo042s.Add(eo042);
            }

            _context.SaveChanges();

            return eo042;
        }

        /// <summary>
        /// 약가인하 수정
        /// </summary>
        /// <param name="id"></param>
        /// <param name="eo042"></param>
        /// <returns></returns>
        [HttpPut]
        [Route("PriceDown")]
        public IActionResult PutEo042(Eo042 eo042)
        {
            eo042.Eo042Date = eo042.Eo042Date.Replace("-", "");
            _context.Entry(eo042).State = EntityState.Modified;
            _context.SaveChanges();

            return NoContent();
        }

        private bool Eo042Exists(Eo042 eo042)
        {
            return _context.Eo042s.Any(e => e.Eo042Date.Equals(eo042.Eo042Date) && 
                                                                    e.Eo042PhysicCd.Equals(eo042.Eo042PhysicCd) );
        }
    }
}
