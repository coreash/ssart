﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eorder.Models.Eorder;
using Eorder.Models;
using StoredProcedureEFCore;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class PriceController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public PriceController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 단가 목록 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="word"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetEo041s(string type, string word, string venCd, string dropCd)
        {
            if (!SESSION_USERKIND.Equals("U") && string.IsNullOrEmpty(venCd) && string.IsNullOrEmpty(dropCd)) return null;

            string today = DateTime.Now.ToString("yyyyMMdd");
            var baseDate = DateTime.Now.AddMonths(-4).ToString("yyyyMMdd");

            #region ## 기본 목록

            var lists = (from eo041 in _context.Eo041s
                        join eo030 in _context.Eo030s on eo041.Eo041VenCd equals eo030.Eo03VenCd
                        join eo031 in _context.Eo031s on eo041.Eo041DropCd equals eo031.Eo31DropCd
                        join eo040 in _context.Eo040s on eo041.Eo041PhysicCd equals eo040.Eo04PhysicCd
                        where string.IsNullOrEmpty(venCd) || eo041.Eo041VenCd.Equals(venCd)
                        where string.IsNullOrEmpty(dropCd) || eo041.Eo041DropCd.Equals(dropCd)
                        where eo040.Eo04DelFlag.Equals("N")
                        where eo030.Eo03DelFlag.Equals("N")
                        where eo031.Eo31DelFlag.Equals("N")
                        where eo041.Eo041StartDate.CompareTo(today) <= 0
                        where eo041.Eo041EndDate.CompareTo(today) >= 0
                        where eo041.Eo041DelFlag.Equals("N")
                        select new { eo041, eo030, eo031, eo040 }).ToList();
            #endregion

            #region ## 주문내역 
            
            List<OrderedListForCM> ifList = null;

            var query = _context.LoadStoredProc("dbo.UP_SELECT_ORDERED_CM_LIST")
                    .AddParam("@VEN_CD", venCd)
                    .AddParam("@DROP_CD", dropCd ?? "");

            query.Exec(r => ifList = r.ToList<OrderedListForCM>());
            #endregion

            var items = from ll in lists
                        join o in ifList on new { vc = ll.eo041.Eo041VenCd.Trim(), dc = ll.eo041.Eo041DropCd.Trim(), pc = ll.eo041.Eo041PhysicCd.Trim() } equals
                                                       new { vc = o.CustCd.Trim(), dc = o.ECustCd.Trim(), pc = o.ItemCd.Trim() } into vv
                        from tmp in vv.DefaultIfEmpty()
                        select new { ll.eo041, ll.eo030, ll.eo031, ll.eo040, sumQty = tmp?.SalQty ?? 0};

            if (SESSION_USERKIND.Equals("U") && string.IsNullOrEmpty(venCd))
            {
                var ven = (from eo030 in _context.Eo030s
                           where eo030.Eo03VenCd.Equals(SESSION_VENCD)
                           select eo030).FirstOrDefault();

                items = items.Where(x => x.eo030.Eo03VenNum.Equals(ven.Eo03VenNum));
            }
            if (!string.IsNullOrEmpty(word))
            {
                if (type.Equals("nm")) items = items.Where(x => x.eo040.Eo04PhysicNm.Contains(word));
                if (type.Equals("stdCd")) items = items.Where(x => x.eo040.Eo04StandardCd.Equals(word));
                if (type.Equals("cd")) items = items.Where(x => x.eo040.Eo04PhysicCd.Equals(word));
                if (type.Equals("vn")) items = items.Where(x => x.eo030.Eo03VenNm.Contains(word));
                if (type.Equals("dvn")) items = items.Where(x => x.eo031.Eo31DropNm.Contains(word));
            }

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderBy(x => x.eo040.Eo04PhysicNm ).ToList()
            };
        }

        /// <summary>
        /// 단가  및 제한수량 수정
        /// </summary>
        /// <param name="eo041"></param>
        /// <returns></returns>
        [HttpPut]
        public IActionResult PutEo041(Eo041 eo041)
        {

            _context.Entry(eo041).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Eo041Exists(eo041.Eo041VenCd, eo041.Eo041DropCd, eo041.Eo041PhysicCd, eo041.Eo041DelFlag))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        /// <summary>
        /// 단가 및 제한수량 일괄수정
        /// </summary>
        /// <param name="eo041"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostEo041(List<Eo041> eo041s)
        {
            foreach(Eo041 item in eo041s)
            {
                PutEo041(item);
            }
            return NoContent();
        }
        private bool Eo041Exists(string venCd, string dropCd, string physicCd, string delFlag)
        {
            return _context.Eo041s.Any(e => e.Eo041VenCd.Equals(venCd) && e.Eo041DropCd.Equals(dropCd) && e.Eo041PhysicCd.Equals(physicCd) && e.Eo041DelFlag.Equals(delFlag));
        }
    }
}
