﻿using Eorder.Models;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.CollectMoney;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CollectMoneyController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public CollectMoneyController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 수금자료 검색
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<Paging> GetEoCollectMoney([FromQuery] EoCollectMoneySearch param)
        {
            int itemCount = 0;

            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            //param.VenCd = "addVenCd";

            param.VenCd = param.VenCd?.Trim() ?? "";

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoCollectMoneyMap> items = null;
            _context.LoadStoredProc("dbo.UP_EOCOLLECTMONEY_LIST_SELECT")
                .AddParam("@CollectMonth", param.CollectMonth)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<EoCollectMoneyMap>());
            if (items != null && items.Count > 0)
            {
                itemCount = Convert.ToInt32(items.First().TotalCount);
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }

        /// <summary>
        /// 수금요청서
        /// </summary>
        /// <param name="vc"></param>
        /// <param name="dt"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IEnumerable<EoCollectMoneyPrint> GetPrintData(string dt )
        {
            return (from o in _context.EoCollectMonies
                        join eo030 in _context.Eo030s on o.VenCd equals eo030.Eo03VenCd
                        join validVen  in (
                            from eo030 in _context.Eo030s
                            where eo030.Eo03VenCd.Equals(SESSION_VENCD)
                            where eo030.Eo03DelFlag.Equals("N")
                            select eo030
                        ) on eo030.Eo03VenNum equals validVen.Eo03VenNum
                        where o.YYYYMM.Equals(dt)
                        select new EoCollectMoneyPrint { eoCollectMoney =  o, eo030 = eo030 });
        }
    }
}
