﻿using Eorder.Filters;
using Eorder.Models;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.Stocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class StockController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public StockController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 재고자료 검색
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetEoStocks([FromQuery] EoStockSearch param)
        {
            int itemCount = 0;

            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            //param.VenCd = "addVenCd";

            param.VenCd = param.VenCd?.Trim() ?? "";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoStock> items = null;
            _context.LoadStoredProc("dbo.UP_EOSTOCKS_LIST_SELECT")
                .AddParam("@StockMonth", param.StockMonth)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<EoStock>());

            if (items != null && items.Count > 0)
            {
                itemCount = Convert.ToInt32(items.First().TotalCount);
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }
    }
}
