﻿using Eorder.Helpers;
using Eorder.Models;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.Sales;
using Eorder.Models.Celltrion.TransCards;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class TransCardController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public TransCardController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        [HttpGet]
        public ActionResult<Paging> GetTransCards([FromQuery] TransCardSearch param)
        {
            int itemCount = 0;
            string srchFlag = "";

            if (SESSION_USERKIND.Equals("U") && string.IsNullOrWhiteSpace(param.VenCd))
            {
                param.VenCd = SESSION_VENCD;
                srchFlag = "VN";
            }

            param.VenCd = param.VenCd?.Trim() ?? "";
            //param.VenCd = "addVenCd"; 

            param.Page = 1;
            param.PageSize = 99999999;
            param.DropCd = param.DropCd ?? "";

            List<TransCardView> items = null;

            if (param.IsValid)
            {
                var startDate = new SqlParameter("@StartDate", param.StartDate);
                var endDate = new SqlParameter("@EndDate", param.EndDate);
                var venCd = new SqlParameter("@VenCd", param.VenCd);
                var dropCd = new SqlParameter("@DropCd", param.DropCd);
                var flag = new SqlParameter("@Flag", srchFlag);
                var venNum = new SqlParameter("@VenNum", param.VenNum ?? "");
                //var pageNo = new SqlParameter("@PageNo", param.Page);
                //var pageSize = new SqlParameter("@PageSize", param.PageSize);

                string sql = @"
                    EXEC UP_TRANS_CARD_LIST_SELECT 
                          @StartDate
                        , @EndDate
                        , @VenCd
                        , @DropCd
                        , @Flag
                    ";
                sql = "EXEC UP_TRANS_CARD_LIST_SELECT {0}, {1}, {2}, {3}, {4}, {5}";
                items = _context.TransCardViews
                    .FromSqlRaw(sql, startDate, endDate, venCd, dropCd, flag, venNum)
                    .ToList();
            }
            else
            {
                items =  new List<TransCardView>();
            }

            if (items != null && items.Count > 0)
            {
                
                if (items.Count == 1)
                {
                    #region 이월데이터밖에 없는 경우. 해당 년도 데이터 모두 가져와서 계산한다. 
                    /// 해당월의 데이터가 없는 경우만 들어오게 됨.
                    var startDate = new SqlParameter("@StartDate", DateTime.Now.Year +"0101");
                    var endDate = new SqlParameter("@EndDate", param.EndDate);
                    var venCd = new SqlParameter("@VenCd", param.VenCd);
                    var dropCd = new SqlParameter("@DropCd", param.DropCd);
                    var flag = new SqlParameter("@Flag", srchFlag);
                    var venNum = new SqlParameter("@VenNum", param.VenNum ?? "");

                    string sql = @"
                    EXEC UP_TRANS_CARD_LIST_SELECT 
                          @StartDate
                        , @EndDate
                        , @VenCd
                        , @DropCd
                        , @Flag
                    ";
                    sql = "EXEC UP_TRANS_CARD_LIST_SELECT {0}, {1}, {2}, {3}, {4}, {5}";
                    var tmpItems = _context.TransCardViews
                        .FromSqlRaw(sql, startDate, endDate, venCd, dropCd, flag, venNum)
                        .ToList();


                    decimal lastYearRmdAmt = 0;
                    decimal lastYearBilAmt = 0;
                    decimal lastYearTRmdAmt = 0;
                    decimal lastYearSalNet = 0;
                    decimal lastYearColAmt = 0;

                    foreach (var item in tmpItems)
                    {
                        if (item.GUBUN.Trim().Equals("W") || item.GUBUN.Trim().Equals("Y")) // 월계/년누계
                        {
                            ///년누계는 마지막 데이터로 업데이트
                            lastYearRmdAmt = item.RMD_AMT ?? 0;
                            lastYearBilAmt = item.BIL_AMT ?? 0;
                            lastYearTRmdAmt = item.T_RMD_AMT ?? 0;
                            lastYearSalNet = item.SAL_NET ?? 0;
                            lastYearColAmt = item.COL_AMT ?? 0;
                        }
                    }

                    items.Add(new TransCardView() { 
                        PRT_SEQ = 2,
                        GUBUN = "W",
                        SAL_DATE = param.StartDate.Substring(0,6) +"88",
                        ITEM_NM = "- 월  계 -",
                        SAL_QTY = 0,
                        SAL_PRC = 0,
                        SAL_NET = 0,
                        COL_AMT = 0,
                        RMD_AMT = lastYearRmdAmt,
                        BIL_AMT = lastYearBilAmt,
                        T_RMD_AMT = lastYearTRmdAmt
                    });
                    items.Add(new TransCardView()
                    {
                        PRT_SEQ = 3,
                        GUBUN = "Y",
                        SAL_DATE = param.StartDate.Substring(0, 6) + "99",
                        ITEM_NM = "- 년누계 -",
                        SAL_QTY = 0,
                        SAL_PRC = 0,
                        SAL_NET = lastYearSalNet,
                        COL_AMT = lastYearColAmt,
                        RMD_AMT = lastYearRmdAmt,
                        BIL_AMT = lastYearBilAmt,
                        T_RMD_AMT = lastYearTRmdAmt
                    });

                    #endregion
                }
                
                itemCount = Convert.ToInt32(items.First().TOTAL_COUNT);

                if (srchFlag.Equals("VN") || (!string.IsNullOrEmpty(param.VenNum) && param.VenCd.Equals("")))
                {
                    decimal sumRmdAmt = 0;
                    decimal sumBilAmt = 0;
                    decimal sumTRmdAmt = 0;

                    foreach (var item in items)
                    {
                        if (item.GUBUN.Trim().Equals("-"))  //전기이월
                        {
                            sumRmdAmt = item.RMD_AMT ?? 0;
                            sumBilAmt = item.BIL_AMT ?? 0;
                            sumTRmdAmt = item.T_RMD_AMT ?? 0;
                        }
                        else if (item.GUBUN.Trim().Equals("W") || item.GUBUN.Trim().Equals("Y")) // 월계/년누계
                        {
                        }
                        else
                        {
                            sumRmdAmt += (item.SAL_NET ?? 0);
                            sumBilAmt += (item.BIL_AMT ?? 0);
                            sumBilAmt = sumRmdAmt - sumBilAmt;

                            item.RMD_AMT = sumRmdAmt;
                            item.BIL_AMT = sumBilAmt;
                            item.T_RMD_AMT = sumTRmdAmt;
                        }
                    }
                }
                

                
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }
    }
}
