﻿using Eorder.Models;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CommonController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public CommonController(Eorder_CelltrionContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        /// <summary>
        /// 거래처명으로 검색결과 (SelectBox option 채우기)
        /// </summary>
        /// <param name="searchText"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<Paging> GetVendors([FromQuery] string searchText)
        {
            int itemCount = 0;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<Eo030SelectOptionList> items = null;
            _context.LoadStoredProc("dbo.UP_EO030_SEARCH_SELECT")
                .AddParam("@SearchText", searchText)
                .Exec(r => items = r.ToList<Eo030SelectOptionList>());

            if (items != null && items.Count > 0)
            {
                itemCount = Convert.ToInt32(items.Count);
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }

        /// <summary>
        /// 간납처 목록
        /// </summary>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<Eo031> GetDropList(string venCd)
        {
            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;
            if (string.IsNullOrEmpty(venCd))
            {
                return null;
            }
            var ven = (from eo030 in _context.Eo030s
                       where eo030.Eo03VenCd.Equals(venCd)
                       select eo030).FirstOrDefault();

            List<Eo031> items = null;

            var query = _context.LoadStoredProc("dbo.UP_SELECT_DROP_LIST")
                    .AddParam("@VEN_NUM", ven.Eo03VenNum)
                    .AddParam("@SALES_MAN_CD", SESSION_USERKIND.Equals("S") ? SESSION_USERCD : "");

            query.Exec(r => items = r.ToList<Eo031>());

            return items;
        }

        /// <summary>
        /// 간납처 목록(특정 거래처 대상만)
        /// </summary>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<Eo031> GetDropListForVen(string venCd)
        {
            if (string.IsNullOrEmpty(venCd))            //전체 거래처 선택시
            {
                if (SESSION_USERKIND.Equals("U")) //사용자는 사업자번호별 간납처 리턴
                {
                    return GetDropList("");
                }
                else
                {
                    return null;
                }
            }

            var items = from eo030 in _context.Eo030s
                        join eo033 in _context.Eo033s on eo030.Eo03VenCd equals eo033.Eo033VenCd
                        join eo031 in _context.Eo031s on eo033.Eo033DropCd equals eo031.Eo31DropCd
                        where eo030.Eo03VenCd.Equals(venCd)
                        where eo031.Eo31DelFlag.Equals("N")
                        where SESSION_USERKIND != "S" || eo030.Eo03SalesMan.Equals(SESSION_USERCD)
                        select eo031;

            return items.Distinct().ToList();
        }

        /// <summary>
        /// 사용자 거래처 목록(사업자번호기준)
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="venNum"></param>
        /// <returns></returns>
        public List<Eo030> GetUserVenList(string venCd, string venNum = "")
        {
            if (!SESSION_USERKIND.Equals("U")) return GetVenList(venCd, venNum);

            Eo030 ven = (from eo030 in _context.Eo030s
                         where eo030.Eo03VenCd.Equals(SESSION_VENCD)
                         where eo030.Eo03DelFlag != "Y"
                         select eo030).FirstOrDefault();

            IEnumerable<Eo030> items = from eo030 in _context.Eo030s
                                       where eo030.Eo03VenNum.Equals(ven.Eo03VenNum)
                                       where eo030.Eo03DelFlag != "Y"
                                       select eo030;
            return items.ToList();
        }

        /// <summary>
        /// 거래처목록
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="venNum"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<Eo030> GetVenList(string venCd, string venNum = "")
        {
            if (string.IsNullOrEmpty(venCd) && string.IsNullOrEmpty(venNum)) return null;
            if (!IsAdmin && !IsSales)
            {
                return null;
            }
            var items = from eo030 in _context.Eo030s
                        join eo041VenCd in (
                            from t in _context.Eo041s
                            where t.Eo041DelFlag.Equals("N")
                            group t by t.Eo041VenCd into vv
                            select vv.Key
                        ) on eo030.Eo03VenCd equals eo041VenCd
                        where eo030.Eo03DelFlag.Equals("N")
                        where string.IsNullOrEmpty(venCd) || eo030.Eo03VenCd.Equals(venCd) || eo030.Eo03VenNm.Contains(venCd)
                        where string.IsNullOrEmpty(venNum) || eo030.Eo03VenNum.Equals(venNum)
                        select eo030;

            if (SESSION_USERKIND.Equals("S"))
            {
                items = from v in items
                        where v.Eo03SalesMan.Equals(SESSION_USERCD)
                        select v;
            }

            return items.ToList();
        }

        /// <summary>
        /// 사업자목록
        /// </summary>
        /// <param name="venNumCd"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public List<Eo030> GetVenGroupList(string venNumCd)
        {
            var items = from ven in _context.Eo030s
                        join g in (
                            from s in _context.Eo030s
                            join eo041VenCd in (
                                from t in _context.Eo041s
                                where t.Eo041DelFlag.Equals("N")
                                group t by t.Eo041VenCd into vv
                                select vv.Key
                            ) on s.Eo03VenCd equals eo041VenCd
                            where s.Eo03VenCd.Equals(venNumCd) || s.Eo03VenNm.Contains(venNumCd)
                            where s.Eo03DelFlag.Equals("N")
                            group s by s.Eo03VenNum into vv
                            select new { venNum = vv.Key, venCd = vv.Min(x => x.Eo03VenCd) }
                        ) on ven.Eo03VenCd equals g.venCd
                        where ven.Eo03DelFlag.Equals("N")
                        where !string.IsNullOrEmpty(ven.Eo03VenNum.Trim())
                        select ven;

            return items.ToList();
        }

        /// <summary>
        /// 이메일 전송 테스트
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult PostSendEmail()
        {
            //string SmtpHost = "mail.sitsolution.co.kr";// "mail.celltrionph.com";
            //int SmtpPort = 587;// 25;
            //string SmtpId = "info@sitsolution.co.kr";// "celltrionph\crm";
            //string SmtpPassword = "#$sit3301$#";// "celltrion123!";

            string SmtpHost = "mail.celltrionph.com"; //118.128.50.170
            int SmtpPort = 25;
            string SmtpId = "crm@celltrionph.com"; //celltrion\crm  , crm
            string SmtpPassword = "celltrion123!";


            using (var client = new SmtpClient(SmtpHost, SmtpPort))
            {
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential(SmtpId, SmtpPassword);
                client.EnableSsl = false;
                var path = Path.Combine(_environment.WebRootPath, "UploadFile\\Notice\\test.zip");
                var attachment = new System.Net.Mail.Attachment(path);
                //crm@celltrionph.com
                var mail = new MailMessage()
                {
                    From = new System.Net.Mail.MailAddress("malir44@sitsolution.co.kr"),
                    Subject = "테스트",
                    SubjectEncoding = System.Text.Encoding.UTF8,
                    Body = "<div><span>Hello Testing ~</span></div>",
                    BodyEncoding = System.Text.Encoding.UTF8,
                    IsBodyHtml = true
                };

                mail.To.Add(new System.Net.Mail.MailAddress("ksh2594@gmail.com"));
                mail.Attachments.Add(attachment);
                client.Send(mail);
            }

            return NoContent();
        }
    }
}
