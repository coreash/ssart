﻿using Eorder.Helpers;
using Eorder.Models;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class OrderSearchController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public OrderSearchController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 주문서 목록
        /// </summary>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <param name="type"></param>
        /// <param name="phyNm"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetOrderSearch(string venCd, string dropCd, string type, string phyNm, string startDate, string endDate, string ordGu)
        {
            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;
            if (string.IsNullOrEmpty(venCd)) venCd = "";

            List<OrderSearchMaster> items = null;
            try
            {
                var query = _context.LoadStoredProc("dbo.UP_ORDERSEARCH_SELECT_ORDERSEARCHMASTERLIST")
                    .AddParam("@YYYYMMDD_FROM", startDate)
                    .AddParam("@YYYYMMDD_TO", endDate)
                    .AddParam("@VENCD", venCd)
                    //.AddParam("@PAGESIZE", pageSize)
                    //.AddParam("@NOWPAGE", page)
                    .AddParam("@MEMCD", SESSION_USERCD)
                    .AddParam("@MEMBER_KIND", SESSION_USERKIND)
                    .AddParam("@ORDGU", ordGu);
  
                if (phyNm != null) query.AddParam("@SEARCHPRODUCT", phyNm);
                if (type != null) query.AddParam("@REDI", type);
                if (dropCd != null) query.AddParam("@DROPCD", dropCd);

                query.Exec(r => items = r.ToList<OrderSearchMaster>());
            }
            catch
            {
                throw;
            }
            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
            };
        }

        /// <summary>
        /// 주문서 상세
        /// </summary>
        /// <param name="yyyymmdd"></param>
        /// <param name="revenCd"></param>
        /// <param name="seq"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Detail")]
        public ActionResult<Paging> GetOrderSearchDetail(string yyyymmdd, string revenCd, short seq)
        {
            var items = from eo150 in _context.Eo150s
                        join eo160 in _context.Eo160s on new { d = eo150.Eo15ReYyMmDd, v = eo150.Eo15RevenCd, s = eo150.Eo15ReSeq } equals
                                                                                 new { d = eo160.Eo16ReYyMmDd, v = eo160.Eo16RevenCd, s = eo160.Eo16ReSeq }
                        join eo040 in _context.Eo040s on eo160.Eo16PhysicCd equals eo040.Eo04PhysicCd
                        join eo031 in _context.Eo031s on eo150.Eo15DropCd equals eo031.Eo31DropCd
                        join eo010 in _context.Eo010s on new { gcode = eo160.Eo16ReDiGcode, tcode = eo160.Eo16ReDi } equals
                                                                                new { gcode = eo010.Eo01Gcode, tcode = eo010.Eo01Tcode }
                        where eo150.Eo15ReYyMmDd.Equals(yyyymmdd)
                        where eo150.Eo15RevenCd.Equals(revenCd)
                        where eo150.Eo15ReSeq.Equals(seq)
                        orderby eo160.Eo16ResubSeq
                        select new { eo160, eo040, eo010, eo031, retFlag=eo150.Eo15ReturnFlag, note=eo150.Eo15Other, retMsg=eo150.Eo15ReturnMsg };

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items.ToList()
            };
        }

        /// <summary>
        /// 거래처정보
        /// </summary>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("VenInfo")]
        public async Task<ActionResult<Eo030>> GetVenInfo(string venCd)
        {
            var items = from eo030 in _context.Eo030s
                        where eo030.Eo03DelFlag.Equals("N")
                        where eo030.Eo03VenCd.Equals(venCd)
                        select eo030 ;
            return await items.FirstOrDefaultAsync();
        }

        /// <summary>
        /// 거래처별 담보
        /// </summary>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("CustScrt")]
        public ActionResult<List<CM_CUST_SCRT_VW>> GetCustScrt(string venCd)
        {
            IEnumerable<CM_CUST_SCRT_VW> items = null;
            var query = _context.LoadStoredProc("dbo.UP_SELECT_CUST_SCRT_VW")
                   .AddParam("@VENCD", venCd);
            query.Exec(r => items = r.ToList<CM_CUST_SCRT_VW>());

            return  items.ToList();
        }

        /// <summary>
        /// 엑셀다운
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("ExcelDown")]
        public IActionResult ExcelDownload(string startDate, string endDate, string venCd, string dropCd, List<Eo150> eo150s)
        {
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;
            string extension = "xlsx";

            var items = GetDetail(startDate, endDate, venCd, dropCd, eo150s);

            var list = items.ToList();
            var venInfo = new List<OrderSearchVenChk>();
            if (IsAdmin)
            {
                var venGroup = (from l in list
                               group l by new OrderSearchMaster() { RevenCd =  l.eo150.Eo15RevenCd, DropCd = l.eo150.Eo15DropCd } into vv
                               select vv.Key ).ToList();
                venInfo = GetVenCheck(venGroup);
            }

            var excelItems = GetExcelType();

            for (int ii = 0, l = list.Count(); ii < l; ii++)
            {
                var item = list[ii];

                if (SESSION_USERKIND.Equals("U"))
                {
                    excelItems.Add(new OrderSearchDetailExcelUser
                    {
                        순번 = ii + 1,
                        주문접수일자 = item.eo160.Eo16AddDate,
                        주문일자 = item.eo160.Eo16ReYyMmDd,
                        사업자번호 = item.eo030.Eo03VenNum.Trim(),
                        간납처명 = item.eo031.Eo31DropNm,
                        표준코드 = item.eo040.Eo04StandardCd.Trim(),
                        품목명 = item.eo040.Eo04PhysicNm,
                        규격 = item.eo040.Eo04Standard,
                        단가 = item.eo160.Eo16UnitCost.ToString("#,##0"),
                        주문수량 = item.eo160.Eo16Quantity,
                        출고수량 = item.eo160.Eo16OutQuantity,
                        공급가 = item.eo160.Eo16SupplyPrice,
                        세액 = item.eo160.Eo16TaxPrice,
                        합계금액 = item.eo160.Eo16SupplyPrice + item.eo160.Eo16TaxPrice,
                        상태 = item.eo010.Eo01Hnm.Trim(),
                        주문메모 = item.eo150.Eo15Other,
                        반품사유 = item.eo150.Eo15ReturnMsg
                    });
                }
                else
                {
                    var venChk = venInfo.Where(x => x.VenCd.Trim().Equals(item.eo150.Eo15RevenCd.Trim()) &&
                                                                             x.DropCd.Trim().Equals(item.eo150.Eo15DropCd.Trim()))
                                                        .FirstOrDefault();
                    excelItems.Add(new OrderSearchDetailExcel
                    {
                        순번 = ii + 1,
                        주문접수일자 = item.eo160.Eo16AddDate,
                        주문일자 = item.eo160.Eo16ReYyMmDd,
                        전표번호 = item.eo160.Eo16IfOrdNum.Trim(),
                        사업자번호 = item.eo030.Eo03VenNum.Trim(),
                        거래처코드 = item.eo030.Eo03VenCd.Trim(),
                        거래처명 = item.eo030.Eo03VenNm,
                        간납처코드 = item.eo031.Eo31DropCd.Trim(),
                        간납처명 = item.eo031.Eo31DropNm,
                        표준코드 = item.eo040.Eo04StandardCd.Trim(),
                        품목코드 = item.eo040.Eo04PhysicCd.Trim(),
                        품목명 = item.eo040.Eo04PhysicNm,
                        규격 = item.eo040.Eo04Standard,
                        단가 = item.eo160.Eo16UnitCost.ToString("#,##0"),
                        주문수량 = item.eo160.Eo16Quantity,
                        출고수량 = item.eo160.Eo16OutQuantity,
                        공급가 = item.eo160.Eo16SupplyPrice,
                        세액 = item.eo160.Eo16TaxPrice,
                        합계금액 = item.eo160.Eo16SupplyPrice + item.eo160.Eo16TaxPrice,
                        상태 = item.eo010.Eo01Hnm.Trim(),
                        주문메모 = item.eo150.Eo15Other,
                        반품사유 = item.eo150.Eo15ReturnMsg,
                        고액 = venChk.RmdCk,
                        회전 = venChk.TurnCk,
                        잔고 = venChk.JanCk,
                        담보 = venChk.ScrtCk,
                        승인ID = item.eo150.Eo15ConfirmUserCd != null ? item.eo060?.Eo06UserId ?? "adminct" : ""
                    });
                }
                
            }
            workbook = excel.WriteExcelWithNPOI(excelItems, extension);

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "주문내역_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 프린트
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetData")]
        public ActionResult<Paging> GetPrintData(string startDate, string endDate, string venCd, string dropCd, List<Eo150> eo150s)
        {
            var items = GetDetail(startDate, endDate, venCd, dropCd, eo150s);

            return new Paging{ 
                Count=items.Count(),
                List = items.ToList()
            };
        }

        /// <summary>
        /// 주문수정
        /// </summary>
        /// <param name="eo160"></param>
        /// <returns></returns>
        [HttpPut]
        public IActionResult PutOrderSearch(List<Eo160> eo160)
        {
            decimal sumSupplyPrice = 0;
            decimal sumTaxPrice = 0;
            string ordGu = string.Empty;

            for (int ii=0, l=eo160.Count(); ii<l; ii++)
            {
                var item = eo160[ii];

                if (string.IsNullOrEmpty(ordGu)) ordGu = item.Eo16SupplyPrice > 0 ? "O" : "R";

                item.Eo16ModCd = SESSION_USERCD;
                item.Eo16ModDate = DateTime.Now;
                item.Eo16SupplyPrice = Math.Ceiling(item.Eo16UnitCost * item.Eo16Quantity / 11 * 10);
                item.Eo16TaxPrice = item.Eo16UnitCost * item.Eo16Quantity - item.Eo16SupplyPrice;

                sumSupplyPrice += item.Eo16SupplyPrice;
                sumTaxPrice += item.Eo16TaxPrice;

                if (ordGu.Equals("R"))
                {
                    item.Eo16SupplyPrice = item.Eo16SupplyPrice * -1;
                    item.Eo16TaxPrice = item.Eo16TaxPrice * -1;
                }
                _context.Entry(item).State = EntityState.Modified;
            }
            Eo160 firstItem = eo160[0];
            Eo150 eo150 = _context.Eo150s.Find(firstItem.Eo16ReYyMmDd, firstItem.Eo16RevenCd, firstItem.Eo16ReSeq);
            eo150.Eo15SupplyPrice = (double)sumSupplyPrice;
            eo150.Eo15TaxPrice = sumTaxPrice;
            eo150.Eo15TotPrice = sumSupplyPrice + sumTaxPrice;

            if (ordGu.Equals("R"))
            {
                eo150.Eo15SupplyPrice = eo150.Eo15SupplyPrice * -1;
                eo150.Eo15TaxPrice = eo150.Eo15TaxPrice * -1;
                eo150.Eo15TotPrice = eo150.Eo15TotPrice * -1;
            }

            _context.Entry(eo150).State = EntityState.Modified;

            _context.SaveChanges();
            

            return NoContent();
        }

        /// <summary>
        /// 주문승인
        /// </summary>
        /// <param name="yyyymmdd"></param>
        /// <param name="seq"></param>
        /// <returns></returns>
        private int GetConfirm(string yyyymmdd, string revenCd, short seq, string other, string confirmDateToIF)
        {
            int chk = 0;
            try
            {
                var query = _context.LoadStoredProc("dbo.UP_INSERT_IFORDER_MASTER")
                       .AddParam("@RE_YYYYMMDD", yyyymmdd)
                       .AddParam("@REVEN_CD", revenCd)
                       .AddParam("@RE_SEQ", seq)
                       .AddParam("@USER_CD", SESSION_USERCD)
                       .AddParam("@NOTE", other)
                       .AddParam("@CONFIRM_DATE_TOIF", confirmDateToIF)
                       .AddParam("@RET", out IOutParam<int> ret);
                query.ExecNonQuery();
                chk = Int32.Parse(ret.ToString());
            }
            catch(Exception )
            {
                _context.LoadStoredProc("dbo.[UP_SMS_SEND]")
                    .AddParam("@ToMobile", "010-3169-0578")
                    .AddParam("@Contents", string.Format("E-ORDER 셀트리온 승인실패{0},{1},{2},{3}", yyyymmdd, revenCd, seq, SESSION_USERCD))
                    .ExecNonQuery();
            }
            if (chk == 0)
            {
                _context.LoadStoredProc("dbo.[UP_SMS_SEND]")
                    .AddParam("@ToMobile", "010-3169-0578")
                    .AddParam("@Contents", string.Format("E-ORDER 셀트리온 승인실패{0},{1},{2},{3}", yyyymmdd, revenCd, seq, SESSION_USERCD))
                    .ExecNonQuery();
            }
            return chk;
        }

        /// <summary>
        /// 주문거절
        /// </summary>
        /// <param name="eo150"></param>
        /// <returns></returns>
        private IActionResult PutCancelOrderSearch(string yyyymmdd, string revenCd, short seq, string msg)
        {
            Eo150 eo150 = _context.Eo150s.Find(yyyymmdd, revenCd, seq );

            eo150.Eo15ReturnDate = DateTime.Now;
            eo150.Eo15ReturnUserCd = SESSION_USERCD;
            eo150.Eo15ReturnFlag = "Y";
            eo150.Eo15ReturnMsg = msg;

            _context.Entry(eo150).State = EntityState.Modified;

            var eo160s = from tmp in _context.Eo160s
                         where tmp.Eo16ReYyMmDd.Equals(yyyymmdd)
                         where tmp.Eo16RevenCd.Equals(revenCd)
                         where tmp.Eo16ReSeq.Equals(seq)
                         select tmp;
            var items = eo160s.ToList();
            for(int ii=0, l=items.Count(); ii < l; ii++)
            {
                items[ii].Eo16ReDi = "5";
                _context.Entry(items[ii]).State = EntityState.Modified;
            }
            
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 주문삭제
        /// </summary>
        /// <param name="yyyymmdd"></param>
        /// <param name="revenCd"></param>
        /// <param name="seq"></param>
        /// <returns></returns>
        private int DeleteOrderSearch(string yyyymmdd, string revenCd, short seq)
        {
            Eo150 eo150 = _context.Eo150s.Find(yyyymmdd, revenCd, seq);

            if (!string.IsNullOrEmpty(eo150.Eo15ConfirmDateToIF))
            {
                return 0;
            }
            var eo160 = (from m in _context.Eo150s
                          join d in _context.Eo160s on new { d = m.Eo15ReYyMmDd, v = m.Eo15RevenCd, s = m.Eo15ReSeq } equals
                                                                           new { d = d.Eo16ReYyMmDd, v = d.Eo16RevenCd, s = d.Eo16ReSeq }
                          where m.Eo15ReYyMmDd.Equals(yyyymmdd)
                          where m.Eo15RevenCd.Equals(revenCd)
                          where m.Eo15ReSeq.Equals(seq)
                          select d).ToList();

            if(eo150 != null && eo160.Count() > 0)
            {
                foreach(var item in eo160)
                {
                    item.Eo16ReDi = "4";
                    item.Eo16ModCd = SESSION_USERCD;
                    item.Eo16ModDate = DateTime.Now;
                    _context.Entry(item).State = EntityState.Modified;
                }
                
                _context.SaveChanges();
            }            

            return 1;
        }

        /// <summary>
        /// 승인 취소
        /// </summary>
        /// <param name="yyyymmdd"></param>
        /// <param name="revenCd"></param>
        /// <param name="seq"></param>
        /// <returns></returns>
        private int CancelConfirm(string yyyymmdd, string revenCd, short seq)
        {
            try
            {
                var eo150 = _context.Eo150s.Find(yyyymmdd, revenCd, seq);
                eo150.Eo15ConfirmDateToIF = null;
                eo150.Eo15ConfirmUserCd = null;
                _context.Entry(eo150).State = EntityState.Modified;

                var eo160 = from d in _context.Eo160s
                            where d.Eo16ReYyMmDd.Equals(yyyymmdd)
                            where d.Eo16RevenCd.Equals(revenCd)
                            where d.Eo16ReSeq.Equals(seq)
                            select d;
                foreach(var item in eo160)
                {
                    item.Eo16ConfirmDate = null;
                    item.Eo16ConfirmFlag = string.Empty;
                    item.Eo16ConfirmQty = 0;
                    item.Eo16IfOrdNum = string.Empty;
                    item.Eo16ReDi = "1";
                    item.Eo16OutQuantity = 0;
                    item.Eo16ModCd = SESSION_USERCD;
                    item.Eo16ModDate = DateTime.Now;
                    _context.Entry(item).State = EntityState.Modified;
                }
                _context.SaveChanges();

                return 1;
            }
            catch
            {
                return 0;
            }
        }
        /// <summary>
        /// 선택 주문승인
        /// </summary>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Confirm")]
        public int PostConfirm(List<Eo150> eo150s)
        {
            int ret = 0;

            foreach(Eo150 item in eo150s)
            {
                ret += GetConfirm(item.Eo15ReYyMmDd, item.Eo15RevenCd, item.Eo15ReSeq, item.Eo15Other, item.Eo15ConfirmDateToIF);
            }
            return ret;
        }

        /// <summary>
        /// 선택 주문 거절
        /// </summary>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Cancel")]
        public IActionResult PostCancelOrderSearch(List<Eo150> eo150s)
        {
            foreach(Eo150 item in eo150s)
            {
                PutCancelOrderSearch(item.Eo15ReYyMmDd, item.Eo15RevenCd, item.Eo15ReSeq, item.Eo15ReturnMsg);
            }
            return NoContent();
        }

        /// <summary>
        /// 선택 주문 삭제
        /// </summary>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Delete")]
        public int PostDeleteOrderSearch(List<Eo150> eo150s)
        {
            int succ = 0;
            int err = 0;
            foreach (Eo150 item in eo150s)
            {
                try {
                    var ret = DeleteOrderSearch(item.Eo15ReYyMmDd, item.Eo15RevenCd, item.Eo15ReSeq);
                    succ += ret;
                }
                catch
                {
                    err++;
                }
            }
            return succ;
        }

        /// <summary>
        /// 선택 승인 취소
        /// </summary>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("CancelConfirm")]
        public int PostCancelConfirm(List<Eo150> eo150s)
        {
            int succ = 0;
            int err = 0;
            foreach (Eo150 item in eo150s)
            {
                try
                {
                    var ret = CancelConfirm(item.Eo15ReYyMmDd, item.Eo15RevenCd, item.Eo15ReSeq);
                    succ += ret;
                }
                catch
                {
                    err++;
                }
            }
            return succ;
        }

        /// <summary>
        /// 엑셀/프린트용 데이터 가져오기
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="venCd"></param>
        /// <param name="dropCd"></param>
        /// <param name="eo150s"></param>
        /// <returns></returns>
        private IEnumerable<dynamic> GetDetail(string startDate, string endDate, string venCd, string dropCd, List<Eo150> eo150s)
        {
            string venNum = "";
            if (!IsAdmin && !IsSales)
            {
                venNum = (from eo030 in _context.Eo030s
                          where eo030.Eo03VenCd.Equals(venCd)
                          select eo030.Eo03VenNum).FirstOrDefault();
            }

            var items = (from eo150 in _context.Eo150s
                        join eo160 in _context.Eo160s on new { d = eo150.Eo15ReYyMmDd, s = eo150.Eo15ReSeq } equals
                                                                                    new { d = eo160.Eo16ReYyMmDd, s = eo160.Eo16ReSeq }
                        join eo040 in _context.Eo040s on eo160.Eo16PhysicCd equals eo040.Eo04PhysicCd
                        join eo030 in _context.Eo030s on eo160.Eo16RevenCd equals eo030.Eo03VenCd
                        join eo031 in _context.Eo031s on eo150.Eo15DropCd equals eo031.Eo31DropCd
                        join eo010 in _context.Eo010s on new { gcode = eo160.Eo16ReDiGcode, tcode = eo160.Eo16ReDi } equals
                                                                                new { gcode = eo010.Eo01Gcode, tcode = eo010.Eo01Tcode }
                        join eo060 in _context.Eo060s on eo150.Eo15ConfirmUserCd equals eo060.Eo06UserCd into vv
                        from tmp in vv.DefaultIfEmpty()
                        where eo150.Eo15ReYyMmDd.CompareTo(startDate.Replace("-","")) >= 0
                        where eo150.Eo15ReYyMmDd.CompareTo(endDate.Replace("-", "")) <= 0
                        where string.IsNullOrEmpty(venCd) || eo150.Eo15RevenCd.Equals(venCd)
                        where string.IsNullOrEmpty(dropCd) || eo150.Eo15DropCd.Equals(dropCd)
                        where string.IsNullOrEmpty(venNum) || eo030.Eo03VenNum.Equals(venNum)
                        select new { eo150, eo160, eo040, eo030, eo010, eo031, eo060 = tmp }).ToList();

            var result = from tmp in items
                         join selected in eo150s on new { d = tmp.eo150.Eo15ReYyMmDd, s = tmp.eo150.Eo15ReSeq } equals
                                                                     new { d = selected.Eo15ReYyMmDd, s = selected.Eo15ReSeq }
                         orderby tmp.eo150.Eo15ReYyMmDd, tmp.eo150.Eo15ReSeq, tmp.eo160.Eo16ResubSeq
                         select tmp;

            return result;
        }

        /// <summary>
        /// 엑셀타입(사용자/관리자)
        /// </summary>
        /// <returns></returns>
        private dynamic GetExcelType()
        {
            if (SESSION_USERKIND.Equals("U"))
            {
                return new List<OrderSearchDetailExcelUser>();
            }
            else
            {
                return new List<OrderSearchDetailExcel>();
            }
        }
        
        /// <summary>
        /// 주문등록일자 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("OrderDate")]
        public string GetOrderDate()
        {
            var item = from o in _context.Eo061s
                       select _context.GetOrderDate();
            return item.FirstOrDefault();
        }

        [HttpPost]
        [Route("VenCheck")]
        public List<OrderSearchVenChk> GetVenCheck(List<OrderSearchMaster> masters)
        {
            if (!IsAdmin && !IsSales) return null;

            var items = (from g in masters
                     select _context.OrderSearchVenChks
                         .FromSqlRaw("exec UP_SELECT_VEN_CHK {0}, {1}", g.RevenCd, g.DropCd).ToList().FirstOrDefault()
                     )
                   .ToList();

            return items;
        }

    }
}
