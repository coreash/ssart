﻿using Eorder.Models;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.Reward;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class RewardController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public RewardController(Eorder_CelltrionContext context)
        {
            _context = context;
        }


        /// <summary>
        /// 약가보상신청자료 검색
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetPriceDown([FromQuery] PriceDownSearch param)
        {
            int itemCount = 0;

            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            //param.VenCd = "addVenCd";
            param.VenCd = param.VenCd?.Trim() ?? "";
            param.ProductName = param.ProductName?.Trim() ?? "";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<PriceDown> items = null;
            _context.LoadStoredProc("dbo.UP_EO042_EOPriceDown_LIST_SELECT")
                .AddParam("@StartDate", param.StartDate)
                .AddParam("@EndDate", param.EndDate)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@ProductName", param.ProductName)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<PriceDown>());

            if (items != null && items.Count > 0)
            {
                itemCount = Convert.ToInt32(items.First().TotalCount);
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }

        /// <summary>
        /// 약가보상신청 - 승인처리
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult<ProcedureResult> ConfirmPriceDown([FromBody] List<PriceDownConfirm> param)
        {
            string userCd = SESSION_USERCD;
            ProcedureResult item = null;

            if (param.Count == 0)
            {
                item = new ProcedureResult();
                return item;
            }

            DataTable dt = GetExcelEoPriceDownConfirmDataTable(param);

            _context.LoadStoredProc("dbo.UP_EOPriceDown_Confirm_UPDATE")
                .AddParam("@UserCd", userCd)
                .AddParam(new SqlParameter { 
                    ParameterName = "@UDTT_EOPriceDownConfirm", 
                    SqlDbType = SqlDbType.Structured, 
                    TypeName = "dbo.UDTT_EOPriceDownConfirm", 
                    Value = dt })
                .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

            return Ok(item);
        }

        #region === Private Method ===

        /// <summary>
        /// 약가보상신청자료 엑셀파일에 대한 DataTable 변환
        /// </summary>
        /// <returns></returns>
        private DataTable GetExcelEoPriceDownConfirmDataTable(List<PriceDownConfirm> items)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("downDate", typeof(string));
            dt.Columns.Add("venCd", typeof(string));
            dt.Columns.Add("dropCd", typeof(string));
            dt.Columns.Add("standardCd", typeof(string));
            dt.Columns.Add("quantity", typeof(int));
            dt.Columns.Add("seq", typeof(int));

            foreach (var item in items)
            {
                var dr = dt.NewRow();
                dr["downDate"] = item.DownDate;
                dr["venCd"] = item.VenCd;
                dr["dropCd"] = item.DropCd;
                dr["standardCd"] = item.StandardCd;
                dr["quantity"] = Convert.ToInt32(item.Quantity);
                dr["seq"] = Convert.ToInt32(item.Seq);
                
                dt.Rows.Add(dr);
            }

            return dt;
        }
        #endregion
    }
}
