﻿using Eorder.Filters;
using Eorder.Models;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.Sales;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class SaleController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public SaleController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 재고자료 검색
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetEoSales([FromQuery] EoSaleSearch param)
        {
            int itemCount = 0;

            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            param.VenCd = param.VenCd?.Trim() ?? "";
            param.SaleVenName = param.SaleVenName ?? "";
            param.Page = 1;
            param.PageSize = 99999999;

            //param.VenCd = "addVenCd"; 

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoSale> items = null;
            _context.LoadStoredProc("dbo.UP_EOSALES_LIST_SELECT")
                .AddParam("@SaleMonth", param.SaleMonth)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@SaleVenName", param.SaleVenName)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<EoSale>());

            if (items != null && items.Count > 0)
            {
                itemCount = Convert.ToInt32(items.First().TotalCount);
            }

            return new Paging
            {
                Count = itemCount,
                List = items
            };
        }

        [HttpGet]
        public IEnumerable<UploadedData> CheckUpload(string startDate, string endDate, string venCd)
        {
            if (SESSION_USERKIND.Equals("U") && string.IsNullOrEmpty(venCd)) venCd = SESSION_VENCD;

            List<UploadedData> items = null;
            _context.LoadStoredProc("dbo.UP_EOSalesStocks_Check_Uploaded_Select")
                .AddParam("@START_MONTH", startDate)
                .AddParam("@END_MONTH", endDate)
                .AddParam("@VEN_CD", venCd)
                .Exec(r => items = r.ToList<UploadedData>());

            return items.ToList();

        }
    }
}
