﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Eorder.Models.Eorder;
using StoredProcedureEFCore;
using Eorder.Models;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class MemberController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public MemberController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        // GET: api/Member
        [HttpGet]
        public ActionResult<Paging> GetEo060s(string type, string word, int page, int pageSize)
        {
            var items = _context.Eo060s
                .Where(x => x.Eo06DelFlag.Equals("N") || x.Eo06DelFlag.Equals(""));


            if (!string.IsNullOrEmpty(word))
            {
                if (type.Equals("id")) items = items.Where(x => x.Eo06UserId.Contains(word));
                if (type.Equals("nm")) items = items.Where(x => x.Eo06UserNm.Contains(word));
            }

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items
                    .OrderByDescending(x => x.Eo06UserCd).ToList()
                    .Skip(pageSize * (page - 1))
                    .Take(pageSize).ToList()
            };
        }

        // GET: api/Member/5
        [HttpGet("{id}")]
        public ActionResult<Eo060> GetEo060(string id)
        {
            var eo060 = _context.Eo060s.Find(id);

            if (eo060 == null)
            {
                return NotFound();
            }

            return eo060;
        }

        // PUT: api/Member/5

        [HttpPut("{id}")]
        public IActionResult PutEo060(string id, Eo060 eo060)
        {
            eo060.Eo06ModDate = DateTime.Now;
            eo060.Eo06ModCd = SESSION_USERCD;

            if (id != eo060.Eo06UserCd)
            {
                return BadRequest();
            }

            _context.Entry(eo060).State = EntityState.Modified;

            try
            {
                _context.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!Eo060Exists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Member
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public ActionResult<Eo060> PostEo060(Eo060 eo060)
        {
            _context.Eo060s.Add(eo060);
            _context.SaveChanges();

            return CreatedAtAction("GetEo060", new { id = eo060.Eo06UserCd }, eo060);
        }

        // DELETE: api/Member/5
        [HttpDelete("{id}")]
        public IActionResult DeleteEo060(string id)
        {
            var eo060 = _context.Eo060s.Find(id);
            if (eo060 == null)
            {
                return NotFound();
            }

            _context.Eo060s.Remove(eo060);
            _context.SaveChanges();

            return NoContent();
        }

        private bool Eo060Exists(string id)
        {
            return _context.Eo060s.Any(e => e.Eo06UserCd == id);
        }

    }
}
