﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class DepositController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        public DepositController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 입금표 출력내역 목록
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="venCd"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<List<SL102M01_SFA>> GetDeposit(string startDate, string endDate, string venCd)
        {
            var items = new List<SL102M01_SFA>();

            if (SESSION_USERKIND.Equals("U")) venCd = SESSION_VENCD;

            _context.LoadStoredProc("dbo.[UP_SELECT_DEPOSIT_LIST]")
                .AddParam("@START_DATE", startDate.Replace("-", ""))
                .AddParam("@END_DATE", endDate.Replace("-", ""))
                .AddParam("@VEN_CD", venCd ?? "")
                .Exec(r => items = r.ToList<SL102M01_SFA>());
            return items;
        }
    }
}
