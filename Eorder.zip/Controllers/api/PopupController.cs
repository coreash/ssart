﻿using Eorder.Helpers;
using Eorder.Models;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class PopupController : ControllerBase
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public PopupController(Eorder_CelltrionContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        /// <summary>
        /// 팝업목록
        /// </summary>
        /// <param name="type"></param>
        /// <param name="word"></param>
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetPopup(string type, string word, string gubun, int page, int pageSize)
        {
            var items = _context.EoPopups.Where(x => x.EopopDelFlag.Equals(""));
            if (!string.IsNullOrEmpty(gubun)) items = items.Where(x => x.EopopGubun.Equals(gubun));

            if (!string.IsNullOrEmpty(word))
            {
                if (type.Equals("title")) items = items.Where(x => x.EopopTitle.Contains(word));
                if (type.Equals("content")) items = items.Where(x => x.EopopContent.Contains(word));
            }
            if (type.Equals("today"))
            {
                string today = DateTime.Now.ToString("yyyyMMdd");
                items = items.Where(x => x.EopopStartDate.CompareTo(today) <= 0 &&
                                                            x.EopopEndDate.CompareTo(today) >= 0);
                if (HttpContext.GetSessionName("UK").Equals("U"))
                {
                    items = items.Where(x => x.EopopVenCd.Equals("") || x.EopopVenCd.Contains(HttpContext.GetSessionName("VC")));
                }
            }                        

            int count = items.Count();
            return new Paging
            {
                Count = count,
                List = items
                    .OrderByDescending(x => x.EopopNum).ToList()
                    .Skip(pageSize * (page - 1))
                    .Take(pageSize).ToList()
            };
        }

        /// <summary>
        /// 팝업내용
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public ActionResult<EoPopup> GetPopup(long id)
        {
            EoPopup eoPopup = _context.EoPopups.Find(id);
            if(eoPopup == null)
            {
                return NotFound();
            }
            return eoPopup;
        }

        /// <summary>
        /// 팝업등록
        /// </summary>
        /// <param name="eoPopup"></param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult PostPopup(EoPopup eoPopup)
        {
            eoPopup.EopopStartDate = eoPopup.EopopStartDate.Replace("-", "");
            eoPopup.EopopEndDate = eoPopup.EopopEndDate.Replace("-", "");
            eoPopup.EopopAddDate = DateTime.Now;
            eoPopup.EopopModDate = DateTime.Now;
            eoPopup.EopopCook = string.Concat( "pop", DateTime.Now.ToString("yyyyMMddHHmmss"));

            _context.EoPopups.Add(eoPopup);
            _context.SaveChanges();
            
            return NoContent();
        }

        /// <summary>
        /// 팝업수정
        /// </summary>
        /// <param name="id"></param>
        /// <param name="eoPopup"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public IActionResult PutPopup(long id, EoPopup eoPopup)
        {
            eoPopup.EopopStartDate = eoPopup.EopopStartDate.Replace("-", "");
            eoPopup.EopopEndDate = eoPopup.EopopEndDate.Replace("-", "");

            _context.Entry(eoPopup).State = EntityState.Modified;
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 팝업삭제
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public IActionResult DeletePopup(long id)
        {
            EoPopup eoPopup = _context.EoPopups.Find(id);
            if (eoPopup == null)
            {
                return NotFound();
            }

            _context.EoPopups.Remove(eoPopup);
            _context.SaveChanges();

            return NoContent();
        }

        /// <summary>
        /// 팝업대상 거래처 목록
        /// </summary>
        /// <param name="vc"></param>
        /// <returns></returns>
        [Route("GetVen")]
        [HttpGet]
        public ActionResult<dynamic> GetPopupVen(string vc)
        {
            List<string> venList = vc.Split(",").ToList();
            var items = from eo030 in _context.Eo030s.ToList()
                        join v in venList on eo030.Eo03VenCd.Trim() equals v.Trim()
                        where eo030.Eo03DelFlag.Equals("N")
                        select new { venCd = eo030.Eo03VenCd, venNm = eo030.Eo03VenNm };
            return items.ToList();
        }

        /// <summary>
        /// 파일업로드
        /// </summary>
        /// <param name="upload"></param>
        /// <returns></returns>
        [Route("UploadFile")]
        [HttpPost]
        public UploadedFile UploadFile(IFormFile upload)
        {
            string fileName = "";
            string url = "";
            if (upload?.Length > 0)
            {
                var path = Path.Combine(_environment.WebRootPath, "UploadFile\\popup");
                url = HttpContext.Request.Scheme +"://"+ Path.Combine(HttpContext.Request.Host.Value, "UploadFile\\popup");
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);

                fileName = DateTime.Now.ToString("yyyyMMddHHmmss_") + upload.FileName;
                path = Path.Combine(path, fileName);
                url = Path.Combine(url, fileName);
                using (var stream = System.IO.File.Create(path))
                {
                    upload.CopyTo(stream);
                }
            }
            return new UploadedFile()
            {
                uploaded = 1,
                fileName = fileName,
                url = url
            };
        }

        /// <summary>
        /// CKEditor 파일업로드 리턴 구조체
        /// </summary>
        public class UploadedFile
        {
            public int uploaded { get; set; }
            public string fileName { get; set; }
            public string url { get; set; }
        }

    }
}
