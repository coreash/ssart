﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using Eorder.Models.Eorder;
using StoredProcedureEFCore;
using Eorder.Filters;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Security.Cryptography;
using Eorder.Helpers;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public LoginController(Eorder_CelltrionContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        [HttpPost]
        public string Login([FromBody] LoginInfo info)
        {
            List<LoginInfo> items = null;

            try
            {
                _context.LoadStoredProc("dbo.[UP_LOGIN_SELECT_LOGINWORK_2.0]")
                    .AddParam("@id", info.id)
                    .Exec(r => items = r.ToList<LoginInfo>());
                if (items.Count <= 0)
                {
                    return "FAIL";
                }
            }catch
            {
                throw;
            }
            var item = items[0];
            var hashObj = new HashBytesForMsSql();
            var pwEncoded = hashObj.GetHashData(info.pwd);

            if (!item.pwd.Equals( pwEncoded))
            {
                return "CHKPWD";
            }
            if (string.IsNullOrEmpty(item.userNm))
            {
                return "INVALID";
            }
            HttpContext.Session.Set("UC", item.userCd.GetUtf8Bytes());
            HttpContext.Session.Set("UN", item.userNm.GetUtf8Bytes());
            HttpContext.Session.Set("UK", item.userKind.GetUtf8Bytes());
            HttpContext.Session.Set("VC", item.venCd.GetUtf8Bytes());
            HttpContext.Session.Set("VN", item.venNm.GetUtf8Bytes());

            if (item.needChangePw.Equals("Y"))
            {
                return "FIRSTLOGIN";
            }
            else if (item.needChangePw.Equals("T"))
            {
                return "NEEDPWCHANGE";
            }
            else
            {
                return "OK";
            }
        }

        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        [HttpGet]
        [Route("FindInfo")]
        public string FindInfo(string venNm, string venNum)
        {
            var item = from mem in _context.Eo061s
                       join ven in _context.Eo030s on mem.Eo61MemberVen equals ven.Eo03VenCd
                       where ven.Eo03VenNum.Replace("-","").Equals(venNum.Replace("-",""))
                       where ven.Eo03VenNm.Contains(venNm.Trim())
                       select mem.Eo61Id;
            if(item.Count() > 0)
            {
                return item.FirstOrDefault().ToString();
            }
            else
            {
                return "";
            }
        }

        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        [HttpGet]
        [Route("IsLogin")]
        public LoginInfo IsLogin()
        {
            return new LoginInfo { 
                userCd = SESSION_USERCD,
                userNm = SESSION_USERNM,
                userKind = SESSION_USERKIND,
                venCd = SESSION_VENCD,
                venNm = SESSION_VENNM
            };
        }

        /// <summary>
        /// 파일 다운로드
        /// </summary>
        /// <param name="filefolder"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("FileDownload")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult FileDownload(string filefolder, string fileName)
        {
            var path = Path.Combine(_environment.WebRootPath, filefolder);
            var filePath = Path.Combine(path, fileName);

            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            try
            {
                var ret = new FileContentResult(System.IO.File.ReadAllBytes(filePath), "application/octet-stream");
                ret.FileDownloadName = fileName;
                return ret;
            }
            catch
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        
    }
}
