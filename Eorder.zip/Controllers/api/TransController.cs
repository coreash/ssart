﻿using Eorder.Models;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
    public class TransController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;
        public TransController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 거래명세서 목록
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="ordNo"></param> 전표번호
        /// <param name="salprssGb"></param> 발행구분
        /// <param name="page"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult<Paging> GetTrans(string startDate, string endDate, string venCd, string ordNo, string salprssGb)
        {
            IEnumerable<TRANS_COMM_VW_LIST> items = null;

            if (!IsAdmin && !IsSales) venCd = SESSION_VENCD;
            if (venCd == null) venCd = "";

            _context.LoadStoredProc("dbo.UP_SELECT_TRANS_COMM_VW")
                    .AddParam("@START_DATE", startDate)
                    .AddParam("@END_DATE", endDate)
                    .AddParam("@CUST_CD", venCd)
                    .Exec(r => items = r.ToList<TRANS_COMM_VW_LIST>());

            var count = items.Count();

            return new Paging
            {
                Count = count,
                List = items.OrderByDescending(x=> x.OrdNo).ToList()
            };
        }

        /// <summary>
        /// 거래명세서 출력용 데이터
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public ActionResult<List<TRANS_COMM_VW_LIST>> GetTrans(string id)
        {
            string[] aryOrdNo = id.Split(",");
            IEnumerable<TRANS_COMM_VW_LIST> master = null;
            IEnumerable<TRANS_COMM_VW_DETAIL> detail = null;

            _context.LoadStoredProc("dbo.UP_SELECT_TRANS_COMM_VW")
                   .AddParam("@ORDNOS", id)
                   .Exec(r => master = r.ToList<TRANS_COMM_VW_LIST>());

            _context.LoadStoredProc("dbo.UP_SELECT_TRANS_COMM_DETAIL")
                    .AddParam("@ORDNOS", id)
                    .Exec(r => detail = r.ToList<TRANS_COMM_VW_DETAIL>());

            foreach(TRANS_COMM_VW_LIST item in master)
            {
                item.detail = detail.Where(x => x.OrdNo.Equals(item.OrdNo)).ToList();
            }

            return master.ToList();
        }
    }
}
