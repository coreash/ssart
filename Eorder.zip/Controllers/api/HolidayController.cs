﻿using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    public class HolidayController : ControllerBaseCommon
    {
        private readonly Eorder_CelltrionContext _context;

        public HolidayController(Eorder_CelltrionContext context)
        {
            _context = context;
        }

        /// <summary>
        /// 공휴일 목록
        /// </summary>
        /// <param name="year"></param>
        /// <returns></returns>
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public ActionResult<List<EoHoliday>> GetHolidays(string year)
        {
            var items = from t in _context.EoHolidays
                        where t.EodayFlag.Equals("holiday")
                        where t.EodayTargetDate.StartsWith(year)
                        select t;

            return items.ToList();
        }

        /// <summary>
        /// 공휴일 등록
        /// </summary>
        /// <param name="eoHoliday"></param>
        /// <returns></returns>
        [HttpPost]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult PostHolidays(EoHoliday eoHoliday)
        {
            _context.EoHolidays.Add(eoHoliday);

            try
            {
                _context.SaveChanges();
            }
            catch
            {
                throw;
            }
            return NoContent();
        }

        /// <summary>
        /// 공휴일 삭제
        /// </summary>
        /// <param name="eoHoliday"></param>
        /// <returns></returns>
        [HttpDelete]
        [Route("{id}")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult DeleteHolidays(string id)
        {
            EoHoliday eoHoliday = _context.EoHolidays.Find(id);

            _context.Remove(eoHoliday);
            _context.SaveChanges();

            return NoContent();
        }
    }
}
