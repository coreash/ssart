﻿using Eorder.Filters;
using Eorder.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Controllers.api
{
    [Route("api/[controller]")]
    [ApiController]
    [TypeFilter(typeof(CustomAuthorizationFilter))]
    public class ControllerBaseCommon : ControllerBase
    {
        public string SESSION_USERCD => HttpContext.GetSessionName("UC");
        public string SESSION_USERNM => HttpContext.GetSessionName("UN");
        public string SESSION_USERKIND => HttpContext.GetSessionName("UK");
        public string SESSION_VENCD => HttpContext.GetSessionName("VC");
        public string SESSION_VENNM => HttpContext.GetSessionName("VN");

        /// <summary>
        /// 관리자여부
        /// </summary>
        public bool IsAdmin => SESSION_USERKIND.Equals("A") || SESSION_USERKIND.Equals("SA");

        /// <summary>
        /// 담당자여부
        /// </summary>
        public bool IsSales => SESSION_USERKIND.Equals("S");
    }
}
