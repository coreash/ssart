﻿using Eorder.Filters;
using Eorder.Helpers;
using Eorder.Models.Celltrion;
using Eorder.Models.Eorder;
using Eorder.Models.Eorder.Sales;
using Eorder.Models.Eorder.Stocks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eorder.Controllers
{
    public class StockController : ControllerCommon
    {
        private readonly ILogger<StockController> _logger;
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public StockController(Eorder_CelltrionContext context, IWebHostEnvironment environment, ILogger<StockController> logger)
        {
            _context = context;
            _environment = environment;
            _logger = logger;
        }

        #region + === 매출/재고업로드 (매출자료) ===
        /// <summary>
        /// 매출자료 목록
        /// </summary>
        /// <returns></returns>
        public IActionResult SaleList()
        {
            if (IsAdmin || IsSales)
            {
                ViewBag.IsAdmin = "true";
                ViewBag.NoRowsColSpan = "12";
                ViewBag.SaleVenClass = "";
            }
            else
            {
                ViewBag.IsAdmin = "false";
                ViewBag.NoRowsColSpan = "10";
                ViewBag.SaleVenClass = "mgl0";
            }

            return View();
        }

        /// <summary>
        /// 재고자료 목록
        /// </summary>
        /// <returns></returns>
        public IActionResult StockList()
        {
            if (IsAdmin || IsSales)
            {
                ViewBag.IsAdmin = "true";
                ViewBag.NoRowsColSpan = "8";
            }
            else
            {
                ViewBag.IsAdmin = "false";
                ViewBag.NoRowsColSpan = "6";
            }

            return View();
        }

        /// <summary>
        /// 매출자료 엑셀파일 업로드
        /// </summary>
        /// <returns></returns>
        public IActionResult UploadExcelSale()
        {
            IFormFile file = Request.Form.Files[0];
            string excelDate = Request.Form["excelDate"].ToString().Replace("-", "");
            string userCd = SESSION_USERCD;
            string venCd = SESSION_VENCD;
            if (IsAdmin || IsSales)
            {
                venCd = "";     // ??? - 관리자인 경우 거래처코드, 거래처명 정보 처리 방법 정의 필요함
            }

            venCd = venCd ?? "";

            string webRootPath = _environment.WebRootPath;
            ExcelUtility excel = new ExcelUtility();
            DataTable dt = GetExcelSaleDataTable();
            dt = excel.ConvertExcelToDataTable(file, webRootPath, dt);
            
            ProcedureResult item = null;
            _context.LoadStoredProc("dbo.UP_EOSALES_INSERT")
                .AddParam("@SaleMonth", excelDate)
                .AddParam("@VenCd", venCd)
                .AddParam("@UserCd", userCd)
                .AddParam(new SqlParameter { ParameterName = "@UDTT_EOSales", SqlDbType = SqlDbType.Structured, TypeName = "dbo.UDTT_EOSales", Value = dt })
                .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

            return Ok(item);
            //return this.Content("OK");
        }

        /// <summary>
        /// 재고자료 엑셀파일 업로드
        /// </summary>
        /// <returns></returns>
        public IActionResult UploadExcelStock()
        {
            IFormFile file = Request.Form.Files[0];
            string excelDate = Request.Form["excelDate"].ToString().Replace("-", "");
            string userCd = SESSION_USERCD;
            string venCd = SESSION_VENCD;
            if (IsAdmin || IsSales)
            {
                venCd = "";     // ??? - 관리자인 경우 거래처코드, 거래처명 정보 처리 방법 정의 필요함
            }

            string webRootPath = _environment.WebRootPath;
            ExcelUtility excel = new ExcelUtility();
            DataTable dt = GetExcelStockDataTable();
            dt = excel.ConvertExcelToDataTable(file, webRootPath, dt);

            ProcedureResult item = null;
            _context.LoadStoredProc("dbo.UP_EOSTOCKS_INSERT")
                .AddParam("@StockMonth", excelDate)
                .AddParam("@VenCd", venCd)
                .AddParam("@UserCd", userCd)
                .AddParam(new SqlParameter { ParameterName = "@UDTT_EOStocks", SqlDbType = SqlDbType.Structured, TypeName = "dbo.UDTT_EOStocks", Value = dt })
                .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

            return Ok(item);
            //return this.Content("OK");
        }

        /// <summary>
        /// 재고자료 엑셀파일 다운로드
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IActionResult DownloadExcelStock([FromQuery] EoStockSearch param)
        {
            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }
            param.VenCd = param.VenCd?.Trim() ?? "";
            //param.VenCd = "addVenCd";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoStock> items = null;
            _context.LoadStoredProc("dbo.UP_EOSTOCKS_LIST_SELECT")
                .AddParam("@StockMonth", param.StockMonth)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<EoStock>());

            string extension = "xlsx";
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;

            // 관리자, 회원 - 거래처코드, 거래처명 칼럼 포함여부 예외처리, 칼럼명 한글처리
            List <EoStockExcelAdmin> excelAdminItems = new List<EoStockExcelAdmin>();
            List<EoStockExcel> excelItems = new List<EoStockExcel>();
            if (IsAdmin || IsSales)
            {
                foreach (var item in items)
                {
                    excelAdminItems.Add(new EoStockExcelAdmin { 
                        순번 = item.Num,
                        년월 = item.StockMonth,
                        거래처코드 = item.AddVenCd,
                        거래처명 = item.AddVenNm,
                        표준코드 = item.StandardCode,
                        품목명 = item.ProductName,
                        규격 = item.Standard,
                        재고수량 = item.StockQuantity
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelAdminItems, extension);
            }
            else
            {
                foreach (var item in items)
                {
                    excelItems.Add(new EoStockExcel
                    {
                        순번 = item.Num,
                        년월 = item.StockMonth,
                        표준코드 = item.StandardCode,
                        품목명 = item.ProductName,
                        규격 = item.Standard,
                        재고수량 = item.StockQuantity
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelItems, extension);
            }

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "재고자료_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 재고자료 업로드 현황 엑셀파일 다운로드
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IActionResult DownloadStatusStock([FromQuery] EoStockSearch param)
        {
            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }
            param.VenCd = "";
            //param.VenCd = "addVenCd";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoStockStatus> items = null;
            _context.LoadStoredProc("dbo.UP_EOStocks_Status_LIST_SELECT")
                .AddParam("@StockMonth", param.StockMonth)
                .Exec(r => items = r.ToList<EoStockStatus>());

            string extension = "xlsx";
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;

            // 관리자, 회원 - 거래처코드, 거래처명 칼럼 포함여부 예외처리, 칼럼명 한글처리
            List<EoStockStatusExcel> excelItems = new List<EoStockStatusExcel>();
            foreach (var item in items)
            {
                excelItems.Add(new EoStockStatusExcel
                {
                    거래처코드 = item.VenCd,
                    거래처명 = item.VenNm,
                    업로드현황 = item.Status
                });
            }
            workbook = excel.WriteExcelWithNPOI(excelItems, extension);

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "재고자료_업로드현황_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 매출자료 엑셀파일 다운로드
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IActionResult DownloadExcelSale([FromQuery] EoSaleSearch param)
        {
            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            param.VenCd = param.VenCd?.Trim() ?? "";

            //param.VenCd = "addVenCd";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoSale> items = null;
            _context.LoadStoredProc("dbo.UP_EOSALES_LIST_SELECT")
                .AddParam("@SaleMonth", param.SaleMonth)
                .AddParam("@VenCd", param.VenCd)
                .AddParam("@SaleVenName", param.SaleVenName)
                .AddParam("@PageNo", param.Page)
                .AddParam("@PageSize", param.PageSize)
                .Exec(r => items = r.ToList<EoSale>());

            string extension = "xlsx";
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;

            // 관리자, 회원 - 거래처코드, 거래처명 칼럼 포함여부 예외처리, 칼럼명 한글처리
            List<EoSaleExcelAdmin> excelAdminItems = new List<EoSaleExcelAdmin>();
            List<EoSaleExcel> excelItems = new List<EoSaleExcel>();
            if (IsAdmin || IsSales)
            {
                foreach (var item in items)
                {
                    excelAdminItems.Add(new EoSaleExcelAdmin
                    {
                        순번 = item.Num,
                        등록일 = item.AddDateYymmdd,
                        매출일 = item.SaleDateYymmdd,
                        거래처코드 = item.AddVenCd,
                        거래처명 = item.AddVenNm,
                        매출처명 = item.SaleVenName,
                        주소 = item.Address,
                        우편번호 = item.ZipCode,
                        표준코드 = item.StandardCode,
                        품목명 = item.ProductName,
                        규격 = item.Standard,
                        매출수량 = item.SaleQuantity
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelAdminItems, extension);
            }
            else
            {
                foreach (var item in items)
                {
                    excelItems.Add(new EoSaleExcel
                    {
                        순번 = item.Num,
                        등록일 = item.AddDateYymmdd,
                        매출일 = item.SaleDateYymmdd,
                        매출처명 = item.SaleVenName,
                        주소 = item.Address,
                        우편번호 = item.ZipCode,
                        표준코드 = item.StandardCode,
                        품목명 = item.ProductName,
                        규격 = item.Standard,
                        매출수량 = item.SaleQuantity
                    });
                }
                workbook = excel.WriteExcelWithNPOI(excelItems, extension);
            }

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "매출자료_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 매출자료 업로드 현황 엑셀파일 다운로드
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public IActionResult DownloadStatusSale([FromQuery] EoSaleSearch param)
        {
            // 관리자 거래처 선택, 회원 자신으로 제한
            if (SESSION_USERKIND.Equals("U"))
            {
                param.VenCd = SESSION_VENCD;
            }

            param.VenCd = param.VenCd?.Trim() ?? "";

            //param.VenCd = "addVenCd";
            param.Page = 1;
            param.PageSize = 99999999;

            // 주의 : C# DataType 과 Sql DataType 다를 경우 에러 발생함 (예: int <-> bigint)
            List<EoSaleStatus> items = null;
            _context.LoadStoredProc("dbo.UP_EOSales_Status_LIST_SELECT")
                .AddParam("@SaleMonth", param.SaleMonth)
                .Exec(r => items = r.ToList<EoSaleStatus>());

            string extension = "xlsx";
            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook = null;

            // 관리자, 회원 - 거래처코드, 거래처명 칼럼 포함여부 예외처리, 칼럼명 한글처리
            List<EoSaleStatusExcel> excelItems = new List<EoSaleStatusExcel>();

            foreach (var item in items)
            {
                excelItems.Add(new EoSaleStatusExcel
                {
                    거래처코드 = item.VenCd,
                    거래처명 = item.VenNm,
                    업로드현황 = item.Status
                });
            }
            workbook = excel.WriteExcelWithNPOI(excelItems, extension);

            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "매출자료_업로드현황_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }

        /// <summary>
        /// 매출/재고 샘플 엑셀파일 다운로드
        /// </summary>
        /// <param name="sampleType"></param>
        /// <returns></returns>
        public IActionResult DownloadExcelSample([FromQuery] string sampleType)
        {
            string fileName = "SampleStock.xlsx";

            if (!string.IsNullOrWhiteSpace(sampleType) && sampleType.Equals("sale", StringComparison.OrdinalIgnoreCase))
            {
                fileName = "SampleSale.xlsx";
            }
            else if (!string.IsNullOrWhiteSpace(sampleType) && sampleType.Equals("collectMoney", StringComparison.OrdinalIgnoreCase))
            {
                fileName = "SampleCollectMoney.xlsx";
            }
            else if (!string.IsNullOrWhiteSpace(sampleType) && sampleType.Equals("reward", StringComparison.OrdinalIgnoreCase))
            {
                fileName = "SampleReward.xlsx";
            }

            string webRootPath = _environment.WebRootPath;
            string folderName = "UploadExcel";
            string newPath = Path.Combine(webRootPath, folderName);
            string fullPath = Path.Combine(newPath, fileName);
            byte[] fileBytes = System.IO.File.ReadAllBytes(fullPath);
            
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

        /// <summary>
        /// 매출/재고업로드 현황 다운로드
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="venCd"></param>
        /// <returns></returns>
        public IActionResult DownloadStatusInfo([FromQuery] string startDate, [FromQuery] string endDate, [FromQuery] string venCd)
        {
            List<UploadedData> items = null;
            _context.LoadStoredProc("dbo.UP_EOSalesStocks_Check_Uploaded_Select")
                .AddParam("@START_MONTH", startDate)
                .AddParam("@END_MONTH", endDate)
                .AddParam("@VEN_CD", venCd ?? "")
                .Exec(r => items = r.ToList<UploadedData>());

            ExcelUtility excel = new ExcelUtility();
            IWorkbook workbook;


            #region 데이터 정리
            var dt = new DataTable();

            dt.Columns.Add("거래처코드");
            dt.Columns.Add("거래처명");

            int yyyymm_from = Convert.ToInt32(startDate);
            int yyyymm_to = Convert.ToInt32(endDate);

            while (yyyymm_from <= yyyymm_to)
            {
                string currDate = yyyymm_from.ToString().Substring(0, 4) + '-' + yyyymm_from.ToString().Substring(4, 2);
                dt.Columns.Add(currDate + "_Sales");
                dt.Columns.Add(currDate + "_Stocks");
                yyyymm_from = Convert.ToInt32(Convert.ToDateTime(currDate + "-01").AddMonths(1).ToString("yyyyMM"));
            }

            foreach (var item in items)
            {
                DataRow row = null;
                bool needAdd = true;
                yyyymm_from = Convert.ToInt32(startDate);
                yyyymm_to = Convert.ToInt32(endDate);

                if (dt.Rows.Count <= 0 || dt.Rows[dt.Rows.Count - 1]["거래처코드"].ToString() != item.VenCd) {
                    row = dt.NewRow();
                    row["거래처코드"] = item.VenCd;
                    row["거래처명"] = item.VenNm;

                    while (yyyymm_from <= yyyymm_to)
                    {
                        string currDate = yyyymm_from.ToString().Substring(0, 4) + '-' + yyyymm_from.ToString().Substring(4, 2);
                        row[currDate + "_Sales"] = "N";
                        row[currDate + "_Stocks"] = "N";
                        yyyymm_from = Convert.ToInt32(Convert.ToDateTime(currDate + "-01").AddMonths(1).ToString("yyyyMM"));
                    }
                }
                else
                {
                    row = dt.Rows[dt.Rows.Count - 1];
                    needAdd = false;
                }
                if (!string.IsNullOrEmpty(item.YYYYMM))
                {
                    string itemYYYYMM = item.YYYYMM.Substring(0, 4) + "-" + item.YYYYMM.Substring(4);
                    row[itemYYYYMM + "_Sales"] = item.SalesCnt > 0 ? "Y" : "N";
                    row[itemYYYYMM + "_Stocks"] = item.StocksCnt > 0 ? "Y" : "N";
                }

                if(needAdd) dt.Rows.Add(row);
            }
            #endregion

            workbook = new XSSFWorkbook();
            var cellStyle = workbook.CreateCellStyle();
            cellStyle.Alignment = HorizontalAlignment.Center;

            ISheet sheet1 = workbook.CreateSheet("Sheet 1");

            #region 헤더 설정
            IRow row1 = sheet1.CreateRow(0);
            IRow row2 = sheet1.CreateRow(1);

            for (int ii = 0; ii < dt.Columns.Count; ii++)
            {
                string columnName = dt.Columns[ii].ToString();
                string columnName2 = columnName;
                if (ii >= 2)
                {
                    columnName = columnName.Substring(0, 7);
                    columnName2 = columnName2.Substring(8) == "Sales" ? "출하" : "재고";
                }

                ICell cell = row1.CreateCell(ii);
                cell.SetCellValue(columnName);
                cell.CellStyle = cellStyle;
                cell.CellStyle.VerticalAlignment = VerticalAlignment.Center;

                ICell cell2 = row2.CreateCell(ii);
                cell2.SetCellValue(columnName2);
                cell2.CellStyle = cellStyle;
                cell2.CellStyle.VerticalAlignment = VerticalAlignment.Center;
            }
            sheet1.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 1, 0, 0));
            sheet1.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 1, 1, 1));
            sheet1.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 0, 2, 3));
            sheet1.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 0, 4, 5));
            sheet1.AddMergedRegion(new NPOI.SS.Util.CellRangeAddress(0, 0, 6, 7));

            #endregion

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                IRow row = sheet1.CreateRow(i + 2);
                for (int j = 0; j < dt.Columns.Count; j++)
                {

                    ICell cell = row.CreateCell(j);
                    string columnName = dt.Columns[j].ToString();
                    cell.SetCellValue(dt.Rows[i][columnName].ToString());
                    if(j != 1) cell.CellStyle = cellStyle;
                }
            }
            // Auto size columns
            
            for (int j = 0; j < row1.LastCellNum; j++)
            {
                sheet1.AutoSizeColumn(j);
            }


            byte[] fileContents = excel.GetFileContentsWorkbook(workbook);
            string contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
            string fileDownloadName = "매출재고자료_업로드현황_" + DateTime.Now.ToString();

            return File(fileContents: fileContents,
                        contentType: contentType,
                        fileDownloadName: fileDownloadName);
        }
        #endregion


        #region + === Sample Code ===
        //public IActionResult SampelUploadExcel([FromBody] EoStockSearch param)
        //{
        //    // 일반회원인 경우 회원의 VenCd 만 조회가능
        //    //param.VenCd     = HttpContext.Session.GetString("VEN_CD");
        //    //param.AddUserCd = HttpContext.Session.GetString("USER_ID");

        //    // =================================================================
        //    // Entityframework

        //    param.StockMonth = "202106";
        //    param.VenCd = "venCd#1";

        //    DataTable dt = GetExcelDataTable();
        //    //List<ProcedureResult> items = null;
        //    ProcedureResult item = null;
        //    _context.LoadStoredProc("dbo.UP_EOSTOCKS_INSERT")
        //        .AddParam("@StockMonth", param.StockMonth)
        //        .AddParam("@VenCd", param.VenCd)
        //        .AddParam("@UserCd", 1)
        //        .AddParam(new SqlParameter { ParameterName = "@UDTT_EOStocks", SqlDbType = SqlDbType.Structured, TypeName = "dbo.UDTT_EOStocks", Value = dt })
        //        .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

        //    return Ok(item);
        //}


        #endregion

        #region + === Private Method ===

        /// <summary>
        /// 매출자료 엑셀파일에 대한 DataTable 변환
        /// </summary>
        /// <returns></returns>
        private DataTable GetExcelSaleDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("saleDate", typeof(string));
            dt.Columns.Add("saleVenName", typeof(string));
            dt.Columns.Add("address", typeof(string));
            dt.Columns.Add("zipCode", typeof(string));
            dt.Columns.Add("standardCode", typeof(string));
            dt.Columns.Add("productName", typeof(string));
            dt.Columns.Add("standard", typeof(string));
            dt.Columns.Add("saleQuantity", typeof(int));

            return dt;
        }

        /// <summary>
        /// 재고자료 엑셀파일에 대한 DataTable 변환
        /// </summary>
        /// <returns></returns>
        private DataTable GetExcelStockDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("standardCode", typeof(string));
            dt.Columns.Add("productName", typeof(string));
            dt.Columns.Add("standard", typeof(string));
            dt.Columns.Add("stockQuantity", typeof(int));

            return dt;
        }

        //private FileContentResult GetFileContentWorkbook(IWorkbook workbook, string filename)
        //{
        //    // =================================================================
        //    string contentType = ""; // Scope
        //    // Credit for two stream since workbook.write() closes the first one: https://stackoverflow.com/a/36584861/6336270 
        //    MemoryStream tempStream = null;
        //    MemoryStream stream = null;
        //    try
        //    {
        //        // 1. Write the workbook to a temporary stream
        //        tempStream = new MemoryStream();
        //        workbook.Write(tempStream);
        //        // 2. Convert the tempStream to byteArray and copy to another stream
        //        var byteArray = tempStream.ToArray();
        //        stream = new MemoryStream();
        //        stream.Write(byteArray, 0, byteArray.Length);
        //        stream.Seek(0, SeekOrigin.Begin);
        //        // 3. Set file content type
        //        contentType = workbook.GetType() == typeof(XSSFWorkbook) ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : "application/vnd.ms-excel";
        //        // 4. Return file
        //        return File(
        //            fileContents: stream.ToArray(),
        //            contentType: contentType,
        //            //fileDownloadName: "매출자료_업로드현황_" + DateTime.Now.ToString() + ((workbook.GetType() == typeof(XSSFWorkbook)) ? ".xlsx" : "xls"));
        //            fileDownloadName: filename + ((workbook.GetType() == typeof(XSSFWorkbook)) ? ".xlsx" : "xls"));
        //    }
        //    finally
        //    {
        //        if (tempStream != null) tempStream.Dispose();
        //        if (stream != null) stream.Dispose();
        //    }
        //    // -----------------------------------------------------------------
        //}

        #endregion
    }
}
