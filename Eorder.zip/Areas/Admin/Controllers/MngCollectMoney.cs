﻿using Eorder.Controllers;
using Eorder.Helpers;
using Eorder.Models.Eorder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using StoredProcedureEFCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class MngCollectMoney : ControllerCommon
    {
        private readonly ILogger<StockController> _logger;
        private readonly Eorder_CelltrionContext _context;
        private readonly IWebHostEnvironment _environment;

        public MngCollectMoney(Eorder_CelltrionContext context, IWebHostEnvironment environment, ILogger<StockController> logger)
        {
            _context = context;
            _environment = environment;
            _logger = logger;
        }
        public IActionResult Index()
        {
            if (SESSION_USERKIND == "A")
            {
                ViewBag.IsAdmin = "true";
                ViewBag.NoRowsColSpan = "10";
            }
            else
            {
                ViewBag.IsAdmin = "false";
                ViewBag.NoRowsColSpan = "10";
            }

            return View("List");
        }

        /// <summary>
        /// 수금자료 엑셀파일 업로드
        /// </summary>
        /// <returns></returns>
        public IActionResult UploadExcel()
        {
            IFormFile file = Request.Form.Files[0];
            string excelDate = Request.Form["excelDate"].ToString().Replace("-", "");
            string userCd = SESSION_USERCD;
            string venCd = SESSION_VENCD;
            if (SESSION_USERKIND == "A")
            {
                venCd = "";     // ??? - 관리자인 경우 거래처코드, 거래처명 정보 처리 방법 정의 필요함
            }

            string webRootPath = _environment.WebRootPath;
            ExcelUtility excel = new ExcelUtility();
            DataTable dt = GetExcelDataTable();
            dt = excel.ConvertExcelToDataTable(file, webRootPath, dt);

            // 선택한 excelDate 와 엑셀의 YYYYMM 칼럼값 동일한지 검증 추가 ???
            DataRow[] drs = dt.Select("YYYYMM <> '" + excelDate + "'");
            ProcedureResult item = null;

            if (drs.Length > 0)
            {
                item = new ProcedureResult();
                item.ProcCount = -1;
                item.ProcData = "ERROR";
                item.ProcErrorMessage = "엑셀파일 [년월] 칼럼 데이터가 틀립니다.\n확인 후 다시 시도해주십시오.";
                item.ProcMessage = "";
                item.ProcReturnData = "";

                return BadRequest(item);
            }

            _context.LoadStoredProc("dbo.UP_EOCOLLECTMONEY_INSERT")
                    .AddParam("@CollectMonth", excelDate)
                    .AddParam("@UserCd", userCd)
                    .AddParam(new SqlParameter { ParameterName = "@UDTT_EOCollectMoney", SqlDbType = SqlDbType.Structured, TypeName = "dbo.UDTT_EOCollectMoney", Value = dt })
                    .Exec(r => item = r.FirstOrDefault<ProcedureResult>());

            return Ok(item);
            //return this.Content("OK");
        }

        #region === Private Method ===
        /// <summary>
        /// 수금자료 엑셀파일에 대한 DataTable 변환
        /// </summary>
        /// <returns></returns>
        private DataTable GetExcelDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("YYYYMM", typeof(string));
            dt.Columns.Add("VenCd", typeof(string));
            dt.Columns.Add("ExpireDate", typeof(string));
            dt.Columns.Add("BankName", typeof(string));
            dt.Columns.Add("BankAccount", typeof(string));
            dt.Columns.Add("Price", typeof(Int64));

            return dt;
        }

        #endregion
    }
}
