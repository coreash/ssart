﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eorder.Areas.Main.Controllers
{
    [Area("Main")]
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View("Login");
        }
        
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return View("Login");
        }


    }
}
