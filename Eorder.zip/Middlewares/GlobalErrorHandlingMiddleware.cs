﻿using Eorder.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace Eorder.Middlewares
{
    public class GlobalErrorHandlingMiddleware
    {
        private readonly ILogger<GlobalErrorHandlingMiddleware> _logger;
        private readonly RequestDelegate _next;

        public GlobalErrorHandlingMiddleware(RequestDelegate next, ILogger<GlobalErrorHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next.Invoke(context);
            }
            catch (Exception ex)
            {
                _logger.LogError("Request {method} {url} \n Error => {error} ",
                    context.Request?.Method,
                    context.Request?.Path.Value,
                    ex);    

                var response = context.Response;
                string errorJson;
                if (context.Request.IsAjaxRequest())
                {
                    response.ContentType = "application/json";
                    response.StatusCode = (int)HttpStatusCode.InternalServerError;

                    var errorResponse = new
                    {
                        //message = ex.Message,
                        message = "InternalServerError",
                        statusCode = response.StatusCode,
                        ExceptionMsg = ex.Message
                    };

                    errorJson = JsonSerializer.Serialize(errorResponse);

                    await response.WriteAsync(errorJson);
                }
                else
                {
                    response.Redirect("/Home/Error");
                }
            }
        }
    }
}
